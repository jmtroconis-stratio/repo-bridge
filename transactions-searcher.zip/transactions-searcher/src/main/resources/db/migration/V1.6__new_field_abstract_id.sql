ALTER TABLE transaction ADD COLUMN gts_extract_id VARCHAR(255) DEFAULT NULL;
ALTER TABLE transaction ALTER COLUMN additional_information TYPE VARCHAR(1024);
ALTER TABLE transaction ALTER COLUMN description TYPE VARCHAR(1024);