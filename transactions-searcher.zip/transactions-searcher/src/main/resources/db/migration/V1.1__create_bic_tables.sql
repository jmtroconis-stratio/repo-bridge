CREATE TABLE entity_country
(
    entity_id                     VARCHAR(255) NOT NULL,
    country_id                    char(2) NOT NULL,
    PRIMARY KEY (entity_id, country_id)
);

CREATE TABLE agent
(
    bic                           VARCHAR(11) NOT NULL,
    entity_id                     VARCHAR(255),
    country_id                    char(2),
    PRIMARY KEY (bic),
    FOREIGN KEY (entity_id, country_id) REFERENCES entity_country (entity_id, country_id)
);
