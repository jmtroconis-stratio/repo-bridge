CREATE SEQUENCE hibernate_sequence_transaction INCREMENT 50 START 1 MINVALUE 1;

CREATE TABLE transaction_company_account (
  -- Clave primaria interna
  transaction_company_account_pk BIGSERIAL PRIMARY KEY,

  -- Clave primaria funcional
  account_id VARCHAR(255) NOT NULL,
  country CHAR(2) NOT NULL,
  UNIQUE(account_id, country),

  company_global_id VARCHAR(255),
  display_number VARCHAR(255),
  alias VARCHAR(255),
  agent VARCHAR(255)
);

CREATE SEQUENCE hibernate_sequence_transaction_company_account INCREMENT 50 START 1 MINVALUE 1;

CREATE TABLE transaction (
  -- Clave primaria interna
  transaction_pk BIGSERIAL PRIMARY KEY,

  -- Clave primaria funcional
  transaction_id VARCHAR(255) NOT NULL,
  transaction_company_account_fk BIGINT NOT NULL,
  FOREIGN KEY (transaction_company_account_fk) REFERENCES transaction_company_account(transaction_company_account_pk),
  UNIQUE(transaction_pk, transaction_company_account_fk),

  swift_code VARCHAR(255),
  creation_date TIMESTAMP WITH TIME ZONE,
  processed_date TIMESTAMP WITH TIME ZONE,
  accounting_date TIMESTAMP WITH TIME ZONE,

  description VARCHAR(255),
  transaction_type VARCHAR(255),
  transaction_category VARCHAR(255),

  transaction_amount NUMERIC(38,18),
  transaction_amount_currency VARCHAR(255),

  transaction_balance_amount NUMERIC(38,18),
  transaction_balance_amount_currency VARCHAR(255),

  local_transaction_code VARCHAR(255),
  local_transaction_description VARCHAR(255),
  additional_information VARCHAR(255),
  customer_transaction_code VARCHAR(255),
  customer_transaction_description VARCHAR(255),
  customer_additional_information VARCHAR(255),
  transaction_client_reference VARCHAR(255),
  transaction_batch_reference VARCHAR(255),
  transaction_internal_reference VARCHAR(255),
  transaction_consolidated BOOLEAN
);