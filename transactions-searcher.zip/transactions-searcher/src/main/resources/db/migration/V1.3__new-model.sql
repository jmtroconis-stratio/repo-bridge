DROP TABLE IF EXISTS transaction_company_account cascade;
DROP TABLE IF EXISTS transaction cascade;
DROP SEQUENCE IF EXISTS hibernate_sequence_transaction;
DROP SEQUENCE IF EXISTS hibernate_sequence_transaction_company_account;

CREATE TABLE transaction_company_account (
  account_id VARCHAR(255) NOT NULL,
  country CHAR(2) NOT NULL,
  company_global_id VARCHAR(255),
  display_number VARCHAR(255),
  alias VARCHAR(255),
  bic VARCHAR(11),
  account_id_type VARCHAR(255),
  iban VARCHAR(255),
  PRIMARY KEY(account_id, country),
  FOREIGN KEY (bic) REFERENCES agent(bic)
);

CREATE TABLE transaction (
  transaction_id VARCHAR(255) NOT NULL,
  transaction_consolidated BOOLEAN NOT NULL,
  account_id VARCHAR(255) NOT NULL,
  country CHAR(2) NOT NULL,

  swift_code VARCHAR(255),
  creation_date TIMESTAMP WITH TIME ZONE,
  processed_date TIMESTAMP WITH TIME ZONE,
  accounting_date TIMESTAMP WITH TIME ZONE,
  description VARCHAR(255),
  transaction_type VARCHAR(255),
  transaction_category VARCHAR(255),
  transaction_amount NUMERIC(38,18),
  transaction_amount_currency VARCHAR(255),
  transaction_balance_amount NUMERIC(38,18),
  transaction_balance_amount_currency VARCHAR(255),
  local_transaction_code VARCHAR(255),
  local_transaction_description VARCHAR(255),
  additional_information VARCHAR(255),
  customer_transaction_code VARCHAR(255),
  customer_transaction_description VARCHAR(255),
  customer_additional_information VARCHAR(255),
  transaction_client_reference VARCHAR(255),
  transaction_batch_reference VARCHAR(255),
  transaction_internal_reference VARCHAR(255),
  PRIMARY KEY(transaction_id, transaction_consolidated, account_id, country),
  FOREIGN KEY (account_id, country) REFERENCES transaction_company_account(account_id, country)
);