ALTER TABLE agent ADD tag                           VARCHAR(255);
ALTER TABLE agent ADD  modification_flag             VARCHAR(255);
ALTER TABLE agent ADD  branch_information            VARCHAR(255);
ALTER TABLE agent ADD  city_heading                  VARCHAR(255);
ALTER TABLE agent ADD  subtype_indication            VARCHAR(255);
ALTER TABLE agent ADD  value_added_services          VARCHAR(255);
ALTER TABLE agent ADD  extra_info                    VARCHAR(255);
ALTER TABLE agent ADD  physical_address_1            VARCHAR(255);
ALTER TABLE agent ADD  physical_address_2            VARCHAR(255);
ALTER TABLE agent ADD  physical_address_3            VARCHAR(255);
ALTER TABLE agent ADD  physical_address_4            VARCHAR(255);
ALTER TABLE agent ADD  location                      VARCHAR(255);
ALTER TABLE agent ADD  pob_number                    VARCHAR(255);
ALTER TABLE agent ADD  pob_location                  VARCHAR(255);
ALTER TABLE agent ADD  pob_country_name              VARCHAR(255);
ALTER TABLE agent ADD  institution_name              VARCHAR(255);
ALTER TABLE agent ADD country_name                  VARCHAR(255);

ALTER TABLE agent DROP CONSTRAINT agent_entity_id_fkey;

CREATE TABLE country
(
    country_id                    char(2) NOT NULL,
    PRIMARY KEY (country_id)
);

INSERT INTO country SELECT DISTINCT country_id FROM agent WHERE country_id IS NOT NULL;

ALTER TABLE agent ADD CONSTRAINT agent_country_id_fkey FOREIGN KEY (country_id) REFERENCES country (country_id);