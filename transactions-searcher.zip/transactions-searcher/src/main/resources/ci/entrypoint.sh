#!/bin/bash


    set -e

    source ${STRATIO_UTILS}/kms_utils.sh
    source ${STRATIO_UTILS}/b-log.sh


    DOCKER_LOG_LEVEL=${DOCKER_LOG_LEVEL:-DEBUG}
    eval LOG_LEVEL_${DOCKER_LOG_LEVEL}
    B_LOG --stdout true # enable logging over stdout

    export PORT0=${PORT0:-"8080"}

    declare -a VAULT_HOSTS
    IFS_OLD=$IFS
    IFS=',' read -r -a VAULT_HOSTS <<< "$VAULT_HOST"

    declare -a MARATHON_ARRAY
    OLD_IFS=$IFS
    IFS='/' read -r -a MARATHON_ARRAY <<< "$MARATHON_APP_ID"
    IFS=$OLD_IFS

    INFO "Trying to login in Vault"
    # Approle login from role_id, secret_id
    if [ "xxx$VAULT_TOKEN" == "xxx" ];
    then
       INFO "Login in vault..."
       login
       if [[ ${code} -ne 0 ]];
       then
           ERROR "  - Something went wrong log in in vault. Exiting..."
           return ${code}
       fi
    fi
    INFO "  - Logged!"

    export JAVA_ARGS="--server.port=${PORT0}"



    export MARATHON_SERVICE_NAME=${MARATHON_ARRAY[-1]}
    MARATHON_SERVICE_NAME=$(echo $MARATHON_SERVICE_NAME | sed -E 's/(.*)-\d*$/\1/')




    INFO "Postgres connection config start"
    export SPRING_DATASOURCE_USERNAME="${MARATHON_SERVICE_NAME}_transactions_gts"

    export POSTGRES_CERT="/etc/stratio/${MARATHON_SERVICE_NAME}_transactions_gts.pem"
    export POSTGRES_KEY="/etc/stratio/key.pkcs8"
    export CA_BUNDLE_PEM="/etc/stratio/ca-bundle.pem"

    INFO "  - Posgres certificate path ${POSTGRES_CERT}"
    INFO "  - Retreiving service certificate [PEM] from url: /gts/transactions/${MARATHON_SERVICE_NAME}.transactions.gts"
    getCert "userland" \
                "/gts/transactions/${MARATHON_SERVICE_NAME}.transactions.gts" \
                "${MARATHON_SERVICE_NAME}_transactions_gts" \
                "PEM" \
                "/etc/stratio" \
    && INFO "    - OK" \
    || INFO "    - Error"

    export POSTGRES_CRT="/etc/stratio/${MARATHON_SERVICE_NAME}_transactions_gts.crt"
    openssl x509 -outform der -in /etc/stratio/${MARATHON_SERVICE_NAME}_transactions_gts.pem -out ${POSTGRES_CRT}

    INFO "  - Getting Ca-Bundle for a given SSL_CERT_PATH/ca-bundle.pem"
    getCAbundle "/etc/stratio" "PEM" \
        && INFO "    - OK"   \
        || INFO "    - Error"

    export CA_BUNDLE_CRT="/etc/stratio/ca-bundle.crt"
    openssl x509 -outform der -in /etc/stratio/ca-bundle.pem -out ${CA_BUNDLE_CRT}
    export POSTGRES_KEY="/etc/stratio/key.pk8"

    openssl pkcs8 -topk8 -inform pem -in /etc/stratio/${MARATHON_SERVICE_NAME}_transactions_gts.key -outform der -nocrypt -out ${POSTGRES_KEY}

    INFO "  - [/etc/stratio] directory:"
    ls /etc/stratio

    export SPRING_DATASOURCE_URL="${POSTGRES_URL}?prepareThreshold=0&sslcert=${POSTGRES_CRT}&sslrootcert=${CA_BUNDLE_CRT}&sslkey=${POSTGRES_KEY}"
    INFO "  - SPRING_DATASOURCE_URL:  "
    INFO "    - ${SPRING_DATASOURCE_URL}"



    getCert "userland" \
                "/gts/transactions/${MARATHON_SERVICE_NAME}.transactions.gts" \
                "${MARATHON_SERVICE_NAME}_transactions_gts" \
                "JKS" \
                "/etc/stratio" \
    && INFO "OK"   \
    ||  INFO "Error"

    CERTIFICATE_VAR_PASS=${MARATHON_SERVICE_NAME//-/_}"_transactions_gts_keystore"
    CERTIFICATE_VAR_PASS=${CERTIFICATE_VAR_PASS^^}

    export CERTIFICATE_KEYSTORE_PASSWORD_VARIABLE=${!CERTIFICATE_VAR_PASS}
    export SPRING_KAFKA_PROPERTIES_SSL_KEYSTORE_PASSWORD=${CERTIFICATE_KEYSTORE_PASSWORD_VARIABLE}
    export SPRING_KAFKA_PROPERTIES_SSL_KEYPASSWORD=${CERTIFICATE_KEYSTORE_PASSWORD_VARIABLE}
    export SPRING_KAFKA_PROPERTIES_SSL_KEYSTORE_LOCATION=/etc/stratio/kafka.pkcs12
    export SPRING_KAFKA_PROPERTIES_SSL_KEYSTORE_TYPE=PKCS12
    export SPRING_KAFKA_PROPERTIES_SECURITY_PROTOCOL=SSL

    openssl pkcs12 -export -out /etc/stratio/kafka.pkcs12 \
    -in /etc/stratio/"${MARATHON_SERVICE_NAME}_transactions_gts".pem \
    -inkey /etc/stratio/"${MARATHON_SERVICE_NAME}_transactions_gts".key \
    -passout pass:${SPRING_KAFKA_SSL_KEYSTORE_PASSWORD}



    getCAbundle "/data/resources" "PEM" \
    && INFO "OK: Getting ca-bundle" \
    || INFO "Error: Getting ca-bundle"

    ${JAVA_HOME}/bin/keytool -noprompt -import -storepass changeit -file /data/resources/ca-bundle.pem -cacerts -alias ca

    export SPRING_KAFKA_PROPERTIES_SSL_TRUSTSTORE_LOCATION=$JAVA_HOME/lib/security/cacerts
    export SPRING_KAFKA_SSL_TRUSTSTORE_PASSWORD=changeit


    HEAP_PERCENTAGE=${HEAP_PERCENTAGE:-"80"}
    JAVA_TOOL_OPTIONS=${JAVA_TOOL_OPTIONS:-"-XX:+UseG1GC -XX:MaxRAMPercentage=${HEAP_PERCENTAGE} -XshowSettings:vm"}

    JAVA_CMD="java -Djavax.net.ssl.keyStoreType=pkcs12 -Djavax.net.ssl.keyStore=${SPRING_KAFKA_PROPERTIES_SSL_KEYSTORE_LOCATION} -Djavax.net.ssl.trustStoreType=jks -Djavax.net.ssl.trustStore=${SPRING_KAFKA_PROPERTIES_SSL_TRUSTSTORE_LOCATION} -Djavax.net.ssl.keyStorePassword=${SPRING_KAFKA_PROPERTIES_SSL_KEYSTORE_PASSWORD} -Djavax.net.ssl.trustStorePassword=${SPRING_KAFKA_SSL_PROPERTIES_TRUSTSTORE_PASSWORD} ${JAVA_TOOL_OPTIONS} -jar /data/app.jar ${JAVA_ARGS}"
    INFO ${JAVA_CMD}

    INFO
    INFO "Starting Spring Boot Service !"
    INFO

    ${JAVA_CMD}