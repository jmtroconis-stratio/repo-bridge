#!/bin/bash


    set -e

    source ${STRATIO_UTILS}/kms_utils.sh
    source ${STRATIO_UTILS}/b-log.sh

    DOCKER_LOG_LEVEL=${DOCKER_LOG_LEVEL:-DEBUG}
    eval LOG_LEVEL_${DOCKER_LOG_LEVEL}
    B_LOG --stdout true # enable logging over stdout

    export PORT0=${PORT0:-"8080"}
    export SPRING_KAFKA_BOOTSTRAP_SERVERS=${KAFKA_BROKERS}

    echo ${SPRING_KAFKA_BOOTSTRAP_SERVERS}

    RESOURCES_PATH=/etc/stratio

    declare -a VAULT_HOSTS
    IFS_OLD=$IFS
    IFS=',' read -r -a VAULT_HOSTS <<< "$VAULT_HOST"

    declare -a MARATHON_ARRAY
    OLD_IFS=$IFS
    IFS='/' read -r -a MARATHON_ARRAY <<< "$MARATHON_APP_ID"
    IFS=$OLD_IFS

	## export workaround_CERT_instead_of_vault="/gts/transactions/${MARATHON_SERVICE_NAME}.transactions.gts"

    INFO "Trying to login in Vault"
    # Approle login from role_id, secret_id
    if [ "xxx$VAULT_TOKEN" == "xxx" ];
    then
       INFO "Login in vault..."
       login
       if [[ ${code} -ne 0 ]];
       then
           ERROR "  - Something went wrong log in in vault. Exiting..."
           return ${code}
       fi
    fi
    INFO "  - Logged!"

    INFO "  - Retrieving service certificate [PEM] from: ${VAULT_PATH}/${MARATHON_SERVICE_NAME} "
    getCert "userland" \
                "${VAULT_PATH}" \
                "${MARATHON_SERVICE_NAME}" \
                "PEM" \
                "${RESOURCES_PATH}" \
    && INFO "OK!" \
    || (ERROR "Could not retrieve certificate in PEM format" && exit 1)

    INFO "  - [${RESOURCES_PATH}] directory:"
    ls ${RESOURCES_PATH}
    #cat ${RESOURCES_PATH}/${MARATHON_SERVICE_NAME}.pem

    INFO "Postgres connection config start"
    export SPRING_DATASOURCE_USERNAME="${MARATHON_SERVICE_NAME}_transactions_gts"

    # Change format of certificate for postgre SSL connection
    export POSTGRES_CRT="${RESOURCES_PATH}/${MARATHON_SERVICE_NAME}.crt"
    openssl x509 -outform der -in ${RESOURCES_PATH}/${MARATHON_SERVICE_NAME}.pem -out ${POSTGRES_CRT}

    INFO "  - Posgres certificate path ${POSTGRES_CERT}"

    # Get ca-bundle and include it in cacerts
    INFO "Getting Ca-Bundle..."
    getCAbundle "${RESOURCES_PATH}" "PEM" \
    && INFO "OK!"   \
    || (ERROR "Could not retrieve the CA-Bundle" && exit 1)

    # Change format of certificate for postgre SSL connection
    export CA_BUNDLE_CRT="${RESOURCES_PATH}/ca-bundle.crt"
    openssl x509 -outform der -in ${RESOURCES_PATH}/ca-bundle.pem -out ${CA_BUNDLE_CRT}

    INFO "  - [${RESOURCES_PATH}] directory:"
    ls ${RESOURCES_PATH}

     # export CA_BUNDLE_PEM="${RESOURCES_PATH}/ca-bundle.pem"
     # export POSTGRES_KEY="${RESOURCES_PATH}/key.pkcs8"
     export POSTGRES_KEY="${RESOURCES_PATH}/key.pk8"

    openssl pkcs8 -topk8 -inform pem -in ${RESOURCES_PATH}/${MARATHON_SERVICE_NAME}.key -outform der -nocrypt -out ${POSTGRES_KEY}

    export SPRING_DATASOURCE_URL="${POSTGRES_URL}?prepareThreshold=0&sslcert=${POSTGRES_CRT}&sslrootcert=${CA_BUNDLE_CRT}&sslkey=${POSTGRES_KEY}"
    INFO "  - SPRING_DATASOURCE_URL:  "
    INFO "    - ${SPRING_DATASOURCE_URL}"

    #### Server certificate ####
    INFO "Getting service certificate"
    getCert "userland" \
           "${VAULT_PATH}" \
           "${MARATHON_SERVICE_NAME}" \
            "JKS" \
            "${RESOURCES_PATH}" \
    && INFO "OK: Getting ${MARATHON_SERVICE_NAME} certificate"   \
    || (ERROR  "Could not retrieve ${MARATHON_SERVICE_NAME} certificate" && exit 1)

    INFO "  - [${RESOURCES_PATH}] directory:"
    ls ${RESOURCES_PATH}

    CERTIFICATE_VAR_PASS=${MARATHON_SERVICE_NAME//-/_}"_transactions_gts_keystore"
    CERTIFICATE_VAR_PASS=${CERTIFICATE_VAR_PASS^^}

    export CERTIFICATE_KEYSTORE_PASSWORD_VARIABLE=${!CERTIFICATE_VAR_PASS}
    export SPRING_KAFKA_PROPERTIES_SSL_KEYSTORE_PASSWORD=${CERTIFICATE_KEYSTORE_PASSWORD_VARIABLE}
    export SPRING_KAFKA_PROPERTIES_SSL_KEYPASSWORD=${CERTIFICATE_KEYSTORE_PASSWORD_VARIABLE}
    export SPRING_KAFKA_PROPERTIES_SSL_KEYSTORE_LOCATION=${RESOURCES_PATH}/kafka.pkcs12
    export SPRING_KAFKA_PROPERTIES_SSL_KEYSTORE_TYPE=PKCS12
    export SPRING_KAFKA_PROPERTIES_SECURITY_PROTOCOL=SSL

    openssl pkcs12 -export -out ${SPRING_KAFKA_PROPERTIES_SSL_KEYSTORE_LOCATION} \
    -in "${RESOURCES_PATH}/${MARATHON_SERVICE_NAME}".pem \
    -inkey "${RESOURCES_PATH}/${MARATHON_SERVICE_NAME}".key \
    -passout pass:${SPRING_KAFKA_PROPERTIES_SSL_KEYSTORE_PASSWORD}

    getCAbundle "/data/resources" "PEM" \
    && INFO "OK: Getting ca-bundle" \
    || INFO "Error: Getting ca-bundle"

    INFO "  - [${RESOURCES_PATH}] directory:"
    ls ${RESOURCES_PATH}

    ${JAVA_HOME}/bin/keytool -noprompt -import -storepass changeit -file /data/resources/ca-bundle.pem -cacerts -alias ca

    export SPRING_KAFKA_PROPERTIES_SSL_TRUSTSTORE_LOCATION=${JAVA_HOME}/lib/security/cacerts
    export SPRING_KAFKA_PROPERTIES_SSL_TRUSTSTORE_PASSWORD=changeit

    INFO "  - [${RESOURCES_PATH}] directory:"
    ls ${RESOURCES_PATH}

    export JAVA_ARGS="--server.port=${PORT0}"

    HEAP_PERCENTAGE=${HEAP_PERCENTAGE:-"80"}
    JAVA_TOOL_OPTIONS=${JAVA_TOOL_OPTIONS:-"-XX:+UseG1GC -XX:MaxRAMPercentage=${HEAP_PERCENTAGE} -XshowSettings:vm"}

    JAVA_CMD="java -Djavax.net.ssl.keyStoreType=pkcs12 -Djavax.net.ssl.keyStore=${SPRING_KAFKA_PROPERTIES_SSL_KEYSTORE_LOCATION} -Djavax.net.ssl.trustStoreType=jks -Djavax.net.ssl.trustStore=${SPRING_KAFKA_PROPERTIES_SSL_TRUSTSTORE_LOCATION} -Djavax.net.ssl.keyStorePassword=${SPRING_KAFKA_PROPERTIES_SSL_KEYSTORE_PASSWORD} -Djavax.net.ssl.trustStorePassword=${SPRING_KAFKA_PROPERTIES_SSL_TRUSTSTORE_PASSWORD} ${JAVA_TOOL_OPTIONS} -jar /data/app.jar ${JAVA_ARGS}"
    INFO ${JAVA_CMD}

    INFO
    INFO "Starting Spring Boot Service !"
    INFO

    ${JAVA_CMD}