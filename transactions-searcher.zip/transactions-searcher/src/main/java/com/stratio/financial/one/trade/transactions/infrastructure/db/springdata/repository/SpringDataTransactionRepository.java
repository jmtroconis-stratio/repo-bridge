package com.stratio.financial.one.trade.transactions.infrastructure.db.springdata.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;
import com.stratio.financial.one.trade.transactions.domain.sql.TransactionId;

@Repository
public interface SpringDataTransactionRepository extends CrudRepository<Transaction, TransactionId> {

  Optional<Transaction> findFirstByTransactionIdTransactionConsolidatedAndTransactionIdAccountIdAndTransactionIdCountryOrderByProcessedDateDesc(
      Boolean consolidated, String accountId, String country);

}
