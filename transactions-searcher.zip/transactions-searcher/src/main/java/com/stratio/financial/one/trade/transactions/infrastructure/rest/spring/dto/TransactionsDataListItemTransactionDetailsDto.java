package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsDataListItemTransactionDetailsAmountDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsDataListItemTransactionDetailsOperationDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsDataListItemTransactionDetailsReferencesDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TransactionsDataListItemTransactionDetailsDto
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-14T15:45:20.224+02:00")

public class TransactionsDataListItemTransactionDetailsDto   {
  @JsonProperty("transactionId")
  private String transactionId = null;

  @JsonProperty("creationDate")
  private String creationDate = null;

  @JsonProperty("processedDate")
  private String processedDate = null;

  @JsonProperty("accountingDate")
  private String accountingDate = null;

  @JsonProperty("description")
  private String description = null;

  @JsonProperty("transactionType")
  private String transactionType = null;

  @JsonProperty("transactionCategory")
  private String transactionCategory = null;

  @JsonProperty("transactionConsolidated")
  private Boolean transactionConsolidated = null;

  @JsonProperty("amount")
  private TransactionsDataListItemTransactionDetailsAmountDto amount = null;

  @JsonProperty("balanceResult")
  private TransactionsDataListItemTransactionDetailsAmountDto balanceResult = null;

  @JsonProperty("references")
  private TransactionsDataListItemTransactionDetailsReferencesDto references = null;

  @JsonProperty("operation")
  private TransactionsDataListItemTransactionDetailsOperationDto operation = null;

  public TransactionsDataListItemTransactionDetailsDto transactionId(String transactionId) {
    this.transactionId = transactionId;
    return this;
  }

   /**
   * Get transactionId
   * @return transactionId
  **/
  @ApiModelProperty(value = "")


  public String getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(String transactionId) {
    this.transactionId = transactionId;
  }

  public TransactionsDataListItemTransactionDetailsDto creationDate(String creationDate) {
    this.creationDate = creationDate;
    return this;
  }

   /**
   * Get creationDate
   * @return creationDate
  **/
  @ApiModelProperty(value = "")


  public String getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(String creationDate) {
    this.creationDate = creationDate;
  }

  public TransactionsDataListItemTransactionDetailsDto processedDate(String processedDate) {
    this.processedDate = processedDate;
    return this;
  }

   /**
   * Get processedDate
   * @return processedDate
  **/
  @ApiModelProperty(value = "")


  public String getProcessedDate() {
    return processedDate;
  }

  public void setProcessedDate(String processedDate) {
    this.processedDate = processedDate;
  }

  public TransactionsDataListItemTransactionDetailsDto accountingDate(String accountingDate) {
    this.accountingDate = accountingDate;
    return this;
  }

   /**
   * Get accountingDate
   * @return accountingDate
  **/
  @ApiModelProperty(value = "")


  public String getAccountingDate() {
    return accountingDate;
  }

  public void setAccountingDate(String accountingDate) {
    this.accountingDate = accountingDate;
  }

  public TransactionsDataListItemTransactionDetailsDto description(String description) {
    this.description = description;
    return this;
  }

   /**
   * Get description
   * @return description
  **/
  @ApiModelProperty(value = "")


  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public TransactionsDataListItemTransactionDetailsDto transactionType(String transactionType) {
    this.transactionType = transactionType;
    return this;
  }

   /**
   * Get transactionType
   * @return transactionType
  **/
  @ApiModelProperty(value = "")


  public String getTransactionType() {
    return transactionType;
  }

  public void setTransactionType(String transactionType) {
    this.transactionType = transactionType;
  }

  public TransactionsDataListItemTransactionDetailsDto transactionCategory(String transactionCategory) {
    this.transactionCategory = transactionCategory;
    return this;
  }

   /**
   * Get transactionCategory
   * @return transactionCategory
  **/
  @ApiModelProperty(value = "")


  public String getTransactionCategory() {
    return transactionCategory;
  }

  public void setTransactionCategory(String transactionCategory) {
    this.transactionCategory = transactionCategory;
  }

  public TransactionsDataListItemTransactionDetailsDto transactionConsolidated(Boolean transactionConsolidated) {
    this.transactionConsolidated = transactionConsolidated;
    return this;
  }

   /**
   * Get transactionConsolidated
   * @return transactionConsolidated
  **/
  @ApiModelProperty(value = "")


  public Boolean getTransactionConsolidated() {
    return transactionConsolidated;
  }

  public void setTransactionConsolidated(Boolean transactionConsolidated) {
    this.transactionConsolidated = transactionConsolidated;
  }

  public TransactionsDataListItemTransactionDetailsDto amount(TransactionsDataListItemTransactionDetailsAmountDto amount) {
    this.amount = amount;
    return this;
  }

   /**
   * Get amount
   * @return amount
  **/
  @ApiModelProperty(value = "")

  @Valid

  public TransactionsDataListItemTransactionDetailsAmountDto getAmount() {
    return amount;
  }

  public void setAmount(TransactionsDataListItemTransactionDetailsAmountDto amount) {
    this.amount = amount;
  }

  public TransactionsDataListItemTransactionDetailsDto balanceResult(TransactionsDataListItemTransactionDetailsAmountDto balanceResult) {
    this.balanceResult = balanceResult;
    return this;
  }

   /**
   * Get balanceResult
   * @return balanceResult
  **/
  @ApiModelProperty(value = "")

  @Valid

  public TransactionsDataListItemTransactionDetailsAmountDto getBalanceResult() {
    return balanceResult;
  }

  public void setBalanceResult(TransactionsDataListItemTransactionDetailsAmountDto balanceResult) {
    this.balanceResult = balanceResult;
  }

  public TransactionsDataListItemTransactionDetailsDto references(TransactionsDataListItemTransactionDetailsReferencesDto references) {
    this.references = references;
    return this;
  }

   /**
   * Get references
   * @return references
  **/
  @ApiModelProperty(value = "")

  @Valid

  public TransactionsDataListItemTransactionDetailsReferencesDto getReferences() {
    return references;
  }

  public void setReferences(TransactionsDataListItemTransactionDetailsReferencesDto references) {
    this.references = references;
  }

  public TransactionsDataListItemTransactionDetailsDto operation(TransactionsDataListItemTransactionDetailsOperationDto operation) {
    this.operation = operation;
    return this;
  }

   /**
   * Get operation
   * @return operation
  **/
  @ApiModelProperty(value = "")

  @Valid

  public TransactionsDataListItemTransactionDetailsOperationDto getOperation() {
    return operation;
  }

  public void setOperation(TransactionsDataListItemTransactionDetailsOperationDto operation) {
    this.operation = operation;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TransactionsDataListItemTransactionDetailsDto transactionsDataListItemTransactionDetails = (TransactionsDataListItemTransactionDetailsDto) o;
    return Objects.equals(this.transactionId, transactionsDataListItemTransactionDetails.transactionId) &&
        Objects.equals(this.creationDate, transactionsDataListItemTransactionDetails.creationDate) &&
        Objects.equals(this.processedDate, transactionsDataListItemTransactionDetails.processedDate) &&
        Objects.equals(this.accountingDate, transactionsDataListItemTransactionDetails.accountingDate) &&
        Objects.equals(this.description, transactionsDataListItemTransactionDetails.description) &&
        Objects.equals(this.transactionType, transactionsDataListItemTransactionDetails.transactionType) &&
        Objects.equals(this.transactionCategory, transactionsDataListItemTransactionDetails.transactionCategory) &&
        Objects.equals(this.transactionConsolidated, transactionsDataListItemTransactionDetails.transactionConsolidated) &&
        Objects.equals(this.amount, transactionsDataListItemTransactionDetails.amount) &&
        Objects.equals(this.balanceResult, transactionsDataListItemTransactionDetails.balanceResult) &&
        Objects.equals(this.references, transactionsDataListItemTransactionDetails.references) &&
        Objects.equals(this.operation, transactionsDataListItemTransactionDetails.operation);
  }

  @Override
  public int hashCode() {
    return Objects.hash(transactionId, creationDate, processedDate, accountingDate, description, transactionType, transactionCategory, transactionConsolidated, amount, balanceResult, references, operation);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TransactionsDataListItemTransactionDetailsDto {\n");
    
    sb.append("    transactionId: ").append(toIndentedString(transactionId)).append("\n");
    sb.append("    creationDate: ").append(toIndentedString(creationDate)).append("\n");
    sb.append("    processedDate: ").append(toIndentedString(processedDate)).append("\n");
    sb.append("    accountingDate: ").append(toIndentedString(accountingDate)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    transactionType: ").append(toIndentedString(transactionType)).append("\n");
    sb.append("    transactionCategory: ").append(toIndentedString(transactionCategory)).append("\n");
    sb.append("    transactionConsolidated: ").append(toIndentedString(transactionConsolidated)).append("\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    balanceResult: ").append(toIndentedString(balanceResult)).append("\n");
    sb.append("    references: ").append(toIndentedString(references)).append("\n");
    sb.append("    operation: ").append(toIndentedString(operation)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

