package com.stratio.financial.one.trade.transactions.domain.sql;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
@NoArgsConstructor
@Entity
@Table(name = "country")
public class Country {

  @Id
  @Column(name = "country_id")
  private String countryId;

  @OneToMany(targetEntity = Agent.class, mappedBy = "country")
  @JsonIgnore
  private List<Agent> agents;
}
