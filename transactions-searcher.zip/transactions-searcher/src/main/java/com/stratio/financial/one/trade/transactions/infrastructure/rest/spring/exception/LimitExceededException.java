package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


@ResponseStatus(value = HttpStatus.PRECONDITION_FAILED)
public class LimitExceededException extends RuntimeException {

  public LimitExceededException() {
    super("The limit of documents to be returned has been reached");
  }

  public LimitExceededException(String s) {
    super(s);
  }


}