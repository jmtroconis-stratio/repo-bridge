package com.stratio.financial.one.trade.transactions.domain.data;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class TransactionCompanyAccountData {
  private String accountId;
  private String country;
  private String entity;
  private String displayNumber;
  private String agent;
  private String alias;
  private String accountIdType;
  private String iban;
}
