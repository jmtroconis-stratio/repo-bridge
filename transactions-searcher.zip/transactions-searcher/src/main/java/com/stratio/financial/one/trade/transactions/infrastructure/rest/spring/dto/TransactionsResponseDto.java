package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionResponseDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsResponseDocumentsDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TransactionsResponseDto
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-14T15:45:20.224+02:00")

public class TransactionsResponseDto   {
  @JsonProperty("documents")
  private TransactionsResponseDocumentsDto documents = null;

  @JsonProperty("transactionsListResponse")
  private List<TransactionResponseDto> transactionsListResponse = null;

  public TransactionsResponseDto documents(TransactionsResponseDocumentsDto documents) {
    this.documents = documents;
    return this;
  }

   /**
   * Get documents
   * @return documents
  **/
  @ApiModelProperty(value = "")

  @Valid

  public TransactionsResponseDocumentsDto getDocuments() {
    return documents;
  }

  public void setDocuments(TransactionsResponseDocumentsDto documents) {
    this.documents = documents;
  }

  public TransactionsResponseDto transactionsListResponse(List<TransactionResponseDto> transactionsListResponse) {
    this.transactionsListResponse = transactionsListResponse;
    return this;
  }

  public TransactionsResponseDto addTransactionsListResponseItem(TransactionResponseDto transactionsListResponseItem) {
    if (this.transactionsListResponse == null) {
      this.transactionsListResponse = new ArrayList<TransactionResponseDto>();
    }
    this.transactionsListResponse.add(transactionsListResponseItem);
    return this;
  }

   /**
   * Get transactionsListResponse
   * @return transactionsListResponse
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<TransactionResponseDto> getTransactionsListResponse() {
    return transactionsListResponse;
  }

  public void setTransactionsListResponse(List<TransactionResponseDto> transactionsListResponse) {
    this.transactionsListResponse = transactionsListResponse;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TransactionsResponseDto transactionsResponse = (TransactionsResponseDto) o;
    return Objects.equals(this.documents, transactionsResponse.documents) &&
        Objects.equals(this.transactionsListResponse, transactionsResponse.transactionsListResponse);
  }

  @Override
  public int hashCode() {
    return Objects.hash(documents, transactionsListResponse);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TransactionsResponseDto {\n");
    
    sb.append("    documents: ").append(toIndentedString(documents)).append("\n");
    sb.append("    transactionsListResponse: ").append(toIndentedString(transactionsListResponse)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

