package com.stratio.financial.one.trade.transactions.infrastructure.es;

import org.springframework.http.client.ClientHttpResponse;

public class RestTemplateException extends RuntimeException {
  private static final long serialVersionUID = 1L;
  private ClientHttpResponse response;

  public RestTemplateException(ClientHttpResponse response) {
    this.response = response;
  }

  public ClientHttpResponse getResponse() {
    return response;
  }
}