package com.stratio.financial.one.trade.transactions.application.repository;

import java.util.List;
import java.util.Optional;

import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;

public interface TransactionRepository {

  void deleteAll(List<Transaction> transactions);

  Optional<Transaction> findLastConsolidated(Boolean consolidated, String accountId, String country);

}