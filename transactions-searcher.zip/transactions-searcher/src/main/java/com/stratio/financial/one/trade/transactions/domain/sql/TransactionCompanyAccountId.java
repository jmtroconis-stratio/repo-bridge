package com.stratio.financial.one.trade.transactions.domain.sql;

import javax.persistence.Embeddable;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Embeddable
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class TransactionCompanyAccountId implements Serializable {

  private String accountId;

  private String country;
}
