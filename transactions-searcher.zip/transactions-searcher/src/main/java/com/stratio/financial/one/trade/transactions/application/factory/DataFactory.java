package com.stratio.financial.one.trade.transactions.application.factory;

import java.math.BigDecimal;
import java.util.ArrayList;

import com.stratio.financial.one.trade.transactions.domain.data.DocumentsData;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionSummaryData;
import com.stratio.financial.one.trade.transactions.domain.search.AccountsCountry;
import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;
import com.stratio.financial.one.trade.transactions.domain.sql.TransactionId;

public class DataFactory {

  public static TransactionSummaryData createTransactionSummaryData() {
    TransactionSummaryData transactionSummaryData = new TransactionSummaryData();

    DocumentsData documentsData = new DocumentsData();
    documentsData.setRetrieved(BigDecimal.ZERO);
    documentsData.setTotalRegistersFound(BigDecimal.ZERO);

    transactionSummaryData.setTransactions(new ArrayList<>());
    transactionSummaryData.setDocuments(documentsData);

    return transactionSummaryData;
  }

  public static Transaction createTransaction(AccountsCountry accountsCountry) {
    TransactionId transactionId = TransactionId.builder()
        .accountId(accountsCountry.getAccount().getAccountId())
        .country(accountsCountry.getCountry())
        .build();

    Transaction transaction = new Transaction();
    transaction.setTransactionId(transactionId);

    return transaction;
  }
}
