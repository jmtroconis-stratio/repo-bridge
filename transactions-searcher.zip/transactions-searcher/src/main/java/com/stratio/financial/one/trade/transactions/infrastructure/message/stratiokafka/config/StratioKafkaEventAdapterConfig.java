package com.stratio.financial.one.trade.transactions.infrastructure.message.stratiokafka.config;

import javax.persistence.EntityManagerFactory;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.kafka.transaction.ChainedKafkaTransactionManager;
import org.springframework.kafka.transaction.KafkaTransactionManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.AbstractPlatformTransactionManager;

@Configuration
@RequiredArgsConstructor
public class StratioKafkaEventAdapterConfig {

  private final KafkaTransactionManager<Object, Object> kafkaTransactionManager;

  private final EntityManagerFactory entityManagerFactory;

  @Bean("transactionManager")
  public JpaTransactionManager customJpaTransactionManager(EntityManagerFactory entityManagerFactory) {
    return new JpaTransactionManager(entityManagerFactory);
  }

  @Bean
  @Primary
  public PlatformTransactionManager chainedTransactionManager(
      JpaTransactionManager customJpaTransactionManager,
      KafkaTransactionManager<Object, Object> kafkaTransactionManager) {

    kafkaTransactionManager.setTransactionSynchronization(AbstractPlatformTransactionManager.SYNCHRONIZATION_ALWAYS);

    return new ChainedKafkaTransactionManager<>(kafkaTransactionManager, customJpaTransactionManager);
  }

}
