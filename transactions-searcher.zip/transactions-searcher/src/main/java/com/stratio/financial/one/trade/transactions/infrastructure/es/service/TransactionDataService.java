package com.stratio.financial.one.trade.transactions.infrastructure.es.service;

import java.util.List;

import com.stratio.financial.one.trade.transactions.domain.data.TransactionData;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionSummaryData;

public interface TransactionDataService {

  void save(TransactionSummaryData transactionDataList);

  void delete(List<TransactionData> transactionDataList);

  TransactionSummaryData searchToDate(String date, Integer size, Boolean consolidated);

  void deleteOldNotConsolidated(String dateTo, int size);
}
