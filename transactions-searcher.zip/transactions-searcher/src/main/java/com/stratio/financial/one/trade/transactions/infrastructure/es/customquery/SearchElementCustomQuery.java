package com.stratio.financial.one.trade.transactions.infrastructure.es.customquery;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SearchElementCustomQuery {

  private String description;
  private String transactionClientReference;
  private AccountCountry accountCountry;
  private Range processedDate;
  private Range transactionAmountFrom;
  private Range transactionAmountTo;
  private List<SwiftCode> swiftCodes;
  private List<TransactionType> transactionTypes;
  private String transactionConsolidated;

  private String processedDateFrom;

  private String orderField;
  private String orderDescAsc;

}
