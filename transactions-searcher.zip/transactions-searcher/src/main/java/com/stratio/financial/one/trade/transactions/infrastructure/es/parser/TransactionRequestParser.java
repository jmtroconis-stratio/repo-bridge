package com.stratio.financial.one.trade.transactions.infrastructure.es.parser;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.stratio.financial.one.trade.transactions.domain.search.AccountsCountry;
import com.stratio.financial.one.trade.transactions.domain.search.RequestQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.Clause;
import com.stratio.financial.one.trade.transactions.infrastructure.es.Condition;
import com.stratio.financial.one.trade.transactions.infrastructure.es.ElasticQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.Filter;
import com.stratio.financial.one.trade.transactions.infrastructure.es.Sort;
import org.springframework.stereotype.Component;

@Component
public class TransactionRequestParser {

  private static final String OR = "or";
  private static final String AND = "and";
  private static final String FILTER = "filter";
  private static final String GTE = "gte";
  private static final String LTE = "lte";
  private static final String GT = "gt";
  private static final String LT = "lt";

  private void addSimpleClauses(Filter filter, Object value, String field) {
    addSimpleClauses(filter.getClauses(), value, field);
  }

  private void addSimpleClauses(List<Clause> clauses, Object value, String field) {
    if (value != null) {
      Clause clause = new Clause();
      clause.setType(FILTER);
      Condition condition = new Condition();
      condition.setField(field);
      condition.setValues(List.of(value));
      clause.setCondition(condition);
      clauses.add(clause);
    }
  }

  private void addSimpleClauses(List<Clause> clauses, Condition condition) {
    if (condition != null) {
      Clause clause = new Clause();
      clause.setType(FILTER);
      clause.setCondition(condition);

      clauses.add(clause);
    }
  }

  private void addRangeClausesIncludeEqual(Filter filter, Object from, Object to, String field) {
    addRangeClauses(filter, from, to, field, GTE, LTE);
  }

  private void addRangeClausesNotIncludeEqual(Filter filter, Object from, Object to, String field) {
    addRangeClauses(filter, from, to, field, GT, LT);
  }

  private void addRangeClauses(Filter filter, Object from, Object to, String field,
                               String comparationFrom, String comparationTo) {
    boolean addClause = false;
    Condition condition = new Condition();
    condition.setField(field);

    if (from != null) {
      addClause = true;
      condition.getRange().put(comparationFrom, from);
    }

    if (to != null) {
      addClause = true;
      condition.getRange().put(comparationTo, to);
    }

    if (addClause) {
      Clause transactionAmountClause = new Clause();
      transactionAmountClause.setType(FILTER);
      transactionAmountClause.setCondition(condition);
      filter.getClauses().add(transactionAmountClause);
    }
  }

  private void addRangeClausesOr(Filter filter, Object from, Object to, String field) {
    Clause transactionAmountClauseOr = new Clause();
    transactionAmountClauseOr.setType(OR);
    List<Clause> clausesForOr = new ArrayList<>(2);

    boolean addClause = false;

    if (from != null) {
      addClause = true;

      Condition condition = createConditionRange(field, GTE, from);
      addSimpleClauses(clausesForOr, condition);
    }

    if (to != null) {
      addClause = true;

      Condition condition = createConditionRange(field, LTE, to);
      addSimpleClauses(clausesForOr, condition);
    }

    if (addClause) {
      transactionAmountClauseOr.setClauses(clausesForOr);
      filter.getClauses().add(transactionAmountClauseOr);
    }
  }

  private void addClausesOr(Filter filter, List<Object> values, String field) {
    if (values != null && !values.isEmpty()) {
      Clause transactionAmountClauseOr = new Clause();
      transactionAmountClauseOr.setType(OR);
      List<Clause> clausesForOr = new ArrayList<>();

      values.stream().filter(Objects::nonNull).forEach(value -> addSimpleClauses(clausesForOr, value, field));

      if (!clausesForOr.isEmpty()) {
        transactionAmountClauseOr.setClauses(clausesForOr);
        filter.getClauses().add(transactionAmountClauseOr);
      }
    }
  }

  private Condition createConditionRange(String field, String symbol, Object value) {
    Condition condition = new Condition();
    condition.setField(field);
    condition.getRange().put(symbol, value);
    return condition;
  }

  private void addRangeToDateClause(Filter filter, Object to, String field) {
    if (to != null) {
      Condition condition = new Condition();
      condition.setField(field);
      condition.getRange().put(LTE, to);
      Clause transactionAmountClause = new Clause();
      transactionAmountClause.setType(FILTER);
      transactionAmountClause.setCondition(condition);
      filter.getClauses().add(transactionAmountClause);
    }
  }

  private void addAccountClauses(Filter filter, List<AccountsCountry> accounts) {
    Clause clauses = new Clause();
    clauses.setType(OR);
    List<Clause> clauseListOr = new ArrayList<>();
    for (AccountsCountry accountsCountry : accounts) {
      Clause clausesAnd = new Clause();
      clausesAnd.setType(AND);
      List<Clause> clauseListAnd = new ArrayList<>();
      addSimpleClauses(clauseListAnd, accountsCountry.getAccount().getAccountId(),
          "transactionCompanyAccount.accountId");
      addSimpleClauses(clauseListAnd, accountsCountry.getAccount().getAccountIdType(),
          "transactionCompanyAccount.accountIdType");
      addSimpleClauses(clauseListAnd, accountsCountry.getCountry(),
          "transactionCompanyAccount.country");
      clausesAnd.setClauses(clauseListAnd);
      clauseListOr.add(clausesAnd);
    }
    clauses.setClauses(clauseListOr);
    filter.getClauses().add(clauses);
  }

  public ElasticQuery parse(RequestQuery requestQuery, Boolean consolidated, String processedDate) {
    ElasticQuery elasticQuery = new ElasticQuery();
    elasticQuery.setSize(requestQuery.getLimit());
    elasticQuery.setFrom(requestQuery.getFrom());
    Filter filter = new Filter();
    filter.setType(AND);

    addAccountClauses(filter, requestQuery.getAccountsCountriesList());
    addRangeClausesIncludeEqual(
        filter, requestQuery.getFromDate(), requestQuery.getToDate(),
        "processedDate"
    );
    addRangeClausesOr(
        filter,
        requestQuery.getFromAmount() != null ? Math.abs(requestQuery.getFromAmount()) : null,
        requestQuery.getFromAmount() != null ? -Math.abs(requestQuery.getFromAmount()) : null,
        "transactionAmount"
    );
    addRangeClausesIncludeEqual(
        filter,
        requestQuery.getToAmount() != null ? -Math.abs(requestQuery.getToAmount()) : null,
        requestQuery.getToAmount() != null ? Math.abs(requestQuery.getToAmount()) : null,
        "transactionAmount"
    );

    if (requestQuery.getSwiftCodes() != null) {
      addClausesOr(filter, new ArrayList<>(requestQuery.getSwiftCodes()), "swiftCode");
    }

    addSimpleClauses(filter, requestQuery.getTransactionType(), "transactionType");
    addSimpleClauses(filter, consolidated, "transactionConsolidated");

    addRangeClausesNotIncludeEqual(
        filter,
        processedDate,
        null,
        "processedDate"
    );

    Sort sortByCreationDate = new Sort();
    sortByCreationDate.setField("processedDate");
    sortByCreationDate.setOrder("desc");
    elasticQuery.getSorts().add(sortByCreationDate);
    elasticQuery.setFilters(filter);
    return elasticQuery;
  }

  public ElasticQuery parseToDate(String date, Integer from, Integer size, Boolean consolidated) {
    ElasticQuery elasticQuery = new ElasticQuery();
    elasticQuery.setSize(size);
    elasticQuery.setFrom(from);
    Filter filter = new Filter();
    filter.setType(AND);

    addRangeToDateClause(
        filter, date,
        "creationDate"
    );

    addSimpleClauses(filter, consolidated, "transactionConsolidated");

    Sort sortByCreationDate = new Sort();
    sortByCreationDate.setField("creationDate");
    sortByCreationDate.setOrder("asc");
    elasticQuery.getSorts().add(sortByCreationDate);
    elasticQuery.setFilters(filter);
    return elasticQuery;
  }

}
