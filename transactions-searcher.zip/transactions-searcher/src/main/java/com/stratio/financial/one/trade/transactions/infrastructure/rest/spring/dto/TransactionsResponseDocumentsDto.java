package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TransactionsResponseDocumentsDto
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-14T15:45:20.224+02:00")

public class TransactionsResponseDocumentsDto   {
  @JsonProperty("totalRegistersFound")
  private BigDecimal totalRegistersFound = null;

  @JsonProperty("retrieved")
  private BigDecimal retrieved = null;

  public TransactionsResponseDocumentsDto totalRegistersFound(BigDecimal totalRegistersFound) {
    this.totalRegistersFound = totalRegistersFound;
    return this;
  }

   /**
   * Get totalRegistersFound
   * @return totalRegistersFound
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BigDecimal getTotalRegistersFound() {
    return totalRegistersFound;
  }

  public void setTotalRegistersFound(BigDecimal totalRegistersFound) {
    this.totalRegistersFound = totalRegistersFound;
  }

  public TransactionsResponseDocumentsDto retrieved(BigDecimal retrieved) {
    this.retrieved = retrieved;
    return this;
  }

   /**
   * Get retrieved
   * @return retrieved
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BigDecimal getRetrieved() {
    return retrieved;
  }

  public void setRetrieved(BigDecimal retrieved) {
    this.retrieved = retrieved;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TransactionsResponseDocumentsDto transactionsResponseDocuments = (TransactionsResponseDocumentsDto) o;
    return Objects.equals(this.totalRegistersFound, transactionsResponseDocuments.totalRegistersFound) &&
        Objects.equals(this.retrieved, transactionsResponseDocuments.retrieved);
  }

  @Override
  public int hashCode() {
    return Objects.hash(totalRegistersFound, retrieved);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TransactionsResponseDocumentsDto {\n");
    
    sb.append("    totalRegistersFound: ").append(toIndentedString(totalRegistersFound)).append("\n");
    sb.append("    retrieved: ").append(toIndentedString(retrieved)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

