package com.stratio.financial.one.trade.transactions.infrastructure.db.springdata.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import com.stratio.financial.one.trade.transactions.application.repository.TransactionRepository;
import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;

@Repository
public class CustomTransactionRepository extends CriteriaEntityRepository<Transaction>
    implements TransactionRepository {

  private final SpringDataTransactionRepository springDataTransactionRepository;

  public CustomTransactionRepository(EntityManager entityManager,
                                     SpringDataTransactionRepository springDataTransactionRepository) {
    super(entityManager);
    this.springDataTransactionRepository = springDataTransactionRepository;
  }

  @Override
  public void deleteAll(List<Transaction> transactions) {
    springDataTransactionRepository.deleteAll(transactions);
  }

  @Override
  public Optional<Transaction> findLastConsolidated(Boolean consolidated, String accountId, String country) {
    return springDataTransactionRepository.findFirstByTransactionIdTransactionConsolidatedAndTransactionIdAccountIdAndTransactionIdCountryOrderByProcessedDateDesc(
        consolidated, accountId, country);
  }

}
