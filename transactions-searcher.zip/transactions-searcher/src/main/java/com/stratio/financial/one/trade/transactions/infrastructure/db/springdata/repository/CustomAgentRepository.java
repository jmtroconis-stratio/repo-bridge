package com.stratio.financial.one.trade.transactions.infrastructure.db.springdata.repository;

import java.util.List;
import javax.persistence.EntityManager;

import com.stratio.financial.one.trade.transactions.application.repository.AgentRepository;
import com.stratio.financial.one.trade.transactions.domain.sql.Agent;
import org.springframework.stereotype.Repository;

@Repository
public class CustomAgentRepository extends CriteriaEntityRepository<Agent>
    implements AgentRepository {

  private final SpringDataAgentRepository springDataAgentRepository;

  public CustomAgentRepository(EntityManager entityManager,
      SpringDataAgentRepository springDataAgentRepository) {
    super(entityManager);
    this.springDataAgentRepository = springDataAgentRepository;
  }

  @Override
  public Agent saveAgent(Agent agent) {
    return springDataAgentRepository.save(agent);
  }

  @Override
  public List<Agent> findAllAgents(List<String> bicList) {
    return springDataAgentRepository.findByBicIn(bicList);
  }
}
