package com.stratio.financial.one.trade.transactions.domain.sql;

import javax.persistence.Embeddable;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
@Builder
@ToString
public class TransactionId implements Serializable {

  private String transactionId;
  private Boolean transactionConsolidated;
  private String accountId;
  private String country;
}