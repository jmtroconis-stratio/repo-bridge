package com.stratio.financial.one.trade.transactions.infrastructure.db.springdata.repository;

import java.util.List;

import com.stratio.financial.one.trade.transactions.domain.sql.Agent;
import org.springframework.data.repository.CrudRepository;

public interface SpringDataAgentRepository extends CrudRepository<Agent, String> {

  List<Agent> findByBicIn(List<String> bicList);
}
