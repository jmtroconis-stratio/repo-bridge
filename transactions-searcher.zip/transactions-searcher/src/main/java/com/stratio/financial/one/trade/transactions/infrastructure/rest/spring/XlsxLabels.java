package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum XlsxLabels {
  SUBSIDIARY("Subsidiary"),
  BANK("Bank"),
  BIC("BIC"),
  ALIAS(" Alias"),
  ACCOUNT("Account"),
  ACCOUNTING_DATE("Book date"),
  VALUE_DATE("Value date"),
  CATEGORY("Category"),
  AMOUNT("Amount"),
  CURRENCY("Currency"),
  CLIENT_REFERENCE("Client Reference"),
  BANK_REFERENCE("Bank Reference"),
  DESCRIPTION("Description");

  private final String en;
}
