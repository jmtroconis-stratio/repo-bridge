package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.resource;

import java.util.List;
import java.util.stream.Collectors;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.stratio.financial.one.trade.transactions.application.repository.TransactionDataRepository;
import com.stratio.financial.one.trade.transactions.application.service.AgentService;
import com.stratio.financial.one.trade.transactions.application.service.TransactionService;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionSummaryData;
import com.stratio.financial.one.trade.transactions.domain.search.AccountsCountriesList;
import com.stratio.financial.one.trade.transactions.domain.search.AccountsCountry;
import com.stratio.financial.one.trade.transactions.domain.search.RequestQuery;
import com.stratio.financial.one.trade.transactions.domain.sql.Agent;
import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;
import com.stratio.financial.one.trade.transactions.infrastructure.es.service.TransactionDataService;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.AccountsCountriesListDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.LastProcessedDateOutputDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.RequestQueryDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.RequestQueryXslxDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsResponseDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.mapper.TransactionMapper;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.spec.TransactionsApi;
import io.swagger.annotations.Api;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;

@RestController
@RequiredArgsConstructor
@Api(tags = {"transactions"})
@Log4j2
public class TransactionsApiResource implements TransactionsApi {

  private final AgentService agentService;
  private final TransactionService transactionService;
  private final TransactionDataService transactionDataService;
  private final TransactionDataRepository transactionDataRepository;
  private final TransactionMapper transactionMapper;

  @Override
  public ResponseEntity<TransactionsResponseDto> transactionsAccountsSearchPost(
      @RequestHeader(value = "X-B3-TraceId") String xB3TraceId,
      @RequestHeader(value = "X-B3-SpanId") String xB3SpanId,
      @RequestHeader(value = "X-B3-ParentSpanId") String xB3ParentSpanId,
      @RequestHeader(value = "X-B3-Sampled") String xB3Sampled,
      @Valid @RequestBody RequestQueryDto requestQueryDto) {
    TransactionSummaryData transactionsSummaryData = search(
        transactionMapper.requestQueryDtoToRequestQuery(requestQueryDto));
    TransactionsResponseDto transactionsResponseDto =
        transactionMapper.transactionsSummaryDataToTransactionsResponseDto(transactionsSummaryData);
    return new ResponseEntity<>(transactionsResponseDto, HttpStatus.OK);
  }

  @SneakyThrows
  @Override
  public ResponseEntity<Resource> transactionsAccountsSearchXslxPost(
      @RequestHeader(value = "X-B3-TraceId") String xB3TraceId,
      @RequestHeader(value = "X-B3-SpanId") String xB3SpanId,
      @RequestHeader(value = "X-B3-ParentSpanId") String xB3ParentSpanId,
      @RequestHeader(value = "X-B3-Sampled") String xB3Sampled,
      @Valid @RequestBody RequestQueryXslxDto requestQueryXslxDto) {
    TransactionSummaryData transactionsSummaryData = search(
        transactionMapper.requestQueryXlsxDtoToRequestQuery(requestQueryXslxDto));
    if (transactionsSummaryData == null || transactionsSummaryData.getTransactions() == null
        || transactionsSummaryData.getTransactions().isEmpty()) {
      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    List<Agent> agentList = agentService.findAllAgents(
        transactionsSummaryData.getTransactions().stream()
            .map(transactionData -> transactionData.getTransactionCompanyAccount().getAgent())
            .collect(
                Collectors.toList()));
    return new ResponseEntity<>(
        transactionMapper
            .transactionsSummaryDataToByteArrayResource(transactionsSummaryData, agentList,
                requestQueryXslxDto.getAccountsCountriesList()),
        HttpStatus.OK);
  }

  @Override
  public ResponseEntity<LastProcessedDateOutputDto> transactionsLastProcessedDatePost(
      @RequestHeader(value = "X-B3-TraceId") String xB3TraceId,
      @RequestHeader(value = "X-B3-SpanId") String xB3SpanId,
      @RequestHeader(value = "X-B3-ParentSpanId") String xB3ParentSpanId,
      @RequestHeader(value = "X-B3-Sampled") String xB3Sampled,
      @Valid @RequestBody AccountsCountriesListDto accountsCountriesListDto) {

    AccountsCountriesList accountsCountriesList =
        transactionMapper.accountsCountriesListDtoToAccountsCountriesList(accountsCountriesListDto);

    List<Transaction> transaction = transactionService
        .getLastTransactionsDateTime(accountsCountriesList);

    return ResponseEntity
        .ok(transactionMapper.transactionsToLastProcessedDateOutputDto(transaction));
  }

  @Override
  public ResponseEntity<Void> transactionsTocreationdateDateToOldNotConsolidatedDelete(
      @RequestHeader(value = "X-B3-TraceId") String xB3TraceId,
      @RequestHeader(value = "X-B3-SpanId") String xB3SpanId,
      @RequestHeader(value = "X-B3-ParentSpanId") String xB3ParentSpanId,
      @RequestHeader(value = "X-B3-Sampled") String xB3Sampled,
      @NotNull @PathVariable("dateTo") String dateTo,
      @RequestParam(value = "size") Integer size) {

    transactionDataService.deleteOldNotConsolidated(dateTo, size);
    return new ResponseEntity<>(HttpStatus.OK);
  }

  //FIXME move all this logic to TransactionService plus change RequestQueryDto to a specific object
  private TransactionSummaryData search(RequestQuery requestQuery) {

    TransactionSummaryData transactionsSummaryData;

    if (!requestQuery.getTypeOfTransaction()) {
      transactionsSummaryData = getTransactionSummaryDataTypeOfTransaction(requestQuery, false);
    } else {
      transactionsSummaryData = getTransactionSummaryDataTypeOfTransaction(requestQuery, true);
    }
    return transactionsSummaryData;
  }

  private TransactionSummaryData getTransactionSummaryDataTypeOfTransaction(
      RequestQuery requestQuery, boolean mustIncludeNotConsolidated) {

    requestQuery.getAccountsCountriesList().stream().forEach(accountsCountry -> {
      accountsCountry.setMustIncludeNotConsolidated(mustIncludeNotConsolidated);
      if (mustIncludeNotConsolidated) {
        String processedDate = getProcessedDateForNotConsolidated(accountsCountry);
        accountsCountry.setProcessedDateFrom(processedDate);
      }
    });

    return transactionDataRepository.search(requestQuery);
  }

  private String getProcessedDateForNotConsolidated(AccountsCountry accountsCountry) {
    AccountsCountriesList accountsCountriesList = new AccountsCountriesList();
    accountsCountriesList.add(accountsCountry);

    List<Transaction> transaction = transactionService.getLastTransactionsDateTime(accountsCountriesList);

    return transaction.size() == 1
        ? transactionMapper.instantToElasticFormatString(transaction.get(0).getProcessedDate()) : null;
  }
}
