package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * LastProcessedDatePerAccountDto
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-14T15:45:20.224+02:00")

public class LastProcessedDatePerAccountDto   {
  @JsonProperty("accountId")
  private String accountId = null;

  @JsonProperty("country")
  private String country = null;

  @JsonProperty("lastProcessedDate")
  private String lastProcessedDate = null;

  @JsonProperty("transactionId")
  private String transactionId = null;

  @JsonProperty("consolidated")
  private Boolean consolidated = null;

  public LastProcessedDatePerAccountDto accountId(String accountId) {
    this.accountId = accountId;
    return this;
  }

   /**
   * Get accountId
   * @return accountId
  **/
  @ApiModelProperty(value = "")


  public String getAccountId() {
    return accountId;
  }

  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  public LastProcessedDatePerAccountDto country(String country) {
    this.country = country;
    return this;
  }

   /**
   * Get country
   * @return country
  **/
  @ApiModelProperty(value = "")


  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public LastProcessedDatePerAccountDto lastProcessedDate(String lastProcessedDate) {
    this.lastProcessedDate = lastProcessedDate;
    return this;
  }

   /**
   * Get lastProcessedDate
   * @return lastProcessedDate
  **/
  @ApiModelProperty(value = "")


  public String getLastProcessedDate() {
    return lastProcessedDate;
  }

  public void setLastProcessedDate(String lastProcessedDate) {
    this.lastProcessedDate = lastProcessedDate;
  }

  public LastProcessedDatePerAccountDto transactionId(String transactionId) {
    this.transactionId = transactionId;
    return this;
  }

   /**
   * Get transactionId
   * @return transactionId
  **/
  @ApiModelProperty(value = "")


  public String getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(String transactionId) {
    this.transactionId = transactionId;
  }

  public LastProcessedDatePerAccountDto consolidated(Boolean consolidated) {
    this.consolidated = consolidated;
    return this;
  }

   /**
   * Get consolidated
   * @return consolidated
  **/
  @ApiModelProperty(value = "")


  public Boolean getConsolidated() {
    return consolidated;
  }

  public void setConsolidated(Boolean consolidated) {
    this.consolidated = consolidated;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LastProcessedDatePerAccountDto lastProcessedDatePerAccount = (LastProcessedDatePerAccountDto) o;
    return Objects.equals(this.accountId, lastProcessedDatePerAccount.accountId) &&
        Objects.equals(this.country, lastProcessedDatePerAccount.country) &&
        Objects.equals(this.lastProcessedDate, lastProcessedDatePerAccount.lastProcessedDate) &&
        Objects.equals(this.transactionId, lastProcessedDatePerAccount.transactionId) &&
        Objects.equals(this.consolidated, lastProcessedDatePerAccount.consolidated);
  }

  @Override
  public int hashCode() {
    return Objects.hash(accountId, country, lastProcessedDate, transactionId, consolidated);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LastProcessedDatePerAccountDto {\n");
    
    sb.append("    accountId: ").append(toIndentedString(accountId)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("    lastProcessedDate: ").append(toIndentedString(lastProcessedDate)).append("\n");
    sb.append("    transactionId: ").append(toIndentedString(transactionId)).append("\n");
    sb.append("    consolidated: ").append(toIndentedString(consolidated)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

