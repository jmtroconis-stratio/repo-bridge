package com.stratio.financial.one.trade.transactions.application.repository;

import java.util.List;

import com.stratio.financial.one.trade.transactions.domain.data.TransactionData;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionSummaryData;
import com.stratio.financial.one.trade.transactions.domain.search.RequestQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.RestTemplateException;

public interface TransactionDataRepository {

  void index(List<TransactionData> transactionDataList) throws RestTemplateException;

  void delete(List<TransactionData> transactionDataList) throws RestTemplateException;

  TransactionSummaryData search(RequestQuery requestQuery);

  TransactionSummaryData searchToDate(String date, Integer from, Integer size, Boolean consolidated);

}
