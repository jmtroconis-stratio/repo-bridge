package com.stratio.financial.one.trade.transactions.domain.data;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class TransactionSummaryData {
  private List<TransactionData> transactions;
  private DocumentsData documents;
}
