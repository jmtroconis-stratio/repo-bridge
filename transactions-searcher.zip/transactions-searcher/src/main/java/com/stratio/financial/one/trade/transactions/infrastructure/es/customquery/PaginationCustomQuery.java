package com.stratio.financial.one.trade.transactions.infrastructure.es.customquery;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
@Builder
@JsonRootName("pagination")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaginationCustomQuery {

  private Integer from;
  private Integer size;

}
