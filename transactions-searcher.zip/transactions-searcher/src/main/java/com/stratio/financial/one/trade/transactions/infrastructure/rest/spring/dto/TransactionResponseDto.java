package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionResponseAccountDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsDataListItemDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TransactionResponseDto
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-14T15:45:20.224+02:00")

public class TransactionResponseDto   {
  @JsonProperty("displayNumber")
  private String displayNumber = null;

  @JsonProperty("account")
  private TransactionResponseAccountDto account = null;

  @JsonProperty("alias")
  private String alias = null;

  @JsonProperty("country")
  private String country = null;

  @JsonProperty("agent")
  private String agent = null;

  @JsonProperty("transactionsDataList")
  private List<TransactionsDataListItemDto> transactionsDataList = null;

  public TransactionResponseDto displayNumber(String displayNumber) {
    this.displayNumber = displayNumber;
    return this;
  }

   /**
   * Get displayNumber
   * @return displayNumber
  **/
  @ApiModelProperty(value = "")


  public String getDisplayNumber() {
    return displayNumber;
  }

  public void setDisplayNumber(String displayNumber) {
    this.displayNumber = displayNumber;
  }

  public TransactionResponseDto account(TransactionResponseAccountDto account) {
    this.account = account;
    return this;
  }

   /**
   * Get account
   * @return account
  **/
  @ApiModelProperty(value = "")

  @Valid

  public TransactionResponseAccountDto getAccount() {
    return account;
  }

  public void setAccount(TransactionResponseAccountDto account) {
    this.account = account;
  }

  public TransactionResponseDto alias(String alias) {
    this.alias = alias;
    return this;
  }

   /**
   * Get alias
   * @return alias
  **/
  @ApiModelProperty(value = "")


  public String getAlias() {
    return alias;
  }

  public void setAlias(String alias) {
    this.alias = alias;
  }

  public TransactionResponseDto country(String country) {
    this.country = country;
    return this;
  }

   /**
   * Get country
   * @return country
  **/
  @ApiModelProperty(value = "")


  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public TransactionResponseDto agent(String agent) {
    this.agent = agent;
    return this;
  }

   /**
   * Get agent
   * @return agent
  **/
  @ApiModelProperty(value = "")


  public String getAgent() {
    return agent;
  }

  public void setAgent(String agent) {
    this.agent = agent;
  }

  public TransactionResponseDto transactionsDataList(List<TransactionsDataListItemDto> transactionsDataList) {
    this.transactionsDataList = transactionsDataList;
    return this;
  }

  public TransactionResponseDto addTransactionsDataListItem(TransactionsDataListItemDto transactionsDataListItem) {
    if (this.transactionsDataList == null) {
      this.transactionsDataList = new ArrayList<TransactionsDataListItemDto>();
    }
    this.transactionsDataList.add(transactionsDataListItem);
    return this;
  }

   /**
   * Get transactionsDataList
   * @return transactionsDataList
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<TransactionsDataListItemDto> getTransactionsDataList() {
    return transactionsDataList;
  }

  public void setTransactionsDataList(List<TransactionsDataListItemDto> transactionsDataList) {
    this.transactionsDataList = transactionsDataList;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TransactionResponseDto transactionResponse = (TransactionResponseDto) o;
    return Objects.equals(this.displayNumber, transactionResponse.displayNumber) &&
        Objects.equals(this.account, transactionResponse.account) &&
        Objects.equals(this.alias, transactionResponse.alias) &&
        Objects.equals(this.country, transactionResponse.country) &&
        Objects.equals(this.agent, transactionResponse.agent) &&
        Objects.equals(this.transactionsDataList, transactionResponse.transactionsDataList);
  }

  @Override
  public int hashCode() {
    return Objects.hash(displayNumber, account, alias, country, agent, transactionsDataList);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TransactionResponseDto {\n");
    
    sb.append("    displayNumber: ").append(toIndentedString(displayNumber)).append("\n");
    sb.append("    account: ").append(toIndentedString(account)).append("\n");
    sb.append("    alias: ").append(toIndentedString(alias)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("    agent: ").append(toIndentedString(agent)).append("\n");
    sb.append("    transactionsDataList: ").append(toIndentedString(transactionsDataList)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

