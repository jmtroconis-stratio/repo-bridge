package com.stratio.financial.one.trade.transactions.application.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import com.stratio.financial.one.trade.transactions.application.factory.DataFactory;
import com.stratio.financial.one.trade.transactions.application.repository.TransactionCompanyAccountRepository;
import com.stratio.financial.one.trade.transactions.application.repository.TransactionRepository;
import com.stratio.financial.one.trade.transactions.application.service.TransactionService;
import com.stratio.financial.one.trade.transactions.domain.search.AccountsCountriesList;
import com.stratio.financial.one.trade.transactions.domain.search.AccountsCountry;
import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;
import com.stratio.financial.one.trade.transactions.domain.sql.TransactionCompanyAccount;
import com.stratio.financial.one.trade.transactions.domain.sql.TransactionCompanyAccountId;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j2;

@AllArgsConstructor
@Log4j2
public class TransactionServiceImpl implements TransactionService {

  private final TransactionCompanyAccountRepository transactionCompanyAccountRepository;
  private final TransactionRepository transactionRepository;
  public static final int MAX_NUM_DOCUMENTS_ELASTIC = 10000;

  @Override
  public List<Transaction> getLastTransactionsDateTime(AccountsCountriesList accountsCountriesList) {
    return accountsCountriesList.stream()
        .filter(accountsCountry -> Objects.nonNull(accountsCountry.getAccount()))
        .map(this::getLastTransactionsDateTimeSingle)
        .filter(Optional::isPresent)
        .map(Optional::get)
        .collect(Collectors.toList());
  }

  private Optional<Transaction> getLastTransactionsDateTimeSingle(AccountsCountry accountsCountry) {
    Optional<Transaction> transaction = Optional.empty();

    TransactionCompanyAccountId transactionCompanyAccountId = TransactionCompanyAccountId.builder()
        .accountId(accountsCountry.getAccount().getAccountId())
        .country(accountsCountry.getCountry())
        .build();

    Optional<TransactionCompanyAccount> transactionCompanyAccount = transactionCompanyAccountRepository
        .findById(transactionCompanyAccountId);

    if (transactionCompanyAccount.isPresent()
        && matchAccountIdType(accountsCountry, transactionCompanyAccount.get())) {
      transaction = Optional.of(
          transactionRepository.findLastConsolidated(true, accountsCountry.getAccount().getAccountId(),
              accountsCountry.getCountry())
              .orElse(DataFactory.createTransaction(accountsCountry)));
    }

    return transaction;
  }

  private boolean matchAccountIdType(AccountsCountry accountsCountry,
                                     TransactionCompanyAccount transactionCompanyAccount) {
    return accountsCountry.getAccount().getAccountIdType() == null
        || accountsCountry.getAccount().getAccountIdType().equals(transactionCompanyAccount.getAccountIdType());
  }

}
