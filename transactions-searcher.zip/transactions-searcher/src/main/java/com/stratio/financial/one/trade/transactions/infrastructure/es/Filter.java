package com.stratio.financial.one.trade.transactions.infrastructure.es;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Filter {

  private String type;
  private List<Clause> clauses;

  public Filter() {
    this.clauses = new ArrayList<>();
  }
}
