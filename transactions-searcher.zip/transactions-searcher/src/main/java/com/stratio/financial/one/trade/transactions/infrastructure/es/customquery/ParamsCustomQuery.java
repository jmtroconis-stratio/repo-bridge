package com.stratio.financial.one.trade.transactions.infrastructure.es.customquery;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
@JsonRootName("params")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ParamsCustomQuery {

  private List<SearchElementCustomQuery> searchElements;

  private String orderField;
  private String orderDescAsc;

}
