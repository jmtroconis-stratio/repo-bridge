package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.mapper;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

import com.stratio.financial.one.trade.transactions.application.service.impl.TransactionServiceImpl;
import com.stratio.financial.one.trade.transactions.domain.data.DocumentsData;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionData;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionSummaryData;
import com.stratio.financial.one.trade.transactions.domain.search.AccountsCountriesList;
import com.stratio.financial.one.trade.transactions.domain.search.AccountsCountry;
import com.stratio.financial.one.trade.transactions.domain.search.AccountsCountryAccount;
import com.stratio.financial.one.trade.transactions.domain.search.RequestQuery;
import com.stratio.financial.one.trade.transactions.domain.sql.Agent;
import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.XlsxLabels;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.AccountsCountriesListDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.AccountsCountryAccountDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.AccountsCountryBeneficiaryDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.AccountsCountryDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.LastProcessedDateOutputDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.LastProcessedDatePerAccountDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.RequestQueryDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.RequestQueryXslxDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionResponseAccountDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionResponseDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsDataListItemDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsDataListItemTransactionDetailsDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsResponseDocumentsDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsResponseDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.exception.LimitExceededException;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.exception.ValidationException;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.springframework.core.io.ByteArrayResource;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Mapper(componentModel = "spring")
public abstract class TransactionMapper {

  private static final int COMMON_ITEM = 0;
  private static final Integer DEFAULT_SEARCH_FROM = 0;
  private static final Integer DEFAULT_SEARCH_LIMIT = 1000;
  private static final String PATTERN_DATE_INPUT = "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d{3})?\\+\\d{4}$";

  @Mapping(source = "offset", target = "from")
  @Mapping(source = "fromDate", target = "fromDate", qualifiedByName = "removeMillisecondsFromString")
  @Mapping(source = "toDate", target = "toDate", qualifiedByName = "removeMillisecondsFromString")
  public abstract RequestQuery requestQueryDtoToRequestQuery(
      RequestQueryDto requestQueryDto);

  @Mapping(source = "offset", target = "from")
  @Mapping(source = "fromDate", target = "fromDate", qualifiedByName = "removeMillisecondsFromString")
  @Mapping(source = "toDate", target = "toDate", qualifiedByName = "removeMillisecondsFromString")
  public abstract RequestQuery requestQueryXlsxDtoToRequestQuery(
      RequestQueryXslxDto requestQueryXslxDto);

  public abstract AccountsCountriesList accountsCountriesListDtoToAccountsCountriesList(
      AccountsCountriesListDto accountsCountriesListDto);

  public abstract AccountsCountry accountsCountryDtoToAccountsCountry(
      AccountsCountryDto accountsCountryDto);

  public abstract AccountsCountryAccount accountsCountryAccountDtoToAccountsCountryAccount(
      AccountsCountryAccountDto accountsCountryAccountDto);

  public LastProcessedDateOutputDto transactionsToLastProcessedDateOutputDto(
      List<Transaction> transactions) {
    LastProcessedDateOutputDto lastProcessedDateOutputDto = new LastProcessedDateOutputDto();
    transactions.stream().forEach(transaction ->
        lastProcessedDateOutputDto.addLastProcessedDatesItem(
            transactionToLastProcessedDatePerAccountDto(transaction)));
    return lastProcessedDateOutputDto;
  }

  @Mapping(source = "transactionId.accountId", target = "accountId")
  @Mapping(source = "transactionId.country", target = "country")
  @Mapping(source = "transactionId.transactionId", target = "transactionId")
  @Mapping(source = "transactionId.transactionConsolidated", target = "consolidated")
  @Mapping(source = "processedDate", target = "lastProcessedDate", qualifiedByName = "instantToSssZString")
  public abstract LastProcessedDatePerAccountDto transactionToLastProcessedDatePerAccountDto(
      Transaction transaction);

  @Mapping(source = "transactionData.transactionId", target = "transactionId")
  @Mapping(source = "transactionData.creationDate", target = "creationDate",
      qualifiedByName = "addMillisecondsFromString")
  @Mapping(source = "transactionData.processedDate", target = "processedDate",
      qualifiedByName = "addMillisecondsFromString")
  @Mapping(source = "transactionData.accountingDate", target = "accountingDate",
      qualifiedByName = "addMillisecondsFromString")
  @Mapping(source = "transactionData.description", target = "description")
  @Mapping(source = "transactionData.transactionType", target = "transactionType")
  @Mapping(source = "transactionData.transactionCategory", target = "transactionCategory")
  @Mapping(source = "transactionData.transactionConsolidated", target = "transactionConsolidated")
  @Mapping(source = "transactionData.transactionAmount", target = "amount.amount")
  @Mapping(source = "transactionData.transactionAmountCurrency", target = "amount.currencyCode")
  @Mapping(source = "transactionData.transactionBalanceAmount", target = "balanceResult.amount")
  @Mapping(source = "transactionData.transactionBalanceAmountCurrency", target = "balanceResult.currencyCode")
  @Mapping(source = "transactionData.transactionBatchReference", target = "references.transactionBatchReference")
  @Mapping(source = "transactionData.transactionClientReference", target = "references.transactionClientReference")
  @Mapping(source = "transactionData.transactionInternalReference", target = "references.transactionInternalReference")
  @Mapping(source = "transactionData.swiftCode", target = "operation.swiftCode")
  @Mapping(source = "transactionData.localTransactionCode", target = "operation.localOperation.ltcCode")
  @Mapping(source = "transactionData.localTransactionDescription",
      target = "operation.localOperation.ltcDescription")
  @Mapping(source = "transactionData.additionalInformation", target = "operation.localOperation.aditionalInformation")
  @Mapping(source = "transactionData.customerAdditionalInformation",
      target = "operation.customerOperation.customerAditionalInformation")
  @Mapping(source = "transactionData.customerTransactionDescription",
      target = "operation.customerOperation.customerTDescription")
  @Mapping(source = "transactionData.customerTransactionCode",
      target = "operation.customerOperation.customerTCode")
  public abstract TransactionsDataListItemTransactionDetailsDto
      transactionDataToTransactionsDataListItemTransactionDetailsDto(
      TransactionData transactionData);

  @Mapping(source = "transactionData", target = "transactionDetails")
  public abstract TransactionsDataListItemDto transactionDataToTransactionsDataListItemDto(
      TransactionData transactionData);

  public abstract List<TransactionsDataListItemDto> transactionDatasToTransactionsDataListItemDtos(
      List<TransactionData> transactionsData);

  @Mapping(source = "documentsData.totalRegistersFound", target = "totalRegistersFound")
  @Mapping(source = "documentsData.retrieved", target = "retrieved")
  public abstract TransactionsResponseDocumentsDto documentsDataToTransactionsResponseDocumentsDto(
      DocumentsData documentsData);

  public ByteArrayResource transactionsSummaryDataToByteArrayResource(
      TransactionSummaryData transactionsSummaryData, List<Agent> agents,
      List<AccountsCountryBeneficiaryDto> accountsCountryBeneficiaryDtos) throws IOException {
    int row = 0;
    Workbook workbook = new XSSFWorkbook();
    Sheet sheet = workbook.createSheet();
    Row header = sheet.createRow(row);
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    try {
      for (int i = 0; i < XlsxLabels.values().length; i++) {
        Cell headerCell = header.createCell(i);
        headerCell.setCellValue(XlsxLabels.values()[i].getEn());
      }
      for (TransactionData transactionData : transactionsSummaryData.getTransactions()) {
        row++;
        Row transaction = sheet.createRow(row);
        transaction.createCell(0).setCellValue(
            accountsCountryBeneficiaryDtos.stream().filter(
                accountsCountryBeneficiaryDto -> accountsCountryBeneficiaryDto.getAccount()
                    .getAccountId()
                    .equals(transactionData.getTransactionCompanyAccount().getAccountId())
            ).filter(
                accountsCountryBeneficiaryDto -> accountsCountryBeneficiaryDto.getCountry()
                    .equals(transactionData.getTransactionCompanyAccount().getCountry())
            ).findFirst().orElseThrow().getAccount().getBeneficiary()
        );
        transaction.createCell(1).setCellValue(
            agents.stream().filter(
                agent -> agent.getBic()
                    .equals(transactionData.getTransactionCompanyAccount().getAgent())
            ).findFirst().orElseThrow().getInstitutionName()
        );
        transaction.createCell(2)
            .setCellValue(transactionData.getTransactionCompanyAccount().getAgent());
        transaction.createCell(3)
            .setCellValue(transactionData.getTransactionCompanyAccount().getAlias());
        transaction.createCell(4)
            .setCellValue(transactionData.getTransactionCompanyAccount().getAccountId());
        transaction.createCell(5).setCellValue(transactionData.getAccountingDate());
        transaction.createCell(6).setCellValue(transactionData.getProcessedDate());
        transaction.createCell(7).setCellValue(transactionData.getSwiftCode());
        transaction.createCell(8).setCellValue(transactionData.getTransactionAmount().toString());
        transaction.createCell(9).setCellValue(transactionData.getTransactionAmountCurrency());
        transaction.createCell(10).setCellValue(transactionData.getTransactionClientReference());
        transaction.createCell(11).setCellValue(transactionData.getTransactionInternalReference());
        transaction.createCell(12).setCellValue(transactionData.getDescription());
      }
      workbook.write(outputStream);
    } catch (Exception e) {
      log.error("Error parsing transactions to an xlsx");
    } finally {
      workbook.close();
    }
    return new ByteArrayResource(outputStream.toByteArray());
  }

  public TransactionsResponseDto transactionsSummaryDataToTransactionsResponseDto(
      TransactionSummaryData transactionsSummaryData) {
    HashMap<String, List<TransactionData>> transactionsByAccount
        = getTransactionsByAccountCountry(transactionsSummaryData);
    TransactionsResponseDto transactionsResponseDto
        = setTransactionsByAccountCountry(transactionsByAccount);
    TransactionsResponseDocumentsDto transactionsResponseDocumentsDto
        = documentsDataToTransactionsResponseDocumentsDto(transactionsSummaryData.getDocuments());
    transactionsResponseDto.setDocuments(transactionsResponseDocumentsDto);
    return transactionsResponseDto;
  }

  private HashMap<String, List<TransactionData>> getTransactionsByAccountCountry(
      TransactionSummaryData transactionsSummaryData) {
    HashMap<String, List<TransactionData>> transactionsByAccount = new LinkedHashMap<>();
    for (TransactionData transactionData : transactionsSummaryData.getTransactions()) {
      String key = transactionData.getTransactionCompanyAccount().getAccountId()
          .concat(transactionData.getTransactionCompanyAccount().getCountry());
      List<TransactionData> transactionDatasByAccount = transactionsByAccount.get(key);
      if (transactionDatasByAccount == null) {
        transactionDatasByAccount = new ArrayList<>();
      }
      transactionDatasByAccount.add(transactionData);
      transactionsByAccount.put(key, transactionDatasByAccount);
    }
    return transactionsByAccount;
  }

  private TransactionsResponseDto setTransactionsByAccountCountry(
      HashMap<String, List<TransactionData>> transactionsByAccount) {
    TransactionsResponseDto transactionsResponseDto = new TransactionsResponseDto();
    for (List<TransactionData> transactionDataList : transactionsByAccount.values()) {
      TransactionResponseDto transactionResponseDto = new TransactionResponseDto();
      TransactionData firstTransactionData = transactionDataList.get(COMMON_ITEM);
      TransactionResponseAccountDto transactionResponseAccountDto = new TransactionResponseAccountDto();
      transactionResponseAccountDto
          .setAccountId(firstTransactionData.getTransactionCompanyAccount().getAccountId());
      transactionResponseAccountDto
          .setIdType(firstTransactionData.getTransactionCompanyAccount().getAccountIdType());
      transactionResponseDto
          .setAccount(transactionResponseAccountDto);
      transactionResponseDto
          .setAgent(firstTransactionData.getTransactionCompanyAccount().getAgent());
      transactionResponseDto
          .setAlias(firstTransactionData.getTransactionCompanyAccount().getAlias());
      transactionResponseDto
          .setCountry(firstTransactionData.getTransactionCompanyAccount().getCountry());
      transactionResponseDto
          .setDisplayNumber(firstTransactionData.getTransactionCompanyAccount().getDisplayNumber());
      List<TransactionsDataListItemDto> transactionsDataListItemDtos =
          transactionDatasToTransactionsDataListItemDtos(transactionDataList);
      transactionResponseDto.setTransactionsDataList(transactionsDataListItemDtos);
      List<TransactionResponseDto> transactionListResponse = transactionsResponseDto
          .getTransactionsListResponse();
      if (transactionListResponse == null) {
        transactionListResponse = new ArrayList<>();
      }
      transactionListResponse.add(transactionResponseDto);
      transactionsResponseDto.setTransactionsListResponse(transactionListResponse);
    }
    return transactionsResponseDto;
  }

  @Named("localDateTimeToInstant")
  public Instant localDateTimeToInstant(LocalDateTime localDateTime) {
    return localDateTime != null ? localDateTime.toInstant(ZoneOffset.UTC) : null;
  }

  @Named("removeMillisecondsFromString")
  public String removeMillisecondsFromString(String date) {
    checkDateFormatInput(date);
    if (StringUtils.isBlank(date)) {
      return date;
    }
    return date.replaceAll("\\.[0-9]{3}", "");
  }

  @Named("addMillisecondsFromString")
  public String addMillisecondsFromString(String date) {
    if (StringUtils.isBlank(date)) {
      return date;
    }
    return date.replaceAll("\\+", ".000+");
  }

  @Named("instantToSssZString")
  public String instantToSssZString(Instant date) {
    return date != null
        ? date.atZone(ZoneOffset.UTC)
        .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")) : null;
  }

  @Named("instantToElasticFormatString")
  public String instantToElasticFormatString(Instant date) {
    return date != null
        ? date.atZone(ZoneOffset.UTC)
        .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")).concat("+0000") : null;
  }

  @Named("generatePk")
  public String generatePk() {
    return UUID.randomUUID().toString();
  }

  @AfterMapping
  public void afterMappingTargetRequestQuery(@MappingTarget RequestQuery requestQuery) {
    requestQuery.setFrom(requestQuery.getFrom() == null || requestQuery.getFrom() < 0
        ? DEFAULT_SEARCH_FROM : requestQuery.getFrom());
    requestQuery.setLimit(requestQuery.getLimit() == null || requestQuery.getLimit() < 0
        ? DEFAULT_SEARCH_LIMIT : requestQuery.getLimit());

    requestQuery.setFrom(requestQuery.getFrom() * requestQuery.getLimit());
    if ((requestQuery.getLimit() + requestQuery.getFrom()) > TransactionServiceImpl.MAX_NUM_DOCUMENTS_ELASTIC) {
      throw new LimitExceededException("The maximum number of documents to be returned has been reached: "
          + TransactionServiceImpl.MAX_NUM_DOCUMENTS_ELASTIC);
    }
  }

  private void checkDateFormatInput(String date) {
    if (date != null && !Pattern.compile(PATTERN_DATE_INPUT).matcher(date).matches()) {
      throw new ValidationException(String.format("Date %s does not match input format", date));
    }
  }
}