package com.stratio.financial.one.trade.transactions.infrastructure.db.springdata.repository;

import javax.persistence.EntityManager;
import java.util.Optional;

import com.stratio.financial.one.trade.transactions.application.repository.TransactionCompanyAccountRepository;
import com.stratio.financial.one.trade.transactions.domain.sql.TransactionCompanyAccount;
import com.stratio.financial.one.trade.transactions.domain.sql.TransactionCompanyAccountId;
import org.springframework.stereotype.Repository;

@Repository
public class CustomTransactionCompanyAccountRepository extends CriteriaEntityRepository<TransactionCompanyAccount>
    implements TransactionCompanyAccountRepository {

  private final SpringDataTransactionCompanyAccountRepository springDataTransactionCompanyAccountRepository;

  public CustomTransactionCompanyAccountRepository(
      EntityManager entityManager,
      SpringDataTransactionCompanyAccountRepository springDataTransactionCompanyAccountRepository) {
    super(entityManager);
    this.springDataTransactionCompanyAccountRepository = springDataTransactionCompanyAccountRepository;
  }

  @Override
  public TransactionCompanyAccount upsert(TransactionCompanyAccount transactionCompanyAccount) {
    Optional<TransactionCompanyAccount> transactionCompanyAccountFound =
        springDataTransactionCompanyAccountRepository
            .findById(transactionCompanyAccount.getTransactionCompanyAccountId());
    if (transactionCompanyAccountFound.isPresent()) {
      mergeEntity(transactionCompanyAccountFound.get(), transactionCompanyAccount, TransactionCompanyAccount.class);
      return springDataTransactionCompanyAccountRepository.save(transactionCompanyAccountFound.get());
    } else {
      return springDataTransactionCompanyAccountRepository.save(transactionCompanyAccount);
    }
  }

  @Override
  public Optional<TransactionCompanyAccount> findById(TransactionCompanyAccountId transactionCompanyAccountId) {
    return springDataTransactionCompanyAccountRepository.findById(transactionCompanyAccountId);
  }

  @Override
  public void deleteAll() {
    springDataTransactionCompanyAccountRepository.deleteAll();
  }
}
