package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


@ResponseStatus(value = HttpStatus.PRECONDITION_FAILED)
public class ValidationException extends RuntimeException {

  public ValidationException() {
    super("Error in query");
  }

  public ValidationException(String s) {
    super(s);
  }


}