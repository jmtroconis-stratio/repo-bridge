package com.stratio.financial.one.trade.transactions.domain.search;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@NoArgsConstructor
@ToString
public class AccountsCountry {

  @JsonProperty("account")
  private AccountsCountryAccount account = null;

  @JsonProperty("country")
  private String country = null;

  private boolean mustIncludeNotConsolidated = false;
  private String processedDateFrom = null;
}
