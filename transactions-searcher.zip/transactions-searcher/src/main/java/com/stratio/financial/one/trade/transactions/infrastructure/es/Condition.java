package com.stratio.financial.one.trade.transactions.infrastructure.es;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Condition {
  private String field;
  private List<Object> values;
  private Map<String, Object> range;
  private Distance distance;

  public Condition() {
    this.values = new ArrayList<>();
    this.range = new HashMap<>();
  }
}
