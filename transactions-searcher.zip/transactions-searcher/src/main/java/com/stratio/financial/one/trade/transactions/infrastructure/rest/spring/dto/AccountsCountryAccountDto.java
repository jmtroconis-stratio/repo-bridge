package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * AccountsCountryAccountDto
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-14T15:45:20.224+02:00")

public class AccountsCountryAccountDto   {
  @JsonProperty("accountId")
  private String accountId = null;

  @JsonProperty("accountIdType")
  private String accountIdType = null;

  public AccountsCountryAccountDto accountId(String accountId) {
    this.accountId = accountId;
    return this;
  }

   /**
   * Get accountId
   * @return accountId
  **/
  @ApiModelProperty(value = "")


  public String getAccountId() {
    return accountId;
  }

  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  public AccountsCountryAccountDto accountIdType(String accountIdType) {
    this.accountIdType = accountIdType;
    return this;
  }

   /**
   * Get accountIdType
   * @return accountIdType
  **/
  @ApiModelProperty(value = "")


  public String getAccountIdType() {
    return accountIdType;
  }

  public void setAccountIdType(String accountIdType) {
    this.accountIdType = accountIdType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AccountsCountryAccountDto accountsCountryAccount = (AccountsCountryAccountDto) o;
    return Objects.equals(this.accountId, accountsCountryAccount.accountId) &&
        Objects.equals(this.accountIdType, accountsCountryAccount.accountIdType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(accountId, accountIdType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AccountsCountryAccountDto {\n");
    
    sb.append("    accountId: ").append(toIndentedString(accountId)).append("\n");
    sb.append("    accountIdType: ").append(toIndentedString(accountIdType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

