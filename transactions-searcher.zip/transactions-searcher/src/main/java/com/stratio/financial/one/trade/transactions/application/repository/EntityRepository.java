package com.stratio.financial.one.trade.transactions.application.repository;

import java.util.Optional;

public interface EntityRepository<T, I> {

  <S extends T> S save(S s);

  <S extends T> Iterable<S> saveAll(Iterable<S> iterable);

  Optional<T> findById(I aLong);

  boolean existsById(I aLong);

  Iterable<T> findAll();

  Iterable<T> findAllById(Iterable<I> iterable);

  long count();

  void deleteById(I aLong);

  void delete(T entity);

  void deleteAll(Iterable<? extends T> iterable);

  void deleteAll();

}
