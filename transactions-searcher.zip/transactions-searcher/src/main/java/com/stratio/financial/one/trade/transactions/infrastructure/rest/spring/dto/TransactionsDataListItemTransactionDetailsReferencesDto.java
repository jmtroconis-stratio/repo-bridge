package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TransactionsDataListItemTransactionDetailsReferencesDto
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-14T15:45:20.224+02:00")

public class TransactionsDataListItemTransactionDetailsReferencesDto   {
  @JsonProperty("transactionBatchReference")
  private String transactionBatchReference = null;

  @JsonProperty("transactionClientReference")
  private String transactionClientReference = null;

  @JsonProperty("transactionInternalReference")
  private String transactionInternalReference = null;

  public TransactionsDataListItemTransactionDetailsReferencesDto transactionBatchReference(String transactionBatchReference) {
    this.transactionBatchReference = transactionBatchReference;
    return this;
  }

   /**
   * Get transactionBatchReference
   * @return transactionBatchReference
  **/
  @ApiModelProperty(value = "")


  public String getTransactionBatchReference() {
    return transactionBatchReference;
  }

  public void setTransactionBatchReference(String transactionBatchReference) {
    this.transactionBatchReference = transactionBatchReference;
  }

  public TransactionsDataListItemTransactionDetailsReferencesDto transactionClientReference(String transactionClientReference) {
    this.transactionClientReference = transactionClientReference;
    return this;
  }

   /**
   * Get transactionClientReference
   * @return transactionClientReference
  **/
  @ApiModelProperty(value = "")


  public String getTransactionClientReference() {
    return transactionClientReference;
  }

  public void setTransactionClientReference(String transactionClientReference) {
    this.transactionClientReference = transactionClientReference;
  }

  public TransactionsDataListItemTransactionDetailsReferencesDto transactionInternalReference(String transactionInternalReference) {
    this.transactionInternalReference = transactionInternalReference;
    return this;
  }

   /**
   * Get transactionInternalReference
   * @return transactionInternalReference
  **/
  @ApiModelProperty(value = "")


  public String getTransactionInternalReference() {
    return transactionInternalReference;
  }

  public void setTransactionInternalReference(String transactionInternalReference) {
    this.transactionInternalReference = transactionInternalReference;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TransactionsDataListItemTransactionDetailsReferencesDto transactionsDataListItemTransactionDetailsReferences = (TransactionsDataListItemTransactionDetailsReferencesDto) o;
    return Objects.equals(this.transactionBatchReference, transactionsDataListItemTransactionDetailsReferences.transactionBatchReference) &&
        Objects.equals(this.transactionClientReference, transactionsDataListItemTransactionDetailsReferences.transactionClientReference) &&
        Objects.equals(this.transactionInternalReference, transactionsDataListItemTransactionDetailsReferences.transactionInternalReference);
  }

  @Override
  public int hashCode() {
    return Objects.hash(transactionBatchReference, transactionClientReference, transactionInternalReference);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TransactionsDataListItemTransactionDetailsReferencesDto {\n");
    
    sb.append("    transactionBatchReference: ").append(toIndentedString(transactionBatchReference)).append("\n");
    sb.append("    transactionClientReference: ").append(toIndentedString(transactionClientReference)).append("\n");
    sb.append("    transactionInternalReference: ").append(toIndentedString(transactionInternalReference)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

