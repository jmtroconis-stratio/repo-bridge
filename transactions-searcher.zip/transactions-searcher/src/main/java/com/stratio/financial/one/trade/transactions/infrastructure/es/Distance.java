package com.stratio.financial.one.trade.transactions.infrastructure.es;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Distance {
  private Double value;
  private String unit;
  private String distanceType;
  private Float latitude;
  private Float longitude;
}
