package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.AccountsCountryBeneficiaryDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RequestQueryXslxDto
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-14T15:45:20.224+02:00")

public class RequestQueryXslxDto   {
  @JsonProperty("typeOfTransaction")
  private Boolean typeOfTransaction = null;

  @JsonProperty("accountsCountriesList")
  private List<AccountsCountryBeneficiaryDto> accountsCountriesList = new ArrayList<AccountsCountryBeneficiaryDto>();

  @JsonProperty("fromDate")
  private String fromDate = null;

  @JsonProperty("toDate")
  private String toDate = null;

  @JsonProperty("fromAmount")
  private Double fromAmount = null;

  @JsonProperty("toAmount")
  private Double toAmount = null;

  @JsonProperty("swiftCodes")
  private List<String> swiftCodes = null;

  @JsonProperty("transactionType")
  private String transactionType = null;

  @JsonProperty("clientReference")
  private String clientReference = null;

  @JsonProperty("description")
  private String description = null;

  @JsonProperty("_offset")
  private Integer offset = null;

  @JsonProperty("_limit")
  private Integer limit = null;

  @JsonProperty("sort")
  private String sort = null;

  @JsonProperty("amountFormat")
  private String amountFormat = null;

  @JsonProperty("dateFormat")
  private String dateFormat = null;

  @JsonProperty("language")
  private String language = null;

  public RequestQueryXslxDto typeOfTransaction(Boolean typeOfTransaction) {
    this.typeOfTransaction = typeOfTransaction;
    return this;
  }

   /**
   * Show only consolidated (false) or not consolidated and consolidated (true)
   * @return typeOfTransaction
  **/
  @ApiModelProperty(required = true, value = "Show only consolidated (false) or not consolidated and consolidated (true)")
  @NotNull


  public Boolean getTypeOfTransaction() {
    return typeOfTransaction;
  }

  public void setTypeOfTransaction(Boolean typeOfTransaction) {
    this.typeOfTransaction = typeOfTransaction;
  }

  public RequestQueryXslxDto accountsCountriesList(List<AccountsCountryBeneficiaryDto> accountsCountriesList) {
    this.accountsCountriesList = accountsCountriesList;
    return this;
  }

  public RequestQueryXslxDto addAccountsCountriesListItem(AccountsCountryBeneficiaryDto accountsCountriesListItem) {
    this.accountsCountriesList.add(accountsCountriesListItem);
    return this;
  }

   /**
   * A list of accounts and countries to search
   * @return accountsCountriesList
  **/
  @ApiModelProperty(required = true, value = "A list of accounts and countries to search")
  @NotNull

  @Valid

  public List<AccountsCountryBeneficiaryDto> getAccountsCountriesList() {
    return accountsCountriesList;
  }

  public void setAccountsCountriesList(List<AccountsCountryBeneficiaryDto> accountsCountriesList) {
    this.accountsCountriesList = accountsCountriesList;
  }

  public RequestQueryXslxDto fromDate(String fromDate) {
    this.fromDate = fromDate;
    return this;
  }

   /**
   * Start date period to be considered for the retrieve of transaction (YYYY-mm-DDTHH:MM:SS+xxxx)
   * @return fromDate
  **/
  @ApiModelProperty(value = "Start date period to be considered for the retrieve of transaction (YYYY-mm-DDTHH:MM:SS+xxxx)")

 @Pattern(regexp="^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d{3})?\\+\\d{4}$")
  public String getFromDate() {
    return fromDate;
  }

  public void setFromDate(String fromDate) {
    this.fromDate = fromDate;
  }

  public RequestQueryXslxDto toDate(String toDate) {
    this.toDate = toDate;
    return this;
  }

   /**
   * End date period to be considered for the retrieve of transaction (YYYY-mm-DDTHH:MM:SS+xxxx)
   * @return toDate
  **/
  @ApiModelProperty(value = "End date period to be considered for the retrieve of transaction (YYYY-mm-DDTHH:MM:SS+xxxx)")

 @Pattern(regexp="^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d{3})?\\+\\d{4}$")
  public String getToDate() {
    return toDate;
  }

  public void setToDate(String toDate) {
    this.toDate = toDate;
  }

  public RequestQueryXslxDto fromAmount(Double fromAmount) {
    this.fromAmount = fromAmount;
    return this;
  }

   /**
   * Minimum amount of transactions to retrieve. Allows negative and positive amounts
   * @return fromAmount
  **/
  @ApiModelProperty(value = "Minimum amount of transactions to retrieve. Allows negative and positive amounts")


  public Double getFromAmount() {
    return fromAmount;
  }

  public void setFromAmount(Double fromAmount) {
    this.fromAmount = fromAmount;
  }

  public RequestQueryXslxDto toAmount(Double toAmount) {
    this.toAmount = toAmount;
    return this;
  }

   /**
   * Maximum amount of transactions to retrieve. Allows negative and positive amounts
   * @return toAmount
  **/
  @ApiModelProperty(value = "Maximum amount of transactions to retrieve. Allows negative and positive amounts")


  public Double getToAmount() {
    return toAmount;
  }

  public void setToAmount(Double toAmount) {
    this.toAmount = toAmount;
  }

  public RequestQueryXslxDto swiftCodes(List<String> swiftCodes) {
    this.swiftCodes = swiftCodes;
    return this;
  }

  public RequestQueryXslxDto addSwiftCodesItem(String swiftCodesItem) {
    if (this.swiftCodes == null) {
      this.swiftCodes = new ArrayList<String>();
    }
    this.swiftCodes.add(swiftCodesItem);
    return this;
  }

   /**
   * Determinate the swift code for a transaction which only contains 3 characters
   * @return swiftCodes
  **/
  @ApiModelProperty(value = "Determinate the swift code for a transaction which only contains 3 characters")


  public List<String> getSwiftCodes() {
    return swiftCodes;
  }

  public void setSwiftCodes(List<String> swiftCodes) {
    this.swiftCodes = swiftCodes;
  }

  public RequestQueryXslxDto transactionType(String transactionType) {
    this.transactionType = transactionType;
    return this;
  }

   /**
   * Type of transaction. Represents if the transaction increases (Credit) or decreases (Debit) the balance of the account. Possible values: debit / credit. If not informed, all transactions are considered (debit and credit).
   * @return transactionType
  **/
  @ApiModelProperty(value = "Type of transaction. Represents if the transaction increases (Credit) or decreases (Debit) the balance of the account. Possible values: debit / credit. If not informed, all transactions are considered (debit and credit).")


  public String getTransactionType() {
    return transactionType;
  }

  public void setTransactionType(String transactionType) {
    this.transactionType = transactionType;
  }

  public RequestQueryXslxDto clientReference(String clientReference) {
    this.clientReference = clientReference;
    return this;
  }

   /**
   * Client reference field. Free write
   * @return clientReference
  **/
  @ApiModelProperty(value = "Client reference field. Free write")


  public String getClientReference() {
    return clientReference;
  }

  public void setClientReference(String clientReference) {
    this.clientReference = clientReference;
  }

  public RequestQueryXslxDto description(String description) {
    this.description = description;
    return this;
  }

   /**
   * Description field. Free write. Minimum: 3 characters. Maximum: 390 characters
   * @return description
  **/
  @ApiModelProperty(value = "Description field. Free write. Minimum: 3 characters. Maximum: 390 characters")


  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public RequestQueryXslxDto offset(Integer offset) {
    this.offset = offset;
    return this;
  }

   /**
   * Number of Register to return from the search
   * @return offset
  **/
  @ApiModelProperty(value = "Number of Register to return from the search")


  public Integer getOffset() {
    return offset;
  }

  public void setOffset(Integer offset) {
    this.offset = offset;
  }

  public RequestQueryXslxDto limit(Integer limit) {
    this.limit = limit;
    return this;
  }

   /**
   * Max Number Registers to return
   * @return limit
  **/
  @ApiModelProperty(value = "Max Number Registers to return")


  public Integer getLimit() {
    return limit;
  }

  public void setLimit(Integer limit) {
    this.limit = limit;
  }

  public RequestQueryXslxDto sort(String sort) {
    this.sort = sort;
    return this;
  }

   /**
   * Get sort
   * @return sort
  **/
  @ApiModelProperty(value = "")


  public String getSort() {
    return sort;
  }

  public void setSort(String sort) {
    this.sort = sort;
  }

  public RequestQueryXslxDto amountFormat(String amountFormat) {
    this.amountFormat = amountFormat;
    return this;
  }

   /**
   * Get amountFormat
   * @return amountFormat
  **/
  @ApiModelProperty(value = "")


  public String getAmountFormat() {
    return amountFormat;
  }

  public void setAmountFormat(String amountFormat) {
    this.amountFormat = amountFormat;
  }

  public RequestQueryXslxDto dateFormat(String dateFormat) {
    this.dateFormat = dateFormat;
    return this;
  }

   /**
   * Get dateFormat
   * @return dateFormat
  **/
  @ApiModelProperty(value = "")


  public String getDateFormat() {
    return dateFormat;
  }

  public void setDateFormat(String dateFormat) {
    this.dateFormat = dateFormat;
  }

  public RequestQueryXslxDto language(String language) {
    this.language = language;
    return this;
  }

   /**
   * Get language
   * @return language
  **/
  @ApiModelProperty(value = "")


  public String getLanguage() {
    return language;
  }

  public void setLanguage(String language) {
    this.language = language;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RequestQueryXslxDto requestQueryXslx = (RequestQueryXslxDto) o;
    return Objects.equals(this.typeOfTransaction, requestQueryXslx.typeOfTransaction) &&
        Objects.equals(this.accountsCountriesList, requestQueryXslx.accountsCountriesList) &&
        Objects.equals(this.fromDate, requestQueryXslx.fromDate) &&
        Objects.equals(this.toDate, requestQueryXslx.toDate) &&
        Objects.equals(this.fromAmount, requestQueryXslx.fromAmount) &&
        Objects.equals(this.toAmount, requestQueryXslx.toAmount) &&
        Objects.equals(this.swiftCodes, requestQueryXslx.swiftCodes) &&
        Objects.equals(this.transactionType, requestQueryXslx.transactionType) &&
        Objects.equals(this.clientReference, requestQueryXslx.clientReference) &&
        Objects.equals(this.description, requestQueryXslx.description) &&
        Objects.equals(this.offset, requestQueryXslx.offset) &&
        Objects.equals(this.limit, requestQueryXslx.limit) &&
        Objects.equals(this.sort, requestQueryXslx.sort) &&
        Objects.equals(this.amountFormat, requestQueryXslx.amountFormat) &&
        Objects.equals(this.dateFormat, requestQueryXslx.dateFormat) &&
        Objects.equals(this.language, requestQueryXslx.language);
  }

  @Override
  public int hashCode() {
    return Objects.hash(typeOfTransaction, accountsCountriesList, fromDate, toDate, fromAmount, toAmount, swiftCodes, transactionType, clientReference, description, offset, limit, sort, amountFormat, dateFormat, language);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RequestQueryXslxDto {\n");
    
    sb.append("    typeOfTransaction: ").append(toIndentedString(typeOfTransaction)).append("\n");
    sb.append("    accountsCountriesList: ").append(toIndentedString(accountsCountriesList)).append("\n");
    sb.append("    fromDate: ").append(toIndentedString(fromDate)).append("\n");
    sb.append("    toDate: ").append(toIndentedString(toDate)).append("\n");
    sb.append("    fromAmount: ").append(toIndentedString(fromAmount)).append("\n");
    sb.append("    toAmount: ").append(toIndentedString(toAmount)).append("\n");
    sb.append("    swiftCodes: ").append(toIndentedString(swiftCodes)).append("\n");
    sb.append("    transactionType: ").append(toIndentedString(transactionType)).append("\n");
    sb.append("    clientReference: ").append(toIndentedString(clientReference)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    offset: ").append(toIndentedString(offset)).append("\n");
    sb.append("    limit: ").append(toIndentedString(limit)).append("\n");
    sb.append("    sort: ").append(toIndentedString(sort)).append("\n");
    sb.append("    amountFormat: ").append(toIndentedString(amountFormat)).append("\n");
    sb.append("    dateFormat: ").append(toIndentedString(dateFormat)).append("\n");
    sb.append("    language: ").append(toIndentedString(language)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

