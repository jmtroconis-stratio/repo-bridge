package com.stratio.financial.one.trade.transactions.infrastructure.es.service.impl;

import java.util.List;
import javax.transaction.Transactional;

import com.stratio.financial.one.trade.transactions.application.repository.TransactionDataRepository;
import com.stratio.financial.one.trade.transactions.application.repository.TransactionRepository;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionData;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionSummaryData;
import com.stratio.financial.one.trade.transactions.infrastructure.es.mapper.TransactionDataMapper;
import com.stratio.financial.one.trade.transactions.infrastructure.es.service.TransactionDataService;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class TransactionDataServiceImpl implements TransactionDataService {

  private final TransactionDataRepository transactionDataRepository;
  private final TransactionRepository transactionRepository;
  private final TransactionDataMapper transactionDataMapper;

  @Override
  public void save(TransactionSummaryData transactionSummaryData) {
    transactionDataRepository.index(transactionSummaryData.getTransactions());
  }

  @Override
  public void delete(List<TransactionData> transactionDataList) {
    transactionDataRepository.delete(transactionDataList);
  }

  @Override
  public TransactionSummaryData searchToDate(String date, Integer size, Boolean consolidated) {
    return transactionDataRepository.searchToDate(date, 0, size, consolidated);
  }

  @Override
  public void deleteOldNotConsolidated(String dateTo, int size) {
    TransactionSummaryData response;
    do  {
      response = searchToDate(dateTo, size, false);
    } while (deleteBlock(response) > 0);
  }

  @Transactional
  public int deleteBlock(TransactionSummaryData response) {
    if (response.getTransactions().size() > 0) {
      transactionRepository.deleteAll(transactionDataMapper
          .transactionDataToTransactionList(response.getTransactions()));
      delete(response.getTransactions());
    }

    return response.getTransactions().size();
  }
}
