package com.stratio.financial.one.trade.transactions.infrastructure.db.springdata.repository;

import javax.persistence.EntityManager;
import javax.persistence.metamodel.EntityType;
import javax.persistence.metamodel.Metamodel;
import javax.persistence.metamodel.SingularAttribute;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class CriteriaEntityRepository<T> {

  protected final EntityManager entityManager;

  public CriteriaEntityRepository(EntityManager entityManager) {
    this.entityManager = entityManager;
  }

  public void mergeEntity(T entityFound, T entity, Class<T> entityClazz, String... attributesMustNotInclude) {
    Metamodel metamodel = entityManager.getMetamodel();
    EntityType<T> entityType = metamodel.entity(entityClazz);

    List<SingularAttribute> attributesMustNotIncludeList = new ArrayList<>();

    Arrays.stream(attributesMustNotInclude)
        .forEach(attributeMustNotInclude ->
            attributesMustNotIncludeList.add(entityType.getDeclaredSingularAttribute(attributeMustNotInclude)));

    entityType.getDeclaredSingularAttributes().stream()
        .filter(singularAttribute -> !singularAttribute.isId())
        .filter(singularAttribute -> !singularAttribute.isCollection())
        .filter(singularAttribute -> !attributesMustNotIncludeList.stream()
            .anyMatch(attribute -> singularAttribute.getName().equals(attribute.getName())))
        .forEach(singularAttribute ->
            getFieldValue(singularAttribute.getName(), entity, entityClazz)
                .ifPresent(value -> setFieldValue(singularAttribute.getName(), entityFound, entityClazz, value)));
  }

  private Optional<Object> getFieldValue(String fieldName, T object, Class<T> entityClazz) {

    try {
      Field field = entityClazz.getDeclaredField(fieldName);

      field.setAccessible(true);

      return Optional.ofNullable(field.get(object));
    } catch (IllegalAccessException e) {
      e.printStackTrace();
    } catch (NoSuchFieldException e) {
      e.printStackTrace();
    }

    return Optional.empty();
  }

  private void setFieldValue(String fieldName, T object, Class<T> entityClazz, Object value) {

    try {
      Field field = entityClazz.getDeclaredField(fieldName);

      field.setAccessible(true);

      field.set(object, value);
    } catch (IllegalAccessException e) {
      e.printStackTrace();
    } catch (NoSuchFieldException e) {
      e.printStackTrace();
    }
  }

}

