package com.stratio.financial.one.trade.transactions.infrastructure.es.parser;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import com.stratio.financial.one.trade.transactions.domain.search.AccountsCountry;
import com.stratio.financial.one.trade.transactions.domain.search.RequestQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.customquery.AccountCountry;
import com.stratio.financial.one.trade.transactions.infrastructure.es.customquery.ElasticCustomQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.customquery.PaginationCustomQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.customquery.ParamsCustomQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.customquery.QueryCustomQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.customquery.Range;
import com.stratio.financial.one.trade.transactions.infrastructure.es.customquery.SearchElementCustomQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.customquery.SwiftCode;
import com.stratio.financial.one.trade.transactions.infrastructure.es.customquery.TransactionType;
import org.springframework.stereotype.Component;

@Component
public class TransactionRequestCustomQueryParser {

  private static final String TRANSACTION_TYPE_CREDIT = "credit";
  private static final String TRANSACTION_TYPE_DEBIT = "debit";
  private static final String PREFIX_REVERSE_TRANSACTION_TYPE = "reverse";

  public ElasticCustomQuery parse(RequestQuery requestQuery) {
    ElasticCustomQuery elasticCustomQuery = new ElasticCustomQuery();

    PaginationCustomQuery paginationCustomQuery =
        PaginationCustomQuery.builder().from(requestQuery.getFrom()).size(requestQuery.getLimit()).build();
    elasticCustomQuery.setPaginationCustomQuery(paginationCustomQuery);

    ParamsCustomQuery paramsCustomQuery = new ParamsCustomQuery();
    addSearchElements(requestQuery, paramsCustomQuery);
    addOrderField(paramsCustomQuery, "processedDate");
    addOrderDescAsc(paramsCustomQuery, "desc");

    elasticCustomQuery.setQueryCustomQuery(new QueryCustomQuery(paramsCustomQuery));

    return elasticCustomQuery;
  }

  private void addSearchElements(RequestQuery requestQuery, ParamsCustomQuery paramsCustomQuery) {

    List<SearchElementCustomQuery> searchElementCustomQueryList = new ArrayList<>();
    requestQuery.getAccountsCountriesList().stream().forEach(accountsCountry -> {
      SearchElementCustomQuery searchElementCustomQueryConsolidated = createSearchElements(
          requestQuery, true, null, accountsCountry);
      searchElementCustomQueryList.add(searchElementCustomQueryConsolidated);

      if (accountsCountry.isMustIncludeNotConsolidated()) {
        SearchElementCustomQuery searchElementCustomQueryNotConsolidated = createSearchElements(
            requestQuery, false, accountsCountry.getProcessedDateFrom(), accountsCountry);
        searchElementCustomQueryList.add(searchElementCustomQueryNotConsolidated);
      }
    });

    paramsCustomQuery.setSearchElements(searchElementCustomQueryList);
  }

  private SearchElementCustomQuery createSearchElements(RequestQuery requestQuery,
                                                        boolean consolidated, String processedDateFrom,
                                                        AccountsCountry accountsCountry) {
    SearchElementCustomQuery searchElementCustomQuery = new SearchElementCustomQuery();

    addDescription(searchElementCustomQuery, requestQuery.getDescription());
    addTransactionClientReference(searchElementCustomQuery, requestQuery.getClientReference());
    addAccountsCountries(searchElementCustomQuery, accountsCountry);
    addProcessedDate(searchElementCustomQuery, requestQuery.getFromDate(), requestQuery.getToDate());

    addTransactionAmountFrom(
        searchElementCustomQuery,
        requestQuery.getFromAmount() != null ? Math.abs(requestQuery.getFromAmount()) : null,
        requestQuery.getFromAmount() != null ? -Math.abs(requestQuery.getFromAmount()) : null
    );

    addTransactionAmountTo(
        searchElementCustomQuery,
        requestQuery.getToAmount() != null ? -Math.abs(requestQuery.getToAmount()) : null,
        requestQuery.getToAmount() != null ? Math.abs(requestQuery.getToAmount()) : null
    );

    addSwiftCodes(searchElementCustomQuery, requestQuery.getSwiftCodes());

    addTransactionType(searchElementCustomQuery, requestQuery.getTransactionType());
    addConsolidated(searchElementCustomQuery, consolidated);

    addProcessedDateFrom(searchElementCustomQuery, processedDateFrom);

    return searchElementCustomQuery;
  }

  private void addDescription(
      SearchElementCustomQuery searchElementCustomQuery, String description) {
    if (description != null) {
      searchElementCustomQuery.setDescription(description);
    }
  }

  private void addTransactionClientReference(
      SearchElementCustomQuery searchElementCustomQuery, String transactionClientReference) {
    if (transactionClientReference != null) {
      searchElementCustomQuery.setTransactionClientReference(transactionClientReference);
    }
  }

  private void addAccountsCountries(SearchElementCustomQuery searchElementCustomQuery,
                                    AccountsCountry accountsCountry) {
    AccountCountry accountCountry = AccountCountry.builder()
        .accountId(accountsCountry.getAccount().getAccountId())
        .accountIdType(accountsCountry.getAccount().getAccountIdType())
        .country(accountsCountry.getCountry())
        .build();
    searchElementCustomQuery.setAccountCountry(accountCountry);
  }

  private void addProcessedDate(SearchElementCustomQuery searchElementCustomQuery, String from, String to) {
    if (from != null || to != null) {
      searchElementCustomQuery.setProcessedDate(createRangeIncludeEquals(from, to));
    }
  }

  private void addTransactionAmountFrom(SearchElementCustomQuery searchElementCustomQuery, Object from, Object to) {
    if (from != null || to != null) {
      searchElementCustomQuery.setTransactionAmountFrom(createRangeIncludeEquals(from, to));
    }
  }

  private void addTransactionAmountTo(SearchElementCustomQuery searchElementCustomQuery, Object from, Object to) {
    if (from != null || to != null) {
      searchElementCustomQuery.setTransactionAmountTo(createRangeIncludeEquals(from, to));
    }
  }

  private void addSwiftCodes(SearchElementCustomQuery searchElementCustomQuery, List<String> swiftCodesStr) {
    if (swiftCodesStr != null && !swiftCodesStr.isEmpty()) {
      searchElementCustomQuery.setSwiftCodes(
          swiftCodesStr.stream().filter(Objects::nonNull).map(SwiftCode::new).collect(Collectors.toList())
      );
    }
  }

  private void addTransactionType(SearchElementCustomQuery searchElementCustomQuery, String transactionType) {
    if (transactionType != null) {
      List<TransactionType> transactionTypes = Arrays.asList(
              new TransactionType(transactionType),
              getTransactionTypeReverse(transactionType))
          .stream().filter(Objects::nonNull).collect(Collectors.toList());

      searchElementCustomQuery.setTransactionTypes(transactionTypes);
    }
  }

  //FIXME: in the future when a refactor will be done, change to enum
  private TransactionType getTransactionTypeReverse(String transactionType) {
    if (transactionType.equals(TRANSACTION_TYPE_CREDIT)) {
      return new TransactionType(PREFIX_REVERSE_TRANSACTION_TYPE + " " + TRANSACTION_TYPE_DEBIT);
    }
    if (transactionType.equals(TRANSACTION_TYPE_DEBIT)) {
      return new TransactionType(PREFIX_REVERSE_TRANSACTION_TYPE + " " + TRANSACTION_TYPE_CREDIT);
    }
    return null;
  }

  private void addConsolidated(SearchElementCustomQuery searchElementCustomQuery, boolean consolidated) {
    searchElementCustomQuery.setTransactionConsolidated(String.valueOf(consolidated));
  }

  private void addProcessedDateFrom(SearchElementCustomQuery searchElementCustomQuery, String from) {
    if (from != null) {
      searchElementCustomQuery.setProcessedDateFrom(from);
    }
  }

  private void addOrderField(ParamsCustomQuery paramsCustomQuery, String orderField) {
    if (orderField != null) {
      paramsCustomQuery.setOrderField(orderField);
    }
  }

  private void addOrderDescAsc(ParamsCustomQuery paramsCustomQuery, String orderDescAsc) {
    if (orderDescAsc != null) {
      paramsCustomQuery.setOrderDescAsc(orderDescAsc);
    }
  }

  private Range createRangeIncludeEquals(Object from, Object to) {
    return Range.builder().gte(from).lte(to).build();
  }
}
