package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.resource;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.ErrorDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.exception.LimitExceededException;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.exception.ValidationException;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import lombok.extern.log4j.Log4j;

@Log4j
@ControllerAdvice
public class ExceptionHandlerResource extends ResponseEntityExceptionHandler {

  @Override
  protected ResponseEntity<Object> handleMethodArgumentNotValid(
      MethodArgumentNotValidException e,
      HttpHeaders headers,
      HttpStatus status,
      WebRequest request) {
    ErrorDto error = getErrorDto(HttpStatus.BAD_REQUEST, e.getMessage());
    List<FieldError> fieldErrors = e.getBindingResult().getFieldErrors();
    List<ObjectError> globalErrors = e.getBindingResult().getGlobalErrors();
    List<String> errors = new ArrayList<>(fieldErrors.size() + globalErrors.size());
    for (FieldError fieldError : fieldErrors) {
      errors.add(fieldError.getField() + ", " + fieldError.getDefaultMessage());
    }
    for (ObjectError objectError : globalErrors) {
      errors.add(objectError.getObjectName() + ", " + objectError.getDefaultMessage());
    }
    error.setDescription(errors.toString());

    log.info(e);
    return new ResponseEntity(error, HttpStatus.BAD_REQUEST);
  }

  @Override
  protected ResponseEntity<Object> handleHttpMessageNotReadable(
      HttpMessageNotReadableException e,
      HttpHeaders headers,
      HttpStatus status,
      WebRequest request) {
    ErrorDto error = getErrorDto(HttpStatus.BAD_REQUEST, e.getMessage());
    Throwable mostSpecificCause = e.getMostSpecificCause();
    if (mostSpecificCause != null) {
      String exceptionName = mostSpecificCause.getClass().getName();
      String message = mostSpecificCause.getMessage();
      error.setDescription(exceptionName + ": " + message);
    }

    log.info(e);
    return new ResponseEntity(error, HttpStatus.BAD_REQUEST);
  }

  @Override
  protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(
      HttpMediaTypeNotSupportedException e,
      HttpHeaders headers,
      HttpStatus status,
      WebRequest request) {
    ErrorDto error = getErrorDto(HttpStatus.BAD_REQUEST, e.getMessage());

    log.info(e);
    return new ResponseEntity(error, HttpStatus.BAD_REQUEST);
  }

  @Override
  public ResponseEntity<Object> handleServletRequestBindingException(
      ServletRequestBindingException e,
      HttpHeaders headers,
      HttpStatus status,
      WebRequest request) {
    ErrorDto error = getErrorDto(HttpStatus.BAD_REQUEST, e.getMessage());

    log.info(e);
    return new ResponseEntity(error, HttpStatus.BAD_REQUEST);
  }

  @Override
  public ResponseEntity<Object> handleHttpRequestMethodNotSupported(
      HttpRequestMethodNotSupportedException e,
      HttpHeaders headers,
      HttpStatus status,
      WebRequest request) {
    ErrorDto error = getErrorDto(HttpStatus.METHOD_NOT_ALLOWED, e.getMessage());

    log.info(e);
    return new ResponseEntity(error, HttpStatus.METHOD_NOT_ALLOWED);
  }

  @ExceptionHandler(value = NoSuchElementException.class)
  public ResponseEntity<Object> handleNoSuchElementException(NoSuchElementException e) {
    ErrorDto error = getErrorDto(HttpStatus.NOT_FOUND, e.getMessage());

    log.info(e);
    return new ResponseEntity(error, HttpStatus.NOT_FOUND);
  }

  @ExceptionHandler(value = Exception.class)
  public ResponseEntity<Object> handleUnexpectedException(Exception e) {
    ErrorDto error = getErrorDto(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
    log.error(e);
    return new ResponseEntity(error, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @ExceptionHandler(value = ValidationException.class)
  public ResponseEntity<ErrorDto> handleValidationException(ValidationException e) {
    ErrorDto error = getErrorDto(HttpStatus.BAD_REQUEST, e.getMessage());

    log.warn(e);
    return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler(value = LimitExceededException.class)
  public ResponseEntity<ErrorDto> handleLimitExceededException(LimitExceededException e) {
    ErrorDto error = getErrorDto(HttpStatus.BAD_REQUEST, e.getMessage());

    log.warn(e);
    return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
  }

  @NotNull
  private ErrorDto getErrorDto(HttpStatus httpStatus, String message) {
    ErrorDto error = new ErrorDto();
    error.setCode(Integer.toString(httpStatus.value()));
    error.setTitle(httpStatus.getReasonPhrase());
    error.setDescription(message);
    return error;
  }
}
