package com.stratio.financial.one.trade.transactions.infrastructure.es;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Include {

  private String type;
  private Condition condition;
}
