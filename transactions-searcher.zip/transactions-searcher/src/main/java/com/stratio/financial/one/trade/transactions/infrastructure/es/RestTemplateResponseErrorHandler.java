package com.stratio.financial.one.trade.transactions.infrastructure.es;

import static org.springframework.http.HttpStatus.Series.CLIENT_ERROR;
import static org.springframework.http.HttpStatus.Series.SERVER_ERROR;

import java.io.IOException;
import java.nio.charset.Charset;

import lombok.extern.log4j.Log4j2;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;
import org.springframework.web.client.DefaultResponseErrorHandler;

@Component
@Log4j2
public class RestTemplateResponseErrorHandler
    extends DefaultResponseErrorHandler {


  @Override
  public boolean hasError(ClientHttpResponse httpResponse)
      throws IOException {

    return (
        httpResponse.getStatusCode().series() == CLIENT_ERROR
            || httpResponse.getStatusCode().series() == SERVER_ERROR);
  }

  @Override
  public void handleError(ClientHttpResponse response)
      throws IOException {
    if (!response.getStatusCode().is2xxSuccessful()) {
      log.error("StratioSearcherRepository object response error, Status code  : {}"
              + " Status text  : {} Headers      : {} Response body: {}", response.getStatusCode(),
          response.getStatusText(), response.getHeaders(),
          StreamUtils.copyToString(response.getBody(), Charset.defaultCharset()));
    }
  }
}