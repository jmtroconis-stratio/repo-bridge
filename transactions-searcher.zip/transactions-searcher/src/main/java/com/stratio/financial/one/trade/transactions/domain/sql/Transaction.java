package com.stratio.financial.one.trade.transactions.domain.sql;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import java.math.BigDecimal;
import java.time.Instant;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "transaction")
@ToString(exclude = {"transactionCompanyAccount"})
public class Transaction {

  @EmbeddedId
  private TransactionId transactionId;

  private Instant accountingDate;

  private String additionalInformation;

  private Instant creationDate;

  private String customerAdditionalInformation;

  private String customerTransactionCode;

  private String customerTransactionDescription;

  private String description;

  private String localTransactionCode;

  private String localTransactionDescription;

  private Instant processedDate;

  private String swiftCode;

  private BigDecimal transactionAmount;

  private String transactionAmountCurrency;

  private BigDecimal transactionBalanceAmount;

  private String transactionBalanceAmountCurrency;

  private String transactionBatchReference;

  private String transactionCategory;

  private String transactionClientReference;

  private String transactionInternalReference;

  private String transactionType;

  @JsonProperty(access = Access.WRITE_ONLY)
  private boolean indexed = false;

  @JsonProperty(access = Access.WRITE_ONLY)
  private String transactionIndexPk;

  private String gtsExtractId;

  @ManyToOne
  @JoinColumns({
      @JoinColumn(name = "accountId", insertable = false, updatable = false),
      @JoinColumn(name = "country", insertable = false, updatable = false)
  })
  private TransactionCompanyAccount transactionCompanyAccount;
}