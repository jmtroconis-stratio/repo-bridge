package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsDataListItemTransactionDetailsOperationCustomerOperationDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsDataListItemTransactionDetailsOperationLocalOperationDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TransactionsDataListItemTransactionDetailsOperationDto
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-14T15:45:20.224+02:00")

public class TransactionsDataListItemTransactionDetailsOperationDto   {
  @JsonProperty("swiftCode")
  private String swiftCode = null;

  @JsonProperty("localOperation")
  private TransactionsDataListItemTransactionDetailsOperationLocalOperationDto localOperation = null;

  @JsonProperty("customerOperation")
  private TransactionsDataListItemTransactionDetailsOperationCustomerOperationDto customerOperation = null;

  public TransactionsDataListItemTransactionDetailsOperationDto swiftCode(String swiftCode) {
    this.swiftCode = swiftCode;
    return this;
  }

   /**
   * Get swiftCode
   * @return swiftCode
  **/
  @ApiModelProperty(value = "")


  public String getSwiftCode() {
    return swiftCode;
  }

  public void setSwiftCode(String swiftCode) {
    this.swiftCode = swiftCode;
  }

  public TransactionsDataListItemTransactionDetailsOperationDto localOperation(TransactionsDataListItemTransactionDetailsOperationLocalOperationDto localOperation) {
    this.localOperation = localOperation;
    return this;
  }

   /**
   * Get localOperation
   * @return localOperation
  **/
  @ApiModelProperty(value = "")

  @Valid

  public TransactionsDataListItemTransactionDetailsOperationLocalOperationDto getLocalOperation() {
    return localOperation;
  }

  public void setLocalOperation(TransactionsDataListItemTransactionDetailsOperationLocalOperationDto localOperation) {
    this.localOperation = localOperation;
  }

  public TransactionsDataListItemTransactionDetailsOperationDto customerOperation(TransactionsDataListItemTransactionDetailsOperationCustomerOperationDto customerOperation) {
    this.customerOperation = customerOperation;
    return this;
  }

   /**
   * Get customerOperation
   * @return customerOperation
  **/
  @ApiModelProperty(value = "")

  @Valid

  public TransactionsDataListItemTransactionDetailsOperationCustomerOperationDto getCustomerOperation() {
    return customerOperation;
  }

  public void setCustomerOperation(TransactionsDataListItemTransactionDetailsOperationCustomerOperationDto customerOperation) {
    this.customerOperation = customerOperation;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TransactionsDataListItemTransactionDetailsOperationDto transactionsDataListItemTransactionDetailsOperation = (TransactionsDataListItemTransactionDetailsOperationDto) o;
    return Objects.equals(this.swiftCode, transactionsDataListItemTransactionDetailsOperation.swiftCode) &&
        Objects.equals(this.localOperation, transactionsDataListItemTransactionDetailsOperation.localOperation) &&
        Objects.equals(this.customerOperation, transactionsDataListItemTransactionDetailsOperation.customerOperation);
  }

  @Override
  public int hashCode() {
    return Objects.hash(swiftCode, localOperation, customerOperation);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TransactionsDataListItemTransactionDetailsOperationDto {\n");
    
    sb.append("    swiftCode: ").append(toIndentedString(swiftCode)).append("\n");
    sb.append("    localOperation: ").append(toIndentedString(localOperation)).append("\n");
    sb.append("    customerOperation: ").append(toIndentedString(customerOperation)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

