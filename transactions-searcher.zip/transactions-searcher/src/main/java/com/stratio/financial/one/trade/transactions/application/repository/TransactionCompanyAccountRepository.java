package com.stratio.financial.one.trade.transactions.application.repository;

import java.util.Optional;

import com.stratio.financial.one.trade.transactions.domain.sql.TransactionCompanyAccount;
import com.stratio.financial.one.trade.transactions.domain.sql.TransactionCompanyAccountId;

public interface TransactionCompanyAccountRepository {

  TransactionCompanyAccount upsert(TransactionCompanyAccount transactionCompanyAccount);

  Optional<TransactionCompanyAccount> findById(TransactionCompanyAccountId transactionCompanyAccountId);

  void deleteAll();

}
