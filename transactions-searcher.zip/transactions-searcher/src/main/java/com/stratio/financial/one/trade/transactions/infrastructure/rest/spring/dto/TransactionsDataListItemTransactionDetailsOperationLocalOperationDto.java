package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TransactionsDataListItemTransactionDetailsOperationLocalOperationDto
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-14T15:45:20.224+02:00")

public class TransactionsDataListItemTransactionDetailsOperationLocalOperationDto   {
  @JsonProperty("ltcCode")
  private String ltcCode = null;

  @JsonProperty("ltcDescription")
  private String ltcDescription = null;

  @JsonProperty("aditionalInformation")
  private String aditionalInformation = null;

  public TransactionsDataListItemTransactionDetailsOperationLocalOperationDto ltcCode(String ltcCode) {
    this.ltcCode = ltcCode;
    return this;
  }

   /**
   * Get ltcCode
   * @return ltcCode
  **/
  @ApiModelProperty(value = "")


  public String getLtcCode() {
    return ltcCode;
  }

  public void setLtcCode(String ltcCode) {
    this.ltcCode = ltcCode;
  }

  public TransactionsDataListItemTransactionDetailsOperationLocalOperationDto ltcDescription(String ltcDescription) {
    this.ltcDescription = ltcDescription;
    return this;
  }

   /**
   * Get ltcDescription
   * @return ltcDescription
  **/
  @ApiModelProperty(value = "")


  public String getLtcDescription() {
    return ltcDescription;
  }

  public void setLtcDescription(String ltcDescription) {
    this.ltcDescription = ltcDescription;
  }

  public TransactionsDataListItemTransactionDetailsOperationLocalOperationDto aditionalInformation(String aditionalInformation) {
    this.aditionalInformation = aditionalInformation;
    return this;
  }

   /**
   * Get aditionalInformation
   * @return aditionalInformation
  **/
  @ApiModelProperty(value = "")


  public String getAditionalInformation() {
    return aditionalInformation;
  }

  public void setAditionalInformation(String aditionalInformation) {
    this.aditionalInformation = aditionalInformation;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TransactionsDataListItemTransactionDetailsOperationLocalOperationDto transactionsDataListItemTransactionDetailsOperationLocalOperation = (TransactionsDataListItemTransactionDetailsOperationLocalOperationDto) o;
    return Objects.equals(this.ltcCode, transactionsDataListItemTransactionDetailsOperationLocalOperation.ltcCode) &&
        Objects.equals(this.ltcDescription, transactionsDataListItemTransactionDetailsOperationLocalOperation.ltcDescription) &&
        Objects.equals(this.aditionalInformation, transactionsDataListItemTransactionDetailsOperationLocalOperation.aditionalInformation);
  }

  @Override
  public int hashCode() {
    return Objects.hash(ltcCode, ltcDescription, aditionalInformation);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TransactionsDataListItemTransactionDetailsOperationLocalOperationDto {\n");
    
    sb.append("    ltcCode: ").append(toIndentedString(ltcCode)).append("\n");
    sb.append("    ltcDescription: ").append(toIndentedString(ltcDescription)).append("\n");
    sb.append("    aditionalInformation: ").append(toIndentedString(aditionalInformation)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

