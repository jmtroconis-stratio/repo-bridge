package com.stratio.financial.one.trade.transactions.application.service.impl;

import java.util.List;

import com.stratio.financial.one.trade.transactions.application.repository.AgentRepository;
import com.stratio.financial.one.trade.transactions.application.service.AgentService;
import com.stratio.financial.one.trade.transactions.domain.sql.Agent;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j2;

@AllArgsConstructor
@Log4j2
public class AgentServiceImpl implements AgentService {

  private AgentRepository agentRepository;

  @Override
  public Agent saveAgent(Agent agent) {
    return agentRepository.saveAgent(agent);
  }

  @Override
  public List<Agent> findAllAgents(List<String> bicList) {
    return agentRepository.findAllAgents(bicList);
  }
}
