package com.stratio.financial.one.trade.transactions.infrastructure.es;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@EqualsAndHashCode
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Query {

  private String text;
  private String type;
  private Map<String, Integer> fields;

  public Query() {
    this.fields = new HashMap<>();
  }
}
