package com.stratio.financial.one.trade.transactions.application.service;

import java.util.List;

import com.stratio.financial.one.trade.transactions.domain.search.AccountsCountriesList;
import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;

public interface TransactionService {

  List<Transaction> getLastTransactionsDateTime(AccountsCountriesList accountsCountriesList);

}
