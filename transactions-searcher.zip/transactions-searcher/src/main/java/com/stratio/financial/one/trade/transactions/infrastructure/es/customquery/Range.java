package com.stratio.financial.one.trade.transactions.infrastructure.es.customquery;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Range {

  private Object gte;
  private Object lte;
  private Object gt;
  private Object lt;

}