package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TransactionsDataListItemTransactionDetailsOperationCustomerOperationDto
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-14T15:45:20.224+02:00")

public class TransactionsDataListItemTransactionDetailsOperationCustomerOperationDto   {
  @JsonProperty("customerAditionalInformation")
  private String customerAditionalInformation = null;

  @JsonProperty("customerTCode")
  private String customerTCode = null;

  @JsonProperty("customerTDescription")
  private String customerTDescription = null;

  public TransactionsDataListItemTransactionDetailsOperationCustomerOperationDto customerAditionalInformation(String customerAditionalInformation) {
    this.customerAditionalInformation = customerAditionalInformation;
    return this;
  }

   /**
   * Get customerAditionalInformation
   * @return customerAditionalInformation
  **/
  @ApiModelProperty(value = "")


  public String getCustomerAditionalInformation() {
    return customerAditionalInformation;
  }

  public void setCustomerAditionalInformation(String customerAditionalInformation) {
    this.customerAditionalInformation = customerAditionalInformation;
  }

  public TransactionsDataListItemTransactionDetailsOperationCustomerOperationDto customerTCode(String customerTCode) {
    this.customerTCode = customerTCode;
    return this;
  }

   /**
   * Get customerTCode
   * @return customerTCode
  **/
  @ApiModelProperty(value = "")


  public String getCustomerTCode() {
    return customerTCode;
  }

  public void setCustomerTCode(String customerTCode) {
    this.customerTCode = customerTCode;
  }

  public TransactionsDataListItemTransactionDetailsOperationCustomerOperationDto customerTDescription(String customerTDescription) {
    this.customerTDescription = customerTDescription;
    return this;
  }

   /**
   * Get customerTDescription
   * @return customerTDescription
  **/
  @ApiModelProperty(value = "")


  public String getCustomerTDescription() {
    return customerTDescription;
  }

  public void setCustomerTDescription(String customerTDescription) {
    this.customerTDescription = customerTDescription;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TransactionsDataListItemTransactionDetailsOperationCustomerOperationDto transactionsDataListItemTransactionDetailsOperationCustomerOperation = (TransactionsDataListItemTransactionDetailsOperationCustomerOperationDto) o;
    return Objects.equals(this.customerAditionalInformation, transactionsDataListItemTransactionDetailsOperationCustomerOperation.customerAditionalInformation) &&
        Objects.equals(this.customerTCode, transactionsDataListItemTransactionDetailsOperationCustomerOperation.customerTCode) &&
        Objects.equals(this.customerTDescription, transactionsDataListItemTransactionDetailsOperationCustomerOperation.customerTDescription);
  }

  @Override
  public int hashCode() {
    return Objects.hash(customerAditionalInformation, customerTCode, customerTDescription);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TransactionsDataListItemTransactionDetailsOperationCustomerOperationDto {\n");
    
    sb.append("    customerAditionalInformation: ").append(toIndentedString(customerAditionalInformation)).append("\n");
    sb.append("    customerTCode: ").append(toIndentedString(customerTCode)).append("\n");
    sb.append("    customerTDescription: ").append(toIndentedString(customerTDescription)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

