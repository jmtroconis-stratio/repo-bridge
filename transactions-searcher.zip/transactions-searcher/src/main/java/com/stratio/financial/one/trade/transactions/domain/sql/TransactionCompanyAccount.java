package com.stratio.financial.one.trade.transactions.domain.sql;

import java.util.List;

import javax.persistence.EmbeddedId;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@Entity
@ToString
@Table(name = "transaction_company_account")
public class TransactionCompanyAccount {

  @EmbeddedId
  private TransactionCompanyAccountId transactionCompanyAccountId;

  private String displayNumber;

  private String alias;

  @ManyToOne
  @JoinColumn(name = "bic")
  private Agent agent;

  private String accountIdType;

  private String iban;

  @JsonIgnore
  @OneToMany(mappedBy = "transactionCompanyAccount", fetch = FetchType.LAZY)
  private List<Transaction> transactions;

}