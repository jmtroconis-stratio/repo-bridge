package com.stratio.financial.one.trade.transactions.domain.search;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@NoArgsConstructor
@ToString
public class RequestQuery {

  @JsonProperty("typeOfTransaction")
  private Boolean typeOfTransaction = null;

  @JsonProperty("accountsCountriesList")
  private List<AccountsCountry> accountsCountriesList = new ArrayList<AccountsCountry>();

  @JsonProperty("from_date")
  private String fromDate = null;

  @JsonProperty("to_date")
  private String toDate = null;

  @JsonProperty("from_amount")
  private Double fromAmount = null;

  @JsonProperty("to_amount")
  private Double toAmount = null;

  @JsonProperty("swift_codes")
  private List<String> swiftCodes = null;

  @JsonProperty("transactionType")
  private String transactionType = null;

  @JsonProperty("client_reference")
  private String clientReference = null;

  @JsonProperty("description")
  private String description = null;

  @JsonProperty("_from")
  private Integer from = null;

  @JsonProperty("_limit")
  private Integer limit = null;

  @JsonProperty("_sort")
  private String sort = null;

  @JsonProperty("amountFormat")
  private String amountFormat = null;

  @JsonProperty("dateFormat")
  private String dateFormat = null;

}
