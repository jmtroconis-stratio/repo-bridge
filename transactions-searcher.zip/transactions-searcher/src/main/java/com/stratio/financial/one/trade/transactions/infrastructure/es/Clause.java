package com.stratio.financial.one.trade.transactions.infrastructure.es;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Clause {
  private String type;
  private Condition condition;
  private List<Clause> clauses;
}
