package com.stratio.financial.one.trade.transactions.application.service;

import java.util.List;

import com.stratio.financial.one.trade.transactions.domain.sql.Agent;

public interface AgentService {
  Agent saveAgent(Agent agent);

  List<Agent> findAllAgents(List<String> bicList);
}
