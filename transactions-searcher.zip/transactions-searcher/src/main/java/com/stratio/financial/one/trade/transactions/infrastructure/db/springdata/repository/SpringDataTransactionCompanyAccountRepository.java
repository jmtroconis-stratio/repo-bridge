package com.stratio.financial.one.trade.transactions.infrastructure.db.springdata.repository;

import com.stratio.financial.one.trade.transactions.domain.sql.TransactionCompanyAccount;
import com.stratio.financial.one.trade.transactions.domain.sql.TransactionCompanyAccountId;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SpringDataTransactionCompanyAccountRepository extends CrudRepository<TransactionCompanyAccount,
    TransactionCompanyAccountId> {
}
