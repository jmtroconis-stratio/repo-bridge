package com.stratio.financial.one.trade.transactions.infrastructure.es;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ElasticQuery {

  private Integer from;
  private Integer size;
  private List<String> includes;
  private Query query;
  private Filter filters;
  private List<Sort> sorts;

  public ElasticQuery() {
    this.sorts = new ArrayList<>();
  }
}
