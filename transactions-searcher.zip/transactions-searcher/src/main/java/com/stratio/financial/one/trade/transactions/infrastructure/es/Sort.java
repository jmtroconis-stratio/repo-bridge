package com.stratio.financial.one.trade.transactions.infrastructure.es;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Sort {
  private String field;
  private String apply;
  private String order;

}
