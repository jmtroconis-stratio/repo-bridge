package com.stratio.financial.one.trade.transactions.infrastructure.db.springdata.repository;

import com.stratio.financial.one.trade.transactions.application.repository.CountryRepository;
import com.stratio.financial.one.trade.transactions.domain.sql.Country;
import org.springframework.data.repository.CrudRepository;

public interface SpringDataCountryRepository extends CrudRepository<Country, String>,
    CountryRepository {

}
