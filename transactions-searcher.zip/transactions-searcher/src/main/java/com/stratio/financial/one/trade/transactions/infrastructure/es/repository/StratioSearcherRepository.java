package com.stratio.financial.one.trade.transactions.infrastructure.es.repository;

import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stratio.financial.one.trade.transactions.application.repository.TransactionDataRepository;
import com.stratio.financial.one.trade.transactions.domain.data.DocumentsData;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionData;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionSummaryData;
import com.stratio.financial.one.trade.transactions.domain.search.RequestQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.ElasticQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.RestTemplateException;
import com.stratio.financial.one.trade.transactions.infrastructure.es.customquery.ElasticCustomQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.parser.TransactionRequestCustomQueryParser;
import com.stratio.financial.one.trade.transactions.infrastructure.es.parser.TransactionRequestParser;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@AllArgsConstructor
@Log4j2
public class StratioSearcherRepository implements TransactionDataRepository {

  private final ObjectMapper objectMapper = new ObjectMapper()
      .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

  private final String searcher;
  private final String indexer;
  private final String domain;
  private final String customQueryName;

  private final RestTemplate restTemplate;
  private final TransactionRequestParser transactionRequestParser;
  private final TransactionRequestCustomQueryParser transactionRequestCustomQueryParser;

  @Override
  public void index(List<TransactionData> transactionDataList) throws RestTemplateException {
    ResponseEntity<String> response = null;
    try {
      URI uri = createUri(indexer + domain + "/partial");

      RequestEntity<List<TransactionData>> request = new RequestEntity<>(transactionDataList,
          completeHeadersSimple(),
          HttpMethod.PUT, uri);
      response = this.restTemplate.exchange(request, String.class);

      log.debug("StratioSearcherRepository partial indexation response: " + response.getBody());
    } catch (Exception e) {
      throw new RestTemplateException(( ClientHttpResponse ) response);
    }
  }

  @Override
  public void delete(List<TransactionData> transactionDataList) throws RestTemplateException {
    ResponseEntity<String> response = null;
    try {
      URI uri = createUri(indexer + domain + "/partial");

      RequestEntity<List<TransactionData>> request = new RequestEntity<>(transactionDataList,
          completeHeadersSimple(),
          HttpMethod.DELETE, uri);
      response = this.restTemplate.exchange(request, String.class);

      log.debug("StratioSearcherRepository partial deletion response: " + response.getBody());
    } catch (Exception e) {
      throw new RestTemplateException(( ClientHttpResponse ) response);
    }
  }

  /**
   * search transactions.
   *
   * @return transactions
   **/
  @Override
  public TransactionSummaryData search(RequestQuery requestQuery) {
    ElasticCustomQuery query = transactionRequestCustomQueryParser.parse(requestQuery);
    return getTransactionSummaryData(query);
  }

  @Override
  public TransactionSummaryData searchToDate(String date, Integer from, Integer size, Boolean consolidated) {
    ElasticQuery query = transactionRequestParser.parseToDate(date, from, size, consolidated);
    return getTransactionSummaryData(query);
  }

  @NotNull
  private TransactionSummaryData getTransactionSummaryData(ElasticQuery query) {
    URI uri = createUri(searcher + domain + "/search");

    DocumentsData documentsData = new DocumentsData(BigDecimal.valueOf(0), BigDecimal.valueOf(0));
    RequestEntity<ElasticQuery> request = new RequestEntity<>(query, completeHeadersSimple(), HttpMethod.POST, uri);
    ResponseEntity<String> response = this.restTemplate.exchange(request, String.class);
    log.debug("StratioSearcherRepository search response: " + response.getBody());
    List<TransactionData> transactions;
    try {
      //FIXME refactor move try to TransactionDataMapper
      JsonNode body = objectMapper.readTree(response.getBody());
      JsonNode documents = body.get("documents");

      transactions = objectMapper.readValue(String.valueOf(documents.get("documents")),
          new TypeReference<List<TransactionData>>() {});

      documentsData.setTotalRegistersFound(BigDecimal.valueOf(Long.parseLong(String.valueOf(documents.get("total")))));
      documentsData.setRetrieved(BigDecimal.valueOf(Long.parseLong(String.valueOf(documents.get("retrieved")))));

    } catch (IOException ex) {
      log.error("Error when deserialize data: " + ex.getMessage());
      throw new IllegalArgumentException("Error when deserializing data");
    }
    return new TransactionSummaryData(transactions, documentsData);
  }

  @NotNull
  private TransactionSummaryData getTransactionSummaryData(ElasticCustomQuery query) {
    URI uri = createUri(searcher + domain + "/search/" + customQueryName);

    DocumentsData documentsData = new DocumentsData(BigDecimal.valueOf(0), BigDecimal.valueOf(0));
    RequestEntity<ElasticCustomQuery> request = new RequestEntity<>(query,
        completeHeadersSimple(), HttpMethod.POST, uri);
    ResponseEntity<String> response = this.restTemplate.exchange(request, String.class);
    log.debug("StratioSearcherRepository custom search response: " + response.getBody());
    List<TransactionData> transactions;
    try {
      //FIXME refactor move try to TransactionDataMapper
      JsonNode body = objectMapper.readTree(response.getBody());
      JsonNode documents = body.at("/esResponse/hits/hits");

      if (documents.isArray()) {
        transactions = new ArrayList(documents.size());
        for (final JsonNode document : documents) {
          transactions.add(objectMapper.readValue(String.valueOf(document.get("_source")), TransactionData.class));
        }
      } else {
        transactions = new ArrayList(0);
      }

      documentsData.setTotalRegistersFound(new BigDecimal(body.at("/esResponse/hits/total/value").bigIntegerValue()));
      documentsData.setRetrieved(BigDecimal.valueOf(transactions.size()));
    } catch (IOException ex) {
      log.error("Error when deserialize data: " + ex.getMessage());
      throw new IllegalArgumentException("Error when deserializing data");
    }
    return new TransactionSummaryData(transactions, documentsData);
  }

  private MultiValueMap<String, String> completeHeadersSimple() {
    MultiValueMap<String, String> headers = new HttpHeaders();
    headers.add(CONTENT_TYPE, APPLICATION_JSON_VALUE);
    return headers;
  }

  private URI createUri(String url) {
    return UriComponentsBuilder.fromUriString(url).build().expand().encode().toUri();
  }
}
