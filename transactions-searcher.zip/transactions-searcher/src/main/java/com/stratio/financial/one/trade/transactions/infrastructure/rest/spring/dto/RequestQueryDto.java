package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.AccountsCountryDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RequestQueryDto
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-14T15:45:20.224+02:00")

public class RequestQueryDto   {
  @JsonProperty("typeOfTransaction")
  private Boolean typeOfTransaction = null;

  @JsonProperty("accountsCountriesList")
  private List<AccountsCountryDto> accountsCountriesList = new ArrayList<AccountsCountryDto>();

  @JsonProperty("from_date")
  private String fromDate = null;

  @JsonProperty("to_date")
  private String toDate = null;

  @JsonProperty("from_amount")
  private Double fromAmount = null;

  @JsonProperty("to_amount")
  private Double toAmount = null;

  @JsonProperty("swift_codes")
  private List<String> swiftCodes = null;

  @JsonProperty("transactionType")
  private String transactionType = null;

  @JsonProperty("client_reference")
  private String clientReference = null;

  @JsonProperty("description")
  private String description = null;

  @JsonProperty("_offset")
  private Integer offset = null;

  @JsonProperty("_limit")
  private Integer limit = null;

  @JsonProperty("_sort")
  private String sort = null;

  @JsonProperty("amountFormat")
  private String amountFormat = null;

  @JsonProperty("dateFormat")
  private String dateFormat = null;

  public RequestQueryDto typeOfTransaction(Boolean typeOfTransaction) {
    this.typeOfTransaction = typeOfTransaction;
    return this;
  }

   /**
   * Show only consolidated (false) or not consolidated and consolidated (true)
   * @return typeOfTransaction
  **/
  @ApiModelProperty(required = true, value = "Show only consolidated (false) or not consolidated and consolidated (true)")
  @NotNull


  public Boolean getTypeOfTransaction() {
    return typeOfTransaction;
  }

  public void setTypeOfTransaction(Boolean typeOfTransaction) {
    this.typeOfTransaction = typeOfTransaction;
  }

  public RequestQueryDto accountsCountriesList(List<AccountsCountryDto> accountsCountriesList) {
    this.accountsCountriesList = accountsCountriesList;
    return this;
  }

  public RequestQueryDto addAccountsCountriesListItem(AccountsCountryDto accountsCountriesListItem) {
    this.accountsCountriesList.add(accountsCountriesListItem);
    return this;
  }

   /**
   * A list of accounts and countries to search
   * @return accountsCountriesList
  **/
  @ApiModelProperty(required = true, value = "A list of accounts and countries to search")
  @NotNull

  @Valid

  public List<AccountsCountryDto> getAccountsCountriesList() {
    return accountsCountriesList;
  }

  public void setAccountsCountriesList(List<AccountsCountryDto> accountsCountriesList) {
    this.accountsCountriesList = accountsCountriesList;
  }

  public RequestQueryDto fromDate(String fromDate) {
    this.fromDate = fromDate;
    return this;
  }

   /**
   * Start date period to be considered for the retrieve of transaction (YYYY-mm-DDTHH:MM:SS+xxxx)
   * @return fromDate
  **/
  @ApiModelProperty(value = "Start date period to be considered for the retrieve of transaction (YYYY-mm-DDTHH:MM:SS+xxxx)")

 @Pattern(regexp="^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d{3})?\\+\\d{4}$")
  public String getFromDate() {
    return fromDate;
  }

  public void setFromDate(String fromDate) {
    this.fromDate = fromDate;
  }

  public RequestQueryDto toDate(String toDate) {
    this.toDate = toDate;
    return this;
  }

   /**
   * End date period to be considered for the retrieve of transaction (YYYY-mm-DDTHH:MM:SSZ+xxxx)
   * @return toDate
  **/
  @ApiModelProperty(value = "End date period to be considered for the retrieve of transaction (YYYY-mm-DDTHH:MM:SSZ+xxxx)")

 @Pattern(regexp="^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d{3})?\\+\\d{4}$")
  public String getToDate() {
    return toDate;
  }

  public void setToDate(String toDate) {
    this.toDate = toDate;
  }

  public RequestQueryDto fromAmount(Double fromAmount) {
    this.fromAmount = fromAmount;
    return this;
  }

   /**
   * Minimum amount of transactions to retrieve. Allows negative and positive amounts
   * @return fromAmount
  **/
  @ApiModelProperty(value = "Minimum amount of transactions to retrieve. Allows negative and positive amounts")


  public Double getFromAmount() {
    return fromAmount;
  }

  public void setFromAmount(Double fromAmount) {
    this.fromAmount = fromAmount;
  }

  public RequestQueryDto toAmount(Double toAmount) {
    this.toAmount = toAmount;
    return this;
  }

   /**
   * Maximum amount of transactions to retrieve. Allows negative and positive amounts
   * @return toAmount
  **/
  @ApiModelProperty(value = "Maximum amount of transactions to retrieve. Allows negative and positive amounts")


  public Double getToAmount() {
    return toAmount;
  }

  public void setToAmount(Double toAmount) {
    this.toAmount = toAmount;
  }

  public RequestQueryDto swiftCodes(List<String> swiftCodes) {
    this.swiftCodes = swiftCodes;
    return this;
  }

  public RequestQueryDto addSwiftCodesItem(String swiftCodesItem) {
    if (this.swiftCodes == null) {
      this.swiftCodes = new ArrayList<String>();
    }
    this.swiftCodes.add(swiftCodesItem);
    return this;
  }

   /**
   * Determinate the swift code for a transaction which only contains 3 characters
   * @return swiftCodes
  **/
  @ApiModelProperty(value = "Determinate the swift code for a transaction which only contains 3 characters")


  public List<String> getSwiftCodes() {
    return swiftCodes;
  }

  public void setSwiftCodes(List<String> swiftCodes) {
    this.swiftCodes = swiftCodes;
  }

  public RequestQueryDto transactionType(String transactionType) {
    this.transactionType = transactionType;
    return this;
  }

   /**
   * Type of transaction. Represents if the transaction increases (Credit) or decreases (Debit) the balance of the account. Possible values: debit / credit. If not informed, all transactions are considered (debit and credit).
   * @return transactionType
  **/
  @ApiModelProperty(value = "Type of transaction. Represents if the transaction increases (Credit) or decreases (Debit) the balance of the account. Possible values: debit / credit. If not informed, all transactions are considered (debit and credit).")


  public String getTransactionType() {
    return transactionType;
  }

  public void setTransactionType(String transactionType) {
    this.transactionType = transactionType;
  }

  public RequestQueryDto clientReference(String clientReference) {
    this.clientReference = clientReference;
    return this;
  }

   /**
   * Client reference field. Free write
   * @return clientReference
  **/
  @ApiModelProperty(value = "Client reference field. Free write")


  public String getClientReference() {
    return clientReference;
  }

  public void setClientReference(String clientReference) {
    this.clientReference = clientReference;
  }

  public RequestQueryDto description(String description) {
    this.description = description;
    return this;
  }

   /**
   * Description field. Free write. Minimum: 3 characters. Maximum: 390 characters
   * @return description
  **/
  @ApiModelProperty(value = "Description field. Free write. Minimum: 3 characters. Maximum: 390 characters")


  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public RequestQueryDto offset(Integer offset) {
    this.offset = offset;
    return this;
  }

   /**
   * Number of Register to return from the search
   * @return offset
  **/
  @ApiModelProperty(value = "Number of Register to return from the search")


  public Integer getOffset() {
    return offset;
  }

  public void setOffset(Integer offset) {
    this.offset = offset;
  }

  public RequestQueryDto limit(Integer limit) {
    this.limit = limit;
    return this;
  }

   /**
   * Max Number Registers to return
   * @return limit
  **/
  @ApiModelProperty(value = "Max Number Registers to return")


  public Integer getLimit() {
    return limit;
  }

  public void setLimit(Integer limit) {
    this.limit = limit;
  }

  public RequestQueryDto sort(String sort) {
    this.sort = sort;
    return this;
  }

   /**
   * Get sort
   * @return sort
  **/
  @ApiModelProperty(value = "")


  public String getSort() {
    return sort;
  }

  public void setSort(String sort) {
    this.sort = sort;
  }

  public RequestQueryDto amountFormat(String amountFormat) {
    this.amountFormat = amountFormat;
    return this;
  }

   /**
   * Get amountFormat
   * @return amountFormat
  **/
  @ApiModelProperty(value = "")


  public String getAmountFormat() {
    return amountFormat;
  }

  public void setAmountFormat(String amountFormat) {
    this.amountFormat = amountFormat;
  }

  public RequestQueryDto dateFormat(String dateFormat) {
    this.dateFormat = dateFormat;
    return this;
  }

   /**
   * Get dateFormat
   * @return dateFormat
  **/
  @ApiModelProperty(value = "")


  public String getDateFormat() {
    return dateFormat;
  }

  public void setDateFormat(String dateFormat) {
    this.dateFormat = dateFormat;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RequestQueryDto requestQuery = (RequestQueryDto) o;
    return Objects.equals(this.typeOfTransaction, requestQuery.typeOfTransaction) &&
        Objects.equals(this.accountsCountriesList, requestQuery.accountsCountriesList) &&
        Objects.equals(this.fromDate, requestQuery.fromDate) &&
        Objects.equals(this.toDate, requestQuery.toDate) &&
        Objects.equals(this.fromAmount, requestQuery.fromAmount) &&
        Objects.equals(this.toAmount, requestQuery.toAmount) &&
        Objects.equals(this.swiftCodes, requestQuery.swiftCodes) &&
        Objects.equals(this.transactionType, requestQuery.transactionType) &&
        Objects.equals(this.clientReference, requestQuery.clientReference) &&
        Objects.equals(this.description, requestQuery.description) &&
        Objects.equals(this.offset, requestQuery.offset) &&
        Objects.equals(this.limit, requestQuery.limit) &&
        Objects.equals(this.sort, requestQuery.sort) &&
        Objects.equals(this.amountFormat, requestQuery.amountFormat) &&
        Objects.equals(this.dateFormat, requestQuery.dateFormat);
  }

  @Override
  public int hashCode() {
    return Objects.hash(typeOfTransaction, accountsCountriesList, fromDate, toDate, fromAmount, toAmount, swiftCodes, transactionType, clientReference, description, offset, limit, sort, amountFormat, dateFormat);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RequestQueryDto {\n");
    
    sb.append("    typeOfTransaction: ").append(toIndentedString(typeOfTransaction)).append("\n");
    sb.append("    accountsCountriesList: ").append(toIndentedString(accountsCountriesList)).append("\n");
    sb.append("    fromDate: ").append(toIndentedString(fromDate)).append("\n");
    sb.append("    toDate: ").append(toIndentedString(toDate)).append("\n");
    sb.append("    fromAmount: ").append(toIndentedString(fromAmount)).append("\n");
    sb.append("    toAmount: ").append(toIndentedString(toAmount)).append("\n");
    sb.append("    swiftCodes: ").append(toIndentedString(swiftCodes)).append("\n");
    sb.append("    transactionType: ").append(toIndentedString(transactionType)).append("\n");
    sb.append("    clientReference: ").append(toIndentedString(clientReference)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    offset: ").append(toIndentedString(offset)).append("\n");
    sb.append("    limit: ").append(toIndentedString(limit)).append("\n");
    sb.append("    sort: ").append(toIndentedString(sort)).append("\n");
    sb.append("    amountFormat: ").append(toIndentedString(amountFormat)).append("\n");
    sb.append("    dateFormat: ").append(toIndentedString(dateFormat)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

