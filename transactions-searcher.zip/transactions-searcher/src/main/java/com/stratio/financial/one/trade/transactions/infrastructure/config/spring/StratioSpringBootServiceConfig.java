package com.stratio.financial.one.trade.transactions.infrastructure.config.spring;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import javax.net.ssl.SSLContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.stratio.financial.one.trade.transactions.application.repository.AgentRepository;
import com.stratio.financial.one.trade.transactions.application.repository.TransactionCompanyAccountRepository;
import com.stratio.financial.one.trade.transactions.application.repository.TransactionDataRepository;
import com.stratio.financial.one.trade.transactions.application.repository.TransactionRepository;
import com.stratio.financial.one.trade.transactions.application.service.AgentService;
import com.stratio.financial.one.trade.transactions.application.service.TransactionService;
import com.stratio.financial.one.trade.transactions.application.service.impl.AgentServiceImpl;
import com.stratio.financial.one.trade.transactions.application.service.impl.TransactionServiceImpl;
import com.stratio.financial.one.trade.transactions.infrastructure.es.RestTemplateResponseErrorHandler;
import com.stratio.financial.one.trade.transactions.infrastructure.es.mapper.TransactionDataMapper;
import com.stratio.financial.one.trade.transactions.infrastructure.es.parser.TransactionRequestCustomQueryParser;
import com.stratio.financial.one.trade.transactions.infrastructure.es.parser.TransactionRequestParser;
import com.stratio.financial.one.trade.transactions.infrastructure.es.repository.StratioSearcherRepository;
import com.stratio.financial.one.trade.transactions.infrastructure.es.service.TransactionDataService;
import com.stratio.financial.one.trade.transactions.infrastructure.es.service.impl.TransactionDataServiceImpl;
import org.apache.http.client.HttpClient;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContexts;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import lombok.RequiredArgsConstructor;

@Configuration
@RequiredArgsConstructor
@ComponentScan({"com.stratio.financial.one.trade.transactions"})
public class StratioSpringBootServiceConfig {

  @Value("${elastic.searcher}")
  private String searcher;
  @Value("${elastic.indexer}")
  private String indexer;
  @Value("${elastic.manager}")
  private String manager;
  @Value("${elastic.domain}")
  private String domain;
  @Value("${elastic.customQueryName}")
  private String customQueryName;

  @Bean
  public ObjectMapper objectMapper() {
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
    return objectMapper;
  }

  /**
   * restTemplate.
   */
  @Bean
  public RestTemplate restTemplate() throws KeyStoreException, NoSuchAlgorithmException,
      KeyManagementException {

    HttpComponentsClientHttpRequestFactory requestFactory =
        new HttpComponentsClientHttpRequestFactory(getHttpClientInsecure());
    RestTemplate restTemplate = new RestTemplate(requestFactory);
    restTemplate.setErrorHandler(getErrorHandler());
    return restTemplate;
  }

  private static HttpClient getHttpClientInsecure() throws KeyStoreException,
      NoSuchAlgorithmException, KeyManagementException {
    TrustStrategy acceptingTrustStrategy = (cert, authType) -> true;
    SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy)
        .build();
    SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext,
        NoopHostnameVerifier.INSTANCE);

    Registry<ConnectionSocketFactory> socketFactoryRegistry =
        RegistryBuilder.<ConnectionSocketFactory>create()
            .register("https", sslsf)
            .register("http", new PlainConnectionSocketFactory())
            .build();

    PoolingHttpClientConnectionManager connectionManager
        = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
    connectionManager.setDefaultMaxPerRoute(10);
    connectionManager.setMaxTotal(10);

    return HttpClients.custom().setSSLSocketFactory(sslsf)
        .setConnectionManager(connectionManager)
        .setRetryHandler(new DefaultHttpRequestRetryHandler(3, true))
        .build();
  }

  @Bean
  public RestTemplateResponseErrorHandler getErrorHandler() {
    return new RestTemplateResponseErrorHandler();
  }


  @Bean
  public TransactionService transactionService(
      TransactionCompanyAccountRepository transactionCompanyAccountRepository,
      TransactionRepository transactionRepository) {
    return new TransactionServiceImpl(transactionCompanyAccountRepository, transactionRepository);
  }

  @Bean
  public TransactionDataService transactionDataService(
      TransactionDataRepository transactionDataRepository, TransactionRepository transactionRepository,
      TransactionDataMapper transactionDataMapper) {
    return new TransactionDataServiceImpl(transactionDataRepository, transactionRepository, transactionDataMapper);
  }

  @Bean
  public StratioSearcherRepository stratioSearcherRepository(RestTemplate restTemplate,
      TransactionRequestParser transactionRequestParser,
      TransactionRequestCustomQueryParser transactionRequestCustomQueryParser) {
    return new StratioSearcherRepository(searcher, indexer, domain, customQueryName, restTemplate,
        transactionRequestParser, transactionRequestCustomQueryParser);
  }

  @Bean
  public AgentService agentService(AgentRepository agentRepository) {
    return new AgentServiceImpl(agentRepository);
  }
}
