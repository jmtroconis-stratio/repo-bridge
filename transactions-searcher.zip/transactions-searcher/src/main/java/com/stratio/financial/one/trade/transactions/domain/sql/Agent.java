package com.stratio.financial.one.trade.transactions.domain.sql;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@NoArgsConstructor
@ToString
@Entity
@Table(name = "agent")
public class Agent {

  @Id
  private String bic;

  private String tag;
  private String modificationFlag;
  private String branchInformation;
  private String cityHeading;
  private String subtypeIndication;
  private String valueAddedServices;
  private String extraInfo;
  @Column(name = "physical_address_1")
  private String physicalAddress1;
  @Column(name = "physical_address_2")
  private String physicalAddress2;
  @Column(name = "physical_address_3")
  private String physicalAddress3;
  @Column(name = "physical_address_4")
  private String physicalAddress4;
  private String location;
  private String pobNumber;
  private String pobLocation;
  private String pobCountryName;

  private String institutionName;
  private String countryName;

  private String entityId;

  @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
  @JoinColumn(name = "country_id", referencedColumnName = "country_id")
  private Country country;
}
