package com.stratio.financial.one.trade.transactions.infrastructure.es.customquery;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountCountry {

  private String accountId;
  private String accountIdType;
  private String country;

}
