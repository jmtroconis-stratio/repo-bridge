package com.stratio.financial.one.trade.transactions.domain.data;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class TransactionData {

  public static final DateTimeFormatter transactionDataDateFormat = DateTimeFormatter
      .ofPattern("yyyy-MM-dd'T'HH:mm:ssZ");

  private String transactionPk;
  private String additionalInformation;
  private String accountingDate;
  private BigDecimal transactionBalanceAmount;
  private String transactionClientReference;
  private String description;
  private String swiftCode;
  private String transactionAmountCurrency;
  private String localTransactionCode;
  private String transactionBalanceAmountCurrency;
  private String creationDate;
  private String transactionId;
  private String customerTransactionCode;
  private Boolean transactionConsolidated;
  private String transactionType;
  private String processedDate;
  private String customerTransactionDescription;
  private String localTransactionDescription;
  private String customerAdditionalInformation;
  private BigDecimal transactionAmount;
  private String transactionCategory;
  private String transactionInternalReference;
  private String transactionBatchReference;
  private String gtsExtractId;
  private TransactionCompanyAccountData transactionCompanyAccount;
}
