package com.stratio.financial.one.trade.transactions.application.repository;

import com.stratio.financial.one.trade.transactions.domain.sql.Country;

public interface CountryRepository extends EntityRepository<Country, String> {

}
