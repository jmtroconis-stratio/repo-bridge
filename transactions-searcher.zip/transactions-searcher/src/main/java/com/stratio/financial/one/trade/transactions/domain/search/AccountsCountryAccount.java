package com.stratio.financial.one.trade.transactions.domain.search;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@NoArgsConstructor
@ToString
public class AccountsCountryAccount {

  @JsonProperty("accountId")
  private String accountId = null;

  @JsonProperty("accountIdType")
  private String accountIdType = null;

}
