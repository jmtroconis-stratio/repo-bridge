package com.stratio.financial.one.trade.transactions.infrastructure.es.customquery;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
public class ElasticCustomQuery {

  @JsonProperty("query")
  private QueryCustomQuery queryCustomQuery;

  @JsonProperty("pagination")
  private PaginationCustomQuery paginationCustomQuery;

}
