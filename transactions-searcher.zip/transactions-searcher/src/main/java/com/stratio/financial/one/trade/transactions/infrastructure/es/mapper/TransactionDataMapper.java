package com.stratio.financial.one.trade.transactions.infrastructure.es.mapper;

import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.List;

import com.stratio.financial.one.trade.transactions.domain.data.TransactionData;
import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring")
public abstract class TransactionDataMapper {

  @Mapping(source = "accountingDate", target = "accountingDate", qualifiedByName = "fromInstantToStringDate")
  @Mapping(source = "processedDate", target = "processedDate", qualifiedByName = "fromInstantToStringDate")
  @Mapping(source = "creationDate", target = "creationDate", qualifiedByName = "fromInstantToStringDate")
  @Mapping(source = "transactionId.transactionId", target = "transactionId")
  @Mapping(source = "transactionId.transactionConsolidated", target = "transactionConsolidated")
  @Mapping(source = "transactionIndexPk", target = "transactionPk")
  @Mapping(source = "transactionCompanyAccount.transactionCompanyAccountId.accountId",
      target = "transactionCompanyAccount.accountId")
  @Mapping(source = "transactionCompanyAccount.transactionCompanyAccountId.country",
      target = "transactionCompanyAccount.country")
  @Mapping(source = "transactionCompanyAccount.agent.bic", target = "transactionCompanyAccount.agent")
  public abstract TransactionData transactionToTransactionData(Transaction transaction);

  @Named("fromInstantToStringDate")
  public String fromInstantToStringDate(Instant instant) {
    DateTimeFormatter formatter = new DateTimeFormatterBuilder().appendInstant(3).toFormatter();
    String formattedString = instant != null ? formatter.format(instant) : null;
    return formattedString != null ? formattedString.substring(0, formattedString.length() - 5)
        + "+0000" : null;
  }

  @Mapping(source = "transactionId", target = "transactionId.transactionId")
  @Mapping(source = "transactionConsolidated", target = "transactionId.transactionConsolidated")
  @Mapping(source = "transactionCompanyAccount.accountId", target = "transactionId.accountId")
  @Mapping(source = "transactionCompanyAccount.country", target = "transactionId.country")
  @Mapping(target = "accountingDate", ignore = true)
  @Mapping(target = "processedDate", ignore = true)
  @Mapping(target = "creationDate", ignore = true)
  @Mapping(target = "transactionCompanyAccount", ignore = true)
  public abstract Transaction transactionDataToTransaction(TransactionData transactionData);

  public abstract List<Transaction> transactionDataToTransactionList(List<TransactionData> transactionDataList);
}
