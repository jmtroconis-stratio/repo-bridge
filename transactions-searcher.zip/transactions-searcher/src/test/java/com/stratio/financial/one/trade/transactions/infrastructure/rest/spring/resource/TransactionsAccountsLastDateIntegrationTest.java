package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.resource;


import static io.zonky.test.db.AutoConfigureEmbeddedDatabase.DatabaseProvider.YANDEX;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.stratio.financial.one.trade.transactions.application.repository.AgentRepository;
import com.stratio.financial.one.trade.transactions.application.repository.TransactionCompanyAccountRepository;
import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;
import com.stratio.financial.one.trade.transactions.domain.sql.TransactionCompanyAccount;
import com.stratio.financial.one.trade.transactions.infrastructure.config.spring.StratioSpringBootService;
import com.stratio.financial.one.trade.transactions.infrastructure.db.springdata.repository.SpringDataAgentRepository;
import com.stratio.financial.one.trade.transactions.infrastructure.db.springdata.repository.SpringDataTransactionRepository;
import io.zonky.test.db.AutoConfigureEmbeddedDatabase;
import org.junit.After;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.rules.SpringClassRule;
import org.springframework.test.context.junit4.rules.SpringMethodRule;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

@RunWith(Parameterized.class)
@SpringBootTest(classes = StratioSpringBootService.class)
@ActiveProfiles("integration")
@AutoConfigureMockMvc
@AutoConfigureEmbeddedDatabase(provider = YANDEX)
@EmbeddedKafka(brokerProperties = {"transaction.state.log.replication.factor=1",
    "transaction.state.log.min.isr=1"})
public class TransactionsAccountsLastDateIntegrationTest {

  private static final String INPUT_PATH = "src/test/resources/infrastructure/rest/spring/resource/input/";
  private static final String OUTPUT_PATH = "src/test/resources/infrastructure/rest/spring/resource/output/";

  @ClassRule
  public static final SpringClassRule scr = new SpringClassRule();

  @Rule
  public final SpringMethodRule smr = new SpringMethodRule();

  @Autowired
  private MockMvc mockMvc;

  @Autowired
  TransactionCompanyAccountRepository transactionCompanyAccountRepository;

  @Autowired
  SpringDataTransactionRepository transactionRepository;

  @Autowired
  private SpringDataAgentRepository springDataAgentRepository;

  private final String jsonAccount;
  private final String jsonTransactions;
  private final String jsonPost;
  private final ObjectMapper objectMapper;
  private final String expected;


  @Parameters(name = "Test for: {0} {1} {2} {3} ")
  public static Collection jsonExamples() {
    return Arrays.asList(new Object[][]{
        {"transactionCompanyAccounts.json", "transactions.json",
            "transactionsPostLastProcessedDate_case1.json", "outputPostLastProcessedDate_case1.json"},
        {"transactionCompanyAccounts.json", "transactions.json",
            "transactionsPostLastProcessedDate_case2.json", "outputPostLastProcessedDate_case2.json"},
        {"transactionCompanyAccounts.json", "transactions.json",
            "transactionsPostLastProcessedDate_case3.json", "outputPostLastProcessedDate_case3.json"}
    });
  }

  public TransactionsAccountsLastDateIntegrationTest(String inputAccount, String inputTransactions,
                                                     String inputPost, String outputPost)
      throws IOException {
    objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
    this.jsonAccount = Files.readString(Path.of(INPUT_PATH + inputAccount));
    this.jsonTransactions = Files.readString(Path.of(INPUT_PATH + inputTransactions));
    this.jsonPost = Files.readString(Path.of(INPUT_PATH + inputPost));
    this.expected = Files.readString(Path.of(OUTPUT_PATH + outputPost));

  }

  @Before
  public void setUp() throws Exception {
    List<TransactionCompanyAccount> transactionCompanyAccounts = Arrays.asList(objectMapper.readValue(jsonAccount, TransactionCompanyAccount[].class));
    List<Transaction> transactions = Arrays.asList(objectMapper.readValue(jsonTransactions, Transaction[].class));

    transactionCompanyAccounts.stream().forEach(transactionCompanyAccount -> {
      springDataAgentRepository.save(transactionCompanyAccount.getAgent());
      transactionCompanyAccountRepository.upsert(transactionCompanyAccount);
    });
    transactions.forEach(transaction -> transactionRepository.saveAll(List.of(transaction)));
  }

  @After
  public void tearDown() {
    transactionRepository.deleteAll();
    transactionCompanyAccountRepository.deleteAll();
    springDataAgentRepository.deleteAll();
  }

  @Test
  public void transactionsLastCreationDateGetTest() throws Exception {
    MockHttpServletRequestBuilder mockMvcRequestBuilders = post("/transactions/lastProcessedDate")
        .header("X-B3-TraceId", "123")
        .header("X-B3-SpanId", "231")
        .header("X-B3-ParentSpanId", "321")
        .header("X-B3-Sampled", "213")
        .content(jsonPost)
        .contentType(MediaType.APPLICATION_JSON);

    MvcResult mvcResult = mockMvc.perform(mockMvcRequestBuilders).andReturn();
    String result = mvcResult.getResponse().getContentAsString();
    JSONAssert.assertEquals(expected, result, JSONCompareMode.NON_EXTENSIBLE);
  }

}
