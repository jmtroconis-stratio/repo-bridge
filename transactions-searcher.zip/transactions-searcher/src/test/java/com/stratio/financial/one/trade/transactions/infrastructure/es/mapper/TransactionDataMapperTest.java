package com.stratio.financial.one.trade.transactions.infrastructure.es.mapper;

import java.nio.file.Files;
import java.nio.file.Paths;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionData;
import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

@RunWith(JUnit4.class)
public class TransactionDataMapperTest {

  private TransactionDataMapper transactionDataMapper;
  private ObjectMapper objectMapper;
  private final String INPUT_PATH = "src/test/resources/infrastructure/es/mapper/transaction.json";
  private final String OUTPUT_PATH = "src/test/resources/infrastructure/es/mapper/transactionData.json";

  @Before
  public void setUp() {
    transactionDataMapper = new TransactionDataMapperImpl();
    objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
  }

  @Test
  public void transactionToTransactionData() throws Exception {
    String input = Files.readString(Paths.get(INPUT_PATH));
    String output = Files.readString(Paths.get(OUTPUT_PATH));
    TransactionData result = transactionDataMapper.transactionToTransactionData(objectMapper.readValue(input, Transaction.class));
    JSONAssert.assertEquals(output, objectMapper.writeValueAsString(result), JSONCompareMode.LENIENT);
  }

}