package com.stratio.financial.one.trade.transactions.infrastructure.es;

import static org.junit.Assert.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import com.stratio.financial.one.trade.transactions.domain.data.TransactionSummaryData;
import com.stratio.financial.one.trade.transactions.domain.search.RequestQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.parser.TransactionRequestCustomQueryParser;
import com.stratio.financial.one.trade.transactions.infrastructure.es.parser.TransactionRequestParser;
import com.stratio.financial.one.trade.transactions.infrastructure.es.repository.StratioSearcherRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

@RunWith(JUnit4.class)
public class StratioSearcherRepositoryTest {

  private final String PATH = "src/test/resources/infrastructure/es/";
  private final String SEARCHER = "searcher";
  private final String INDEXER = "indexer";
  private final String DOMAIN = "domain";
  private final String CUSTOM_QUERY_NAME = "customQueryName";
  private final RestTemplate restTemplate = Mockito.mock(RestTemplate.class);
  private final TransactionRequestParser transactionRequestParser = Mockito
      .mock(TransactionRequestParser.class);
  private final TransactionRequestCustomQueryParser transactionRequestCustomQueryParser = Mockito
      .mock(TransactionRequestCustomQueryParser.class);
  private final PodamFactory podamFactory = new PodamFactoryImpl();
  private StratioSearcherRepository stratioSearcherRepository;

  @Before
  public void setUp() {
    stratioSearcherRepository = new StratioSearcherRepository(SEARCHER, INDEXER, DOMAIN, CUSTOM_QUERY_NAME,
        restTemplate, transactionRequestParser, transactionRequestCustomQueryParser);
  }

  @Test
  public void search() throws IOException {
    RequestQuery requestQuery = podamFactory.manufacturePojo(RequestQuery.class);
    ElasticQuery elasticQuery = podamFactory.manufacturePojo(ElasticQuery.class);
    ResponseEntity responseEntity = new ResponseEntity(Files.readString(Path.of(PATH+"searchResponseConsolidated.json")), HttpStatus.OK);
    when(transactionRequestParser.parse(any(),any(),any())).thenReturn(elasticQuery);
    when(restTemplate.exchange(any(),(Class<String>)any())).thenReturn(responseEntity);
    TransactionSummaryData transactionSummaryData = stratioSearcherRepository.search(requestQuery);
    assertFalse(transactionSummaryData.getTransactions().size()<5);
  }
}