package com.stratio.financial.one.trade.transactions.application.service.impl;

import static org.junit.Assert.*;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import com.stratio.financial.one.trade.transactions.application.repository.TransactionCompanyAccountRepository;
import com.stratio.financial.one.trade.transactions.application.repository.TransactionRepository;
import com.stratio.financial.one.trade.transactions.application.service.TransactionService;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionSummaryData;
import com.stratio.financial.one.trade.transactions.domain.search.AccountsCountriesList;
import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;
import com.stratio.financial.one.trade.transactions.domain.sql.TransactionCompanyAccount;
import com.stratio.financial.one.trade.transactions.domain.sql.TransactionCompanyAccountId;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mockito;
import org.slf4j.LoggerFactory;
import scala.util.Random;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;
import uk.co.jemos.podam.api.RandomDataProviderStrategyImpl;

@RunWith(JUnit4.class)
public class TransactionServiceImplTest {

  private PodamFactory podamFactory;
  private final TransactionCompanyAccountRepository transactionCompanyAccountRepository = Mockito
      .mock(TransactionCompanyAccountRepository.class);
  private final TransactionRepository transactionRepository = Mockito
      .mock(TransactionRepository.class);
  private TransactionService transactionService;

  private TransactionCompanyAccount transactionCompanyAccount;
  private TransactionCompanyAccountId transactionCompanyAccountId;
  private TransactionSummaryData transactionSummaryData;
  private TransactionSummaryData transactionSummaryDataConsolidated;
  private TransactionSummaryData transactionSummaryDataEmptyTransactions;
  private int from;
  private int limit;
  private AccountsCountriesList accountsCountriesList;

  @Before
  public void setUp() {
    Random r = new Random();
    Logger root = (Logger) LoggerFactory.getLogger("uk.co.jemos.podam.api");
    root.setLevel(Level.ERROR);
    RandomDataProviderStrategyImpl randomDataProviderStrategy = new RandomDataProviderStrategyImpl();
    randomDataProviderStrategy.setMaxDepth(1);
    podamFactory = new PodamFactoryImpl();
    podamFactory.setStrategy(randomDataProviderStrategy);
    transactionService = new TransactionServiceImpl(transactionCompanyAccountRepository,
        transactionRepository);
    transactionCompanyAccount = podamFactory.manufacturePojo(TransactionCompanyAccount.class);
    transactionCompanyAccountId = transactionCompanyAccount.getTransactionCompanyAccountId();
    transactionSummaryData = podamFactory.manufacturePojo(TransactionSummaryData.class);
    transactionSummaryData.getTransactions().forEach(transactionData -> transactionData
        .setProcessedDate("2019-03-05T00:05:01+0000"));
    transactionSummaryDataConsolidated = podamFactory.manufacturePojo(TransactionSummaryData.class);
    transactionSummaryDataConsolidated.getTransactions().forEach(transactionData -> transactionData
        .setProcessedDate("2019-03-05T00:05:01+0000"));
    transactionSummaryDataEmptyTransactions = podamFactory
        .manufacturePojo(TransactionSummaryData.class);
    transactionSummaryDataEmptyTransactions.getTransactions().clear();
    from = 0;
    limit = Integer.MAX_VALUE;
    accountsCountriesList = podamFactory.manufacturePojo(AccountsCountriesList.class);
  }

  private boolean checkDateTimeFormat(String dateTime) {
    try {
      DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse(dateTime);
    } catch (DateTimeParseException ex) {
      return false;
    }
    return true;
  }

  @Test
  public void getLastTransactionsDateTime() {
    Transaction transaction = transactionCompanyAccount.getTransactions().get(0);

    when(transactionCompanyAccountRepository.findById(any()))
        .thenReturn(Optional.of(transactionCompanyAccount));
    when(transactionRepository.findLastConsolidated(eq(true), any(), any()))
        .thenReturn(Optional.of(transaction));

    setAccountIdTypeToAccountsCountriesList(accountsCountriesList, transactionCompanyAccount);
    accountsCountriesList.get(0).getAccount().setAccountIdType(null);

    List<Transaction> result = transactionService.getLastTransactionsDateTime(accountsCountriesList);

    assertEquals(accountsCountriesList.size(), result.size());
    result.stream().forEach(transactionResult -> {
      assertEquals(transaction.getTransactionId().getCountry(), transactionResult.getTransactionId().getCountry());
      assertEquals(transaction.getTransactionId().getAccountId(), transactionResult.getTransactionId().getAccountId());
      assertEquals(transaction.getTransactionId().getTransactionId(), transactionResult.getTransactionId().getTransactionId());
      assertEquals(transaction.getTransactionId().getTransactionConsolidated(), transactionResult.getTransactionId().getTransactionConsolidated());
      assertEquals(transaction.getProcessedDate(), transactionResult.getProcessedDate());
    });
  }

  @Test
  public void getLastTransactionsDateTimeWithNoAccount() {
    when(transactionCompanyAccountRepository.findById(any()))
        .thenReturn(Optional.empty());

    List<Transaction> result = transactionService.getLastTransactionsDateTime(accountsCountriesList);
    assertEquals(0, result.size());
  }

  @Test
  public void getLastTransactionsDateTimeWithNoTransactions() {
    when(transactionCompanyAccountRepository.findById(any()))
        .thenReturn(Optional.of(transactionCompanyAccount));
    when(transactionRepository.findLastConsolidated(eq(true), any(), any()))
        .thenReturn(Optional.empty());

    setAccountIdTypeToAccountsCountriesList(accountsCountriesList, transactionCompanyAccount);
    accountsCountriesList.get(0).setAccount(null);

    List<Transaction> result = transactionService.getLastTransactionsDateTime(accountsCountriesList);
    assertEquals(accountsCountriesList.size() - 1, result.size());
    for (int i = 0; i < accountsCountriesList.size(); i ++) {
      if (accountsCountriesList.get(i).getAccount() != null) {
        assertEquals(accountsCountriesList.get(i).getCountry(), result.get(i - 1).getTransactionId().getCountry());
        assertEquals(accountsCountriesList.get(i).getAccount().getAccountId(), result.get(i - 1).getTransactionId().getAccountId());
        assertNull(result.get(i - 1).getTransactionId().getTransactionId());
        assertNull(result.get(i - 1).getTransactionId().getTransactionConsolidated());
        assertNull(result.get(i - 1).getProcessedDate());
      }
    }
  }

  private void setAccountIdTypeToAccountsCountriesList(AccountsCountriesList accountsCountriesList, TransactionCompanyAccount transactionCompanyAccount) {
    accountsCountriesList.stream().forEach(accountsCountry -> accountsCountry.getAccount().setAccountIdType(transactionCompanyAccount.getAccountIdType()));
  }
}