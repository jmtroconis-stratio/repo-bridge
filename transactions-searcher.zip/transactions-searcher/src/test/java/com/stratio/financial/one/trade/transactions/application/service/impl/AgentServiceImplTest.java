package com.stratio.financial.one.trade.transactions.application.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.stratio.financial.one.trade.transactions.application.repository.AgentRepository;
import com.stratio.financial.one.trade.transactions.application.service.AgentService;
import com.stratio.financial.one.trade.transactions.domain.sql.Agent;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mockito;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

@RunWith(JUnit4.class)
public class AgentServiceImplTest {

  private final PodamFactory podamFactory = new PodamFactoryImpl();
  private AgentRepository agentRepository = Mockito.mock(AgentRepository.class);
  private AgentService agentService = new AgentServiceImpl(agentRepository);

  private Agent agent;

  @Before
  public void setUp() {
    agent = podamFactory.manufacturePojo(Agent.class);
  }

  @Test
  public void saveAgent() {
    when(agentRepository.saveAgent(agent)).thenReturn(agent);

    Agent saved = agentService.saveAgent(agent);

    verify(agentRepository, times(1)).saveAgent(agent);
    assertEquals(agent, saved);
  }
}
