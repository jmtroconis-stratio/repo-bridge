package com.stratio.financial.one.trade.transactions.infrastructure.es;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collection;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.stratio.financial.one.trade.transactions.infrastructure.es.parser.TransactionRequestParser;
import net.sf.json.test.JSONAssert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class TransactionRequestParserToDateTest {

  private static final String OUTPUT_PATH = "src/test/resources/infrastructure/es/output/";

  private final String output;
  private final String date;
  private final int from;
  private final int size;
  private final boolean consolidated;
  private final ObjectMapper objectMapper;
  private final TransactionRequestParser parser;

  @Parameters(name = "Test for: {0} - {1} - {2} - {3} - {4}")
  public static Collection jsonExamples() {
    return Arrays.asList(new Object[][]{
        {"2019-03-05T00:05:01+0000", 0, 10000, false, "queryToDate.json"}
    });
  }

  public TransactionRequestParserToDateTest(String date, int from, int size, boolean consolidated, String output)
      throws IOException {
    this.output = Files.readString(Path.of(OUTPUT_PATH + output));
    this.date = date;
    this.from = from;
    this.size = size;
    this.consolidated = consolidated;
    parser = new TransactionRequestParser();
    objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
  }

  @Test
  public void shouldParseRequestQueryToDate() throws IOException {
    ElasticQuery query = parser.parseToDate(date, from, size, consolidated);
    JSONAssert.assertEquals(objectMapper.writeValueAsString(objectMapper.readValue(output, ElasticQuery.class)),
        objectMapper.writeValueAsString(query)
    );
  }

}
