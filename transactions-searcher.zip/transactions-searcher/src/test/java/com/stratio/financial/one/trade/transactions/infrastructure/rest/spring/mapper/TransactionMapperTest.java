package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.mapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.stratio.financial.one.trade.transactions.application.service.impl.TransactionServiceImpl;
import com.stratio.financial.one.trade.transactions.domain.data.DocumentsData;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionCompanyAccountData;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionData;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionSummaryData;
import com.stratio.financial.one.trade.transactions.domain.search.AccountsCountriesList;
import com.stratio.financial.one.trade.transactions.domain.search.RequestQuery;
import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.AccountsCountriesListDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.LastProcessedDateOutputDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.RequestQueryDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.RequestQueryXslxDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionResponseDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsDataListItemDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsDataListItemTransactionDetailsDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsResponseDocumentsDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsResponseDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.exception.LimitExceededException;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.exception.ValidationException;
import edu.emory.mathcs.backport.java.util.Arrays;
import lombok.SneakyThrows;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;

public class TransactionMapperTest {

  private static final String INPUT_PATH = "src/test/resources/infrastructure/rest/spring/mapper/input/";
  private static final String OUTPUT_PATH = "src/test/resources/infrastructure/rest/spring/mapper/output/";

  private ObjectMapper objectMapper;
  private TransactionMapper transactionMapper;

  private TransactionSummaryData transactionSummaryData;
  private TransactionData transactionData;

  @Before
  public void setUp() {
    PodamFactory podamFactory = new PodamFactoryImpl();
    transactionMapper = new TransactionMapperImpl();
    objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());

    transactionSummaryData = podamFactory.manufacturePojo(TransactionSummaryData.class);
    transactionData = podamFactory.manufacturePojo(TransactionData.class);
  }

  @Test
  public void transactionsSummaryDataToTransactionsResponseDto() throws Exception  {
    TransactionsResponseDto result = transactionMapper.transactionsSummaryDataToTransactionsResponseDto(
        transactionSummaryData);

    TransactionCompanyAccountData expected = transactionSummaryData.getTransactions().get(0).getTransactionCompanyAccount();
    TransactionResponseDto transactionResponseDto = result.getTransactionsListResponse().get(0);

    JSONObject expectedJson = new JSONObject(objectMapper.writeValueAsString(expected));
    expectedJson.remove("entity");
    expectedJson.remove("accountId");
    expectedJson.remove("accountIdType");
    expectedJson.remove("iban");

    JSONObject actualJson = new JSONObject(objectMapper.writeValueAsString(transactionResponseDto));

    JSONAssert.assertEquals(expectedJson, actualJson, JSONCompareMode.LENIENT);
    Assert.assertFalse(transactionResponseDto.getTransactionsDataList().isEmpty());
  }

  @Test
  public void transactionsSummaryDataToTransactionsResponseDtoDocuments() throws Exception  {
    TransactionsResponseDto result = transactionMapper.transactionsSummaryDataToTransactionsResponseDto(
        transactionSummaryData);

    DocumentsData expected = transactionSummaryData.getDocuments();
    TransactionsResponseDocumentsDto transactionResponseDto = result.getDocuments();

    JSONObject expectedJson = new JSONObject(objectMapper.writeValueAsString(expected));
    JSONObject actualJson = new JSONObject(objectMapper.writeValueAsString(transactionResponseDto));
    JSONAssert.assertEquals(expectedJson, actualJson, JSONCompareMode.LENIENT);
  }

  @Test
  public void transactionDataToTransactionsDataListItemTransactionDetailsDto() throws Exception {
    TransactionsDataListItemTransactionDetailsDto result = transactionMapper.
        transactionDataToTransactionsDataListItemTransactionDetailsDto(transactionData);

    JSONObject expectedJson = new JSONObject(objectMapper.writeValueAsString(transactionData));
    expectedJson.remove("additionalInformation");
    expectedJson.remove("customerAdditionalInformation");
    expectedJson.remove("customerTransactionCode");
    expectedJson.remove("customerTransactionDescription");
    expectedJson.remove("localTransactionCode");
    expectedJson.remove("localTransactionDescription");
    expectedJson.remove("swiftCode");
    expectedJson.remove("transactionBatchReference");
    expectedJson.remove("transactionClientReference");
    expectedJson.remove("transactionCompanyAccount");
    expectedJson.remove("transactionInternalReference");
    expectedJson.remove("transactionAmount");
    expectedJson.remove("transactionAmountCurrency");
    expectedJson.remove("transactionBalanceAmount");
    expectedJson.remove("transactionBalanceAmountCurrency");
    expectedJson.remove("transactionPk");
    expectedJson.remove("gtsExtractId");

    JSONObject actualJson = new JSONObject(objectMapper.writeValueAsString(result));
    JSONAssert.assertEquals(expectedJson, actualJson, JSONCompareMode.LENIENT);

    assertEquals(transactionData.getTransactionBatchReference(), result.getReferences().getTransactionBatchReference());
    assertEquals(transactionData.getTransactionClientReference(),
        result.getReferences().getTransactionClientReference());
    assertEquals(transactionData.getTransactionInternalReference(),
        result.getReferences().getTransactionInternalReference());
    assertEquals(transactionData.getSwiftCode(), result.getOperation().getSwiftCode());
    assertEquals(transactionData.getLocalTransactionCode(),
        result.getOperation().getLocalOperation().getLtcCode());
    assertEquals(transactionData.getLocalTransactionDescription(),
        result.getOperation().getLocalOperation().getLtcDescription());
    assertEquals(transactionData.getAdditionalInformation(),
        result.getOperation().getLocalOperation().getAditionalInformation());
    assertEquals(transactionData.getTransactionBatchReference(), result.getReferences().getTransactionBatchReference());
    assertEquals(transactionData.getCustomerAdditionalInformation(),
        result.getOperation().getCustomerOperation().getCustomerAditionalInformation());
    assertEquals(transactionData.getCustomerTransactionDescription(),
        result.getOperation().getCustomerOperation().getCustomerTDescription());
    assertEquals(transactionData.getCustomerTransactionCode(),
        result.getOperation().getCustomerOperation().getCustomerTCode());
    assertEquals(transactionData.getTransactionAmount(),
        result.getAmount().getAmount());
    assertEquals(transactionData.getTransactionAmountCurrency(),
        result.getAmount().getCurrencyCode());
    assertEquals(transactionData.getTransactionBalanceAmount(),
        result.getBalanceResult().getAmount());
    assertEquals(transactionData.getTransactionBalanceAmountCurrency(),
        result.getBalanceResult().getCurrencyCode());
  }

  @Test
  public void transactionDataToTransactionsDataListItemTransactionDetailsDtoNull() {
    TransactionsDataListItemTransactionDetailsDto result = transactionMapper.
        transactionDataToTransactionsDataListItemTransactionDetailsDto(null);

    assertNull(result);
  }

  @Test
  public void transactionDataToTransactionsDataListItemDto() throws Exception {
    TransactionsDataListItemDto result = transactionMapper.transactionDataToTransactionsDataListItemDto(transactionData);

    JSONObject expectedJson = new JSONObject(objectMapper.writeValueAsString(transactionData));
    expectedJson.remove("additionalInformation");
    expectedJson.remove("customerAdditionalInformation");
    expectedJson.remove("customerTransactionCode");
    expectedJson.remove("customerTransactionDescription");
    expectedJson.remove("localTransactionCode");
    expectedJson.remove("localTransactionDescription");
    expectedJson.remove("swiftCode");
    expectedJson.remove("transactionBatchReference");
    expectedJson.remove("transactionClientReference");
    expectedJson.remove("transactionCompanyAccount");
    expectedJson.remove("transactionInternalReference");
    expectedJson.remove("transactionAmount");
    expectedJson.remove("transactionAmountCurrency");
    expectedJson.remove("transactionBalanceAmount");
    expectedJson.remove("transactionBalanceAmountCurrency");
    expectedJson.remove("transactionPk");
    expectedJson.remove("gtsExtractId");

    JSONObject actualJson = new JSONObject(objectMapper.writeValueAsString(result.getTransactionDetails()));
    JSONAssert.assertEquals(expectedJson, actualJson, JSONCompareMode.LENIENT);
  }

  @Test
  public void transactionDataToTransactionsDataListItemDtoNull() {
    TransactionsDataListItemDto result = transactionMapper.transactionDataToTransactionsDataListItemDto(null);

    assertNull(result);
  }

  @Test
  public void documentsDataToTransactionsResponseDocumentsDtoNull() {
   TransactionsResponseDocumentsDto result = transactionMapper.documentsDataToTransactionsResponseDocumentsDto(null);

   assertNull(result);
  }

  @Test
  public void transactionDatasToTransactionsDataListItemDtosNull() {
    assertNull(transactionMapper.transactionDatasToTransactionsDataListItemDtos(null));
  }


  @Test
  @SneakyThrows
  public void accountsCountriesListDtoToAccountsCountriesList() {
    String jsonOutput = Files.readString(Path.of(OUTPUT_PATH + "accountsCountriesList_case1.json"));
    AccountsCountriesListDto accountsCountriesListDto =
        objectMapper.readValue(Files.readString(Path.of(INPUT_PATH + "accountsCountriesListDto_case1.json")), AccountsCountriesListDto.class);
    AccountsCountriesList accountsCountriesList =
        transactionMapper.accountsCountriesListDtoToAccountsCountriesList(accountsCountriesListDto);

    JSONAssert.assertEquals(jsonOutput, objectMapper.writeValueAsString(accountsCountriesList), JSONCompareMode.STRICT_ORDER);
  }

  @Test
  @SneakyThrows
  public void transactionsToLastProcessedDateOutputDto() {
    String jsonOutput = Files.readString(Path.of(OUTPUT_PATH + "lastProcessedDateOutputDto_case2.json"));
    Transaction[] transactions =
        objectMapper.readValue(Files.readString(Path.of(INPUT_PATH + "listTransactions_case2.json")), Transaction[].class);
    LastProcessedDateOutputDto lastProcessedDateOutputDto =
        transactionMapper.transactionsToLastProcessedDateOutputDto(Arrays.asList(transactions));
    JSONAssert.assertEquals(jsonOutput, objectMapper.writeValueAsString(lastProcessedDateOutputDto), JSONCompareMode.STRICT_ORDER);
  }

  @Test
  @SneakyThrows
  public void requestQueryDtoToRequestQuery() {
    String jsonOutput = Files.readString(Path.of(OUTPUT_PATH + "requestQuery_case3.json"));
    RequestQueryDto requestQueryDto =
        objectMapper.readValue(Files.readString(Path.of(INPUT_PATH + "requestQueryDto_case3.json")), RequestQueryDto.class);
    RequestQuery requestQuery =
        transactionMapper.requestQueryDtoToRequestQuery(requestQueryDto);
    JSONAssert.assertEquals(jsonOutput, objectMapper.writeValueAsString(requestQuery), JSONCompareMode.NON_EXTENSIBLE);
  }

  @Test(expected = ValidationException.class)
  @SneakyThrows
  public void requestQueryDtoToRequestQuery_whenFromDateNotValidFormat_thenThrowError() {
    RequestQueryDto requestQueryDto =
        objectMapper.readValue(Files.readString(Path.of(INPUT_PATH + "requestQueryDto_case3.json")), RequestQueryDto.class);
    requestQueryDto.setFromDate("2020-01-01T00:00:00");
    RequestQuery requestQuery =
        transactionMapper.requestQueryDtoToRequestQuery(requestQueryDto);
  }

  @Test(expected = ValidationException.class)
  @SneakyThrows
  public void requestQueryDtoToRequestQuery_whenToDateNotValidFormat_thenThrowError() {
    RequestQueryDto requestQueryDto =
        objectMapper.readValue(Files.readString(Path.of(INPUT_PATH + "requestQueryDto_case3.json")), RequestQueryDto.class);
    requestQueryDto.setToDate("2020-01-01T00:00:00");
    RequestQuery requestQuery =
        transactionMapper.requestQueryDtoToRequestQuery(requestQueryDto);
  }

  @Test(expected = LimitExceededException.class)
  @SneakyThrows
  public void requestQueryDtoToRequestQuery_whenLimitExceeded_thenThrowError() {
    RequestQueryDto requestQueryDto =
        objectMapper.readValue(Files.readString(Path.of(INPUT_PATH + "requestQueryDto_case3.json")), RequestQueryDto.class);
    requestQueryDto.setLimit(TransactionServiceImpl.MAX_NUM_DOCUMENTS_ELASTIC + 1);
    RequestQuery requestQuery =
        transactionMapper.requestQueryDtoToRequestQuery(requestQueryDto);
  }

  @Test
  @SneakyThrows
  public void requestQueryDtoToRequestQuery_whenNoOffsetLimitAndNoDates_thenSetDefaultValues() {
    String jsonOutput = Files.readString(Path.of(OUTPUT_PATH + "requestQuery_case4.json"));
    RequestQueryDto requestQueryDto =
        objectMapper.readValue(Files.readString(Path.of(INPUT_PATH + "requestQueryDto_case4.json")), RequestQueryDto.class);
    RequestQuery requestQuery =
        transactionMapper.requestQueryDtoToRequestQuery(requestQueryDto);
    JSONAssert.assertEquals(jsonOutput, objectMapper.writeValueAsString(requestQuery), JSONCompareMode.NON_EXTENSIBLE);
  }

  @Test
  @SneakyThrows
  public void requestQueryXlsxDtoToRequestQuery() {
    String jsonOutput = Files.readString(Path.of(OUTPUT_PATH + "requestQuery_case5.json"));
    RequestQueryXslxDto requestQueryXslxDto =
        objectMapper.readValue(Files.readString(Path.of(INPUT_PATH + "requestQueryXlsxDto_case5.json")), RequestQueryXslxDto.class);
    RequestQuery requestQuery =
        transactionMapper.requestQueryXlsxDtoToRequestQuery(requestQueryXslxDto);
    JSONAssert.assertEquals(jsonOutput, objectMapper.writeValueAsString(requestQuery), JSONCompareMode.NON_EXTENSIBLE);
  }

  @Test(expected = ValidationException.class)
  @SneakyThrows
  public void requestQueryXlsxDtoToRequestQuery_whenFromDateNotValidFormat_thenThrowError() {
    RequestQueryXslxDto requestQueryXslxDto =
        objectMapper.readValue(Files.readString(Path.of(INPUT_PATH + "requestQueryXlsxDto_case5.json")), RequestQueryXslxDto.class);
    requestQueryXslxDto.setFromDate("2020-01-01T00:00:00");
    RequestQuery requestQuery =
        transactionMapper.requestQueryXlsxDtoToRequestQuery(requestQueryXslxDto);
  }

  @Test(expected = ValidationException.class)
  @SneakyThrows
  public void requestQueryXlsxDtoToRequestQuery_whenToDateNotValidFormat_thenThrowError() {
    RequestQueryXslxDto requestQueryXslxDto =
        objectMapper.readValue(Files.readString(Path.of(INPUT_PATH + "requestQueryXlsxDto_case5.json")), RequestQueryXslxDto.class);
    requestQueryXslxDto.setToDate("2020-01-01T00:00:00");
    RequestQuery requestQuery =
        transactionMapper.requestQueryXlsxDtoToRequestQuery(requestQueryXslxDto);
  }

  @Test(expected = LimitExceededException.class)
  @SneakyThrows
  public void requestQueryXlsxDtoToRequestQuery_whenLimitExceeded_thenThrowError() {
    RequestQueryXslxDto requestQueryXslxDto =
        objectMapper.readValue(Files.readString(Path.of(INPUT_PATH + "requestQueryXlsxDto_case5.json")), RequestQueryXslxDto.class);
    requestQueryXslxDto.setLimit(TransactionServiceImpl.MAX_NUM_DOCUMENTS_ELASTIC + 1);
    RequestQuery requestQuery =
        transactionMapper.requestQueryXlsxDtoToRequestQuery(requestQueryXslxDto);
  }

  @Test
  @SneakyThrows
  public void requestQueryXlsxDtoToRequestQuery_whenNoOffsetLimitAndNoDates_thenSetDefaultValues() {
    String jsonOutput = Files.readString(Path.of(OUTPUT_PATH + "requestQuery_case6.json"));
    RequestQueryXslxDto requestQueryXslxDto =
        objectMapper.readValue(Files.readString(Path.of(INPUT_PATH + "requestQueryXlsxDto_case6.json")), RequestQueryXslxDto.class);
    RequestQuery requestQuery =
        transactionMapper.requestQueryXlsxDtoToRequestQuery(requestQueryXslxDto);
    JSONAssert.assertEquals(jsonOutput, objectMapper.writeValueAsString(requestQuery), JSONCompareMode.NON_EXTENSIBLE);
  }

  @Test
  public void instantToElasticFormatString() {
    String expected = "1995-10-23T10:12:35+0000";
    Instant instant = Instant.parse("1995-10-23T10:12:35.000Z");

    String output = transactionMapper.instantToElasticFormatString(instant);

    assertEquals(expected, output);
  }

  @Test
  public void instantToElasticFormatString_whenNull_thenNull() {
    String output = transactionMapper.instantToElasticFormatString(null);
    assertNull(output);
  }
}
