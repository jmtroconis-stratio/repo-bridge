package com.stratio.financial.one.trade.transactions.infrastructure.es;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collection;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.stratio.financial.one.trade.transactions.domain.search.RequestQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.parser.TransactionRequestParser;
import net.sf.json.test.JSONAssert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class TransactionRequestParserTest {

  private final String INPUT_PATH = "src/test/resources/infrastructure/es/input/";
  private final String OUTPUT_PATH = "src/test/resources/infrastructure/es/output/";

  private String input;
  private String output;
  private Boolean consolidated;
  private String creationDate;
  private ObjectMapper objectMapper;
  private TransactionRequestParser parser;

  public TransactionRequestParserTest(String input, String output, Boolean consolidated,
                                      String creationDate) throws IOException {
    this.input = Files.readString(Path.of(INPUT_PATH + input));
    this.output = Files.readString(Path.of(OUTPUT_PATH + output));
    this.consolidated = consolidated;
    this.creationDate = creationDate;
    parser = new TransactionRequestParser();
    objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
  }

  @Parameters(name = "Test for: {0} - {1} - {2} - {3}")
  public static Collection jsonExamples() {
    return Arrays.asList(new Object[][]{
        {"requestQueryLU.json", "queryWithAllFieldsConsolidated.json", true, null},
        {"requestQueryEOD.json", "queryWithAllFieldsNotConsolidated.json", false, "2020-05-15T00:05:01.000+0000"}
    });
  }

  @Test
  public void shouldParseRequestQueryWithAccountCountry() throws IOException {
    ElasticQuery query = parser.parse(objectMapper.readValue(input, RequestQuery.class), consolidated, creationDate);
    JSONAssert.assertEquals(
        objectMapper.writeValueAsString(objectMapper.readValue(output, ElasticQuery.class)),
        objectMapper.writeValueAsString(query)
    );
  }

}
