package com.stratio.financial.one.trade.transactions.infrastructure.es;

import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.ErrorDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.resource.ExceptionHandlerResource;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.context.request.WebRequest;

import java.util.NoSuchElementException;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(JUnit4.class)
public class ExceptionHandlerResourceTest {

  @Mock
  private WebRequest webRequest = Mockito.mock(WebRequest.class);

  private ExceptionHandlerResource exceptionHandlerResource = new ExceptionHandlerResource();
  private ServletRequestBindingException servletRequestBindingException = Mockito.mock(ServletRequestBindingException.class);
  private HttpRequestMethodNotSupportedException httpRequestMethodNotSupportedException = Mockito.mock(HttpRequestMethodNotSupportedException.class);
  private NoSuchElementException noSuchElementException = Mockito.mock(NoSuchElementException.class);

  @Test
  public void handleServletRequestBindingException() {
    when(servletRequestBindingException.getMessage()).thenReturn("servletRequestBindingException");
    ResponseEntity<Object> result = exceptionHandlerResource.handleServletRequestBindingException(
        servletRequestBindingException,
        HttpHeaders.EMPTY,
        HttpStatus.BAD_REQUEST,
        webRequest);
    ErrorDto errorDto = (ErrorDto) result.getBody();
    assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
    assertEquals(Integer.toString(HttpStatus.BAD_REQUEST.value()), errorDto.getCode());
    assertEquals(HttpStatus.BAD_REQUEST.getReasonPhrase(), errorDto.getTitle());
    assertEquals(servletRequestBindingException.getMessage(), errorDto.getDescription());
  }

  @Test
  public void handleHttpRequestMethodNotSupported() {
    when(httpRequestMethodNotSupportedException.getMessage()).thenReturn("httpRequestMethodNotSupportedException");
    ResponseEntity<Object> result = exceptionHandlerResource.handleHttpRequestMethodNotSupported(
        httpRequestMethodNotSupportedException,
        HttpHeaders.EMPTY,
        HttpStatus.METHOD_NOT_ALLOWED,
        webRequest);
    ErrorDto errorDto = (ErrorDto) result.getBody();
    assertEquals(HttpStatus.METHOD_NOT_ALLOWED, result.getStatusCode());
    assertEquals(Integer.toString(HttpStatus.METHOD_NOT_ALLOWED.value()), errorDto.getCode());
    assertEquals(HttpStatus.METHOD_NOT_ALLOWED.getReasonPhrase(), errorDto.getTitle());
    assertEquals(httpRequestMethodNotSupportedException.getMessage(), errorDto.getDescription());
  }

  @Test
  public void handleNoSuchElementException() {
    when(noSuchElementException.getMessage()).thenReturn("noSuchElementException");
    ResponseEntity<Object> result = exceptionHandlerResource.handleNoSuchElementException(noSuchElementException);
    ErrorDto errorDto = (ErrorDto) result.getBody();
    assertEquals(HttpStatus.NOT_FOUND, result.getStatusCode());
    assertEquals(Integer.toString(HttpStatus.NOT_FOUND.value()), errorDto.getCode());
    assertEquals(HttpStatus.NOT_FOUND.getReasonPhrase(), errorDto.getTitle());
    assertEquals(noSuchElementException.getMessage(), errorDto.getDescription());
  }

  @Test
  public void handleUnexpectedException() {
    when(noSuchElementException.getMessage()).thenReturn("noSuchElementException");
    ResponseEntity<Object> result = exceptionHandlerResource.handleUnexpectedException(noSuchElementException);
    ErrorDto errorDto = (ErrorDto) result.getBody();
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
    assertEquals(Integer.toString(HttpStatus.INTERNAL_SERVER_ERROR.value()), errorDto.getCode());
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), errorDto.getTitle());
    assertEquals(noSuchElementException.getMessage(), errorDto.getDescription());
  }
}