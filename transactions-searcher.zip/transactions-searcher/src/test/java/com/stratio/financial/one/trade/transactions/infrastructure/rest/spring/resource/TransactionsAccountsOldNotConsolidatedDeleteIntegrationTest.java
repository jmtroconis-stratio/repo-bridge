package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.resource;

import static io.zonky.test.db.AutoConfigureEmbeddedDatabase.DatabaseProvider.YANDEX;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.stratio.financial.one.trade.transactions.application.repository.AgentRepository;
import com.stratio.financial.one.trade.transactions.application.repository.TransactionCompanyAccountRepository;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionSummaryData;
import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;
import com.stratio.financial.one.trade.transactions.infrastructure.config.spring.StratioSpringBootService;
import com.stratio.financial.one.trade.transactions.infrastructure.db.springdata.repository.SpringDataAgentRepository;
import com.stratio.financial.one.trade.transactions.infrastructure.db.springdata.repository.SpringDataTransactionRepository;
import com.stratio.financial.one.trade.transactions.infrastructure.es.repository.StratioSearcherRepository;
import io.zonky.test.db.AutoConfigureEmbeddedDatabase;
import org.junit.After;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.rules.SpringClassRule;
import org.springframework.test.context.junit4.rules.SpringMethodRule;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

@RunWith(Parameterized.class)
@SpringBootTest(classes = StratioSpringBootService.class)
@ActiveProfiles("integration")
@AutoConfigureMockMvc
@AutoConfigureEmbeddedDatabase(provider = YANDEX)
@EmbeddedKafka(brokerProperties = {"transaction.state.log.replication.factor=1", "transaction.state.log.min.isr=1"})
public class TransactionsAccountsOldNotConsolidatedDeleteIntegrationTest {

  private static final String INPUT_PATH = "src/test/resources/infrastructure/rest/spring/resource/input/";
  private static final String OUTPUT_PATH = "src/test/resources/infrastructure/rest/spring/resource/output/";
  private static final int SIZE = 10000;

  @ClassRule
  public static final SpringClassRule scr = new SpringClassRule();

  @Rule
  public final SpringMethodRule smr = new SpringMethodRule();

  @MockBean
  StratioSearcherRepository stratioSearcherRepository;

  @Autowired
  MockMvc mockMvc;

  @Autowired
  SpringDataAgentRepository agentRepository;

  @Autowired
  SpringDataTransactionRepository transactionRepository;

  @Autowired
  TransactionCompanyAccountRepository transactionCompanyAccountRepository;

  private final String dateTo;
  private final Transaction transaction;
  private final TransactionSummaryData transactionSummaryData;
  private final TransactionSummaryData transactionSummaryDataEmpty;

  @Parameterized.Parameters(name = "Test for: {0} - {1}")
  public static Collection jsonExamples() {
    return Arrays.asList(new Object[][]{
        {"transaction.json", "2019-03-05T00:05:01+0000", "transactionSummaryData.json"}
    });
  }

  public TransactionsAccountsOldNotConsolidatedDeleteIntegrationTest(String input, String dateTo, String output)
      throws IOException {
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
    this.dateTo = dateTo;
    transaction = objectMapper.readValue(Path.of(INPUT_PATH + input).toFile(), Transaction.class);
    transactionSummaryData = objectMapper.readValue(Path.of(OUTPUT_PATH + output).toFile(),
        TransactionSummaryData.class);
    transactionSummaryDataEmpty = objectMapper.readValue(Path.of(OUTPUT_PATH + output).toFile(),
        TransactionSummaryData.class);
    transactionSummaryDataEmpty.getTransactions().clear();
  }

  @After
  public void tearDown() {
    transactionRepository.deleteAll();
    transactionCompanyAccountRepository.deleteAll();
    agentRepository.deleteAll();
  }

  @Test
  public void transactionsAccountsSearchDeleteOldNotConsolidated() throws Exception {
    when(stratioSearcherRepository.searchToDate(dateTo, 0, SIZE, false))
        .thenReturn(transactionSummaryData)
        .thenReturn(transactionSummaryDataEmpty);

    transactionCompanyAccountRepository.upsert(transaction.getTransactionCompanyAccount());
    transaction.setTransactionCompanyAccount(null);
    transactionRepository.saveAll(List.of(transaction));

    String url = "/transactions/tocreationdate/" + dateTo + "/oldNotConsolidated?size="+SIZE;
    MockHttpServletRequestBuilder mockMvcRequestBuilders = delete(url)
        .header("X-B3-TraceId", "123")
        .header("X-B3-SpanId", "231")
        .header("X-B3-ParentSpanId", "321")
        .header("X-B3-Sampled", "213")
        .contentType(MediaType.APPLICATION_JSON);

    mockMvc.perform(mockMvcRequestBuilders).andExpect(status().isOk());
    assertNull(transactionRepository.findById(transaction.getTransactionId()).orElse(null));
  }
}
