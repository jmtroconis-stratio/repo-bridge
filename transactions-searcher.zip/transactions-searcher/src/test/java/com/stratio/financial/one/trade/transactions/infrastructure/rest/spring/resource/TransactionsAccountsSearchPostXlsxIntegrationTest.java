package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.resource;

import static io.zonky.test.db.AutoConfigureEmbeddedDatabase.DatabaseProvider.YANDEX;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.stratio.financial.one.trade.transactions.application.repository.TransactionCompanyAccountRepository;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionSummaryData;
import com.stratio.financial.one.trade.transactions.domain.sql.Agent;
import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;
import com.stratio.financial.one.trade.transactions.infrastructure.config.spring.StratioSpringBootService;
import com.stratio.financial.one.trade.transactions.infrastructure.db.springdata.repository.SpringDataAgentRepository;
import com.stratio.financial.one.trade.transactions.infrastructure.db.springdata.repository.SpringDataTransactionRepository;
import com.stratio.financial.one.trade.transactions.infrastructure.es.repository.StratioSearcherRepository;
import io.zonky.test.db.AutoConfigureEmbeddedDatabase;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.rules.SpringClassRule;
import org.springframework.test.context.junit4.rules.SpringMethodRule;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

@RunWith(Parameterized.class)
@SpringBootTest(classes = StratioSpringBootService.class)
@ActiveProfiles("integration")
@AutoConfigureMockMvc
@AutoConfigureEmbeddedDatabase(provider = YANDEX)
@EmbeddedKafka(brokerProperties = {"transaction.state.log.replication.factor=1",
    "transaction.state.log.min.isr=1"})
public class TransactionsAccountsSearchPostXlsxIntegrationTest {

  private static final String INPUT_PATH = "src/test/resources/infrastructure/rest/spring/resource/input/";
  private static final String REQUEST_PATH = "src/test/resources/infrastructure/es/";

  @ClassRule
  public static final SpringClassRule scr = new SpringClassRule();

  @Rule
  public final SpringMethodRule smr = new SpringMethodRule();

  @MockBean
  StratioSearcherRepository stratioSearcherRepository;

  @Autowired
  SpringDataAgentRepository agentRepository;

  @Autowired
  SpringDataTransactionRepository transactionRepository;

  @Autowired
  TransactionCompanyAccountRepository transactionCompanyAccountRepository;

  @Autowired
  MockMvc mockMvc;

  private final String agent;
  private final String input;
  private final String transactionsNotConsolidatedConsolidated;
  private final Transaction[] transactions;
  private final ObjectMapper objectMapper;

  public TransactionsAccountsSearchPostXlsxIntegrationTest(String agent, String input,
      String transactionsNotConsolidatedConsolidated, String inputTransaction)
      throws IOException {
    objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
    this.agent = Files.readString(Path.of(INPUT_PATH + agent));
    this.input = Files.readString(Path.of(INPUT_PATH + input));
    this.transactionsNotConsolidatedConsolidated = Files
        .readString(Path.of(REQUEST_PATH + transactionsNotConsolidatedConsolidated));
    this.transactions = objectMapper
        .readValue(Path.of(INPUT_PATH + inputTransaction).toFile(),
            Transaction[].class);
  }

  @Parameters(name = "Test for: {0} - {1} - {2} - {3}")
  public static Collection jsonExamples() {
    return Arrays.asList(new Object[][]{
        {"agent.json", "requestTransactionsSearchXlsxPostLUMultiple.json",
            "transactionSummaryData_case3.json", "transactionsPostSearch.json"}
    });
  }

  @Before
  public void setUp() throws IOException {
    Arrays.stream(transactions).forEach(transaction -> {
      transactionCompanyAccountRepository.upsert(transaction.getTransactionCompanyAccount());
      transaction.setTransactionCompanyAccount(null);
      transactionRepository.saveAll(List.of(transaction));
    });
    agentRepository.save(objectMapper.readValue(agent, Agent.class));
  }

  @After
  public void tearDown() {
    transactionRepository.deleteAll();
    transactionCompanyAccountRepository.deleteAll();
    agentRepository.deleteAll();
  }

  @Test
  public void transactionsAccountsSearchPostTest() throws Exception {
    TransactionSummaryData transactionSummaryData = objectMapper.readValue(transactionsNotConsolidatedConsolidated,
        TransactionSummaryData.class);
    when(stratioSearcherRepository.search(any()))
        .thenReturn(transactionSummaryData);

    MockHttpServletRequestBuilder mockMvcRequestBuilders = post(
        "/transactions/accounts/search/xslx")
        .header("X-B3-TraceId", "123")
        .header("X-B3-SpanId", "231")
        .header("X-B3-ParentSpanId", "321")
        .header("X-B3-Sampled", "213")
        .contentType(MediaType.APPLICATION_JSON)
        .content(input);
    MvcResult mvcResult = mockMvc.perform(mockMvcRequestBuilders).andExpect(status().isOk())
        .andReturn();
    Assert.assertEquals(200, mvcResult.getResponse().getStatus());
  }

}
