package com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.resource;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import com.stratio.financial.one.trade.transactions.application.repository.TransactionDataRepository;
import com.stratio.financial.one.trade.transactions.application.service.AgentService;
import com.stratio.financial.one.trade.transactions.application.service.TransactionService;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionSummaryData;
import com.stratio.financial.one.trade.transactions.domain.search.AccountsCountriesList;
import com.stratio.financial.one.trade.transactions.domain.search.RequestQuery;
import com.stratio.financial.one.trade.transactions.domain.sql.Agent;
import com.stratio.financial.one.trade.transactions.domain.sql.Transaction;
import com.stratio.financial.one.trade.transactions.infrastructure.es.mapper.TransactionDataMapper;
import com.stratio.financial.one.trade.transactions.infrastructure.es.service.TransactionDataService;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.AccountsCountriesListDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.LastProcessedDateOutputDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.RequestQueryDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.RequestQueryXslxDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.dto.TransactionsResponseDto;
import com.stratio.financial.one.trade.transactions.infrastructure.rest.spring.mapper.TransactionMapper;
import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;
import uk.co.jemos.podam.api.RandomDataProviderStrategyImpl;

@RunWith(JUnit4.class)
public class TransactionsApiResourceTest {

  private final TransactionService transactionService = Mockito.mock(TransactionService.class);
  private final TransactionDataRepository transactionDataRepository = Mockito
      .mock(TransactionDataRepository.class);
  private final TransactionMapper transactionMapper = Mockito.mock(TransactionMapper.class);
  private final TransactionDataService transactionDataService = Mockito
      .mock(TransactionDataService.class);
  private final AgentService agentService = Mockito.mock(AgentService.class);
  private final TransactionsApiResource transactionsApiResource = new TransactionsApiResource(
      agentService, transactionService,
      transactionDataService, transactionDataRepository, transactionMapper);
  private TransactionDataMapper transactionDataMapper = Mockito.mock(TransactionDataMapper.class);
  private String xB3TraceId;
  private String xB3SpanId;
  private String xB3ParentSpanId;
  private String xB3Sampled;
  private String dateTo;
  private Integer size;
  private RequestQueryDto requestQueryDto;
  private RequestQuery requestQuery;
  private String accountId;
  private String country;
  private String milliseconds;
  private TransactionSummaryData transactionsSummaryData;
  private TransactionsResponseDto transactionsResponseDto;
  private List<Transaction> transactions;
  private AccountsCountriesList accountsCountriesList;
  private AccountsCountriesListDto accountsCountriesListDto;
  private LastProcessedDateOutputDto lastProcessedDateOutputDto;
  private Agent agent;
  private ByteArrayResource byteArrayResource;
  private RequestQueryXslxDto requestQueryXslxDto;

  @Before
  public void setUp() {
    Logger root = (Logger) LoggerFactory.getLogger("uk.co.jemos.podam.api");
    root.setLevel(Level.ERROR);
    RandomDataProviderStrategyImpl randomDataProviderStrategy = new RandomDataProviderStrategyImpl();
    randomDataProviderStrategy.setMaxDepth(1);
    PodamFactory podamFactory = new PodamFactoryImpl();
    podamFactory.setStrategy(randomDataProviderStrategy);

    xB3TraceId = podamFactory.manufacturePojo(String.class);
    xB3SpanId = podamFactory.manufacturePojo(String.class);
    xB3ParentSpanId = podamFactory.manufacturePojo(String.class);
    xB3Sampled = podamFactory.manufacturePojo(String.class);
    dateTo = podamFactory.manufacturePojo(String.class);
    size = podamFactory.manufacturePojo(Integer.class);
    requestQueryDto = podamFactory.manufacturePojo(RequestQueryDto.class);
    requestQuery = podamFactory.manufacturePojo(RequestQuery.class);
    accountId = podamFactory.manufacturePojo(String.class);
    country = podamFactory.manufacturePojo(String.class);
    milliseconds = podamFactory.manufacturePojo(String.class);
    transactionsSummaryData = podamFactory.manufacturePojo(TransactionSummaryData.class);
    transactionsResponseDto = podamFactory.manufacturePojo(TransactionsResponseDto.class);
    transactions = Arrays.asList(podamFactory.manufacturePojo(Transaction[].class));
    accountsCountriesList = podamFactory.manufacturePojo(AccountsCountriesList.class);
    accountsCountriesListDto = podamFactory.manufacturePojo(AccountsCountriesListDto.class);
    lastProcessedDateOutputDto = podamFactory.manufacturePojo(LastProcessedDateOutputDto.class);
    agent = podamFactory.manufacturePojo(Agent.class);
    byteArrayResource = podamFactory.manufacturePojo(ByteArrayResource.class);
    requestQueryXslxDto = podamFactory.manufacturePojo(RequestQueryXslxDto.class);

    requestQuery.getAccountsCountriesList().stream().forEach(accountsCountries -> {
      accountsCountries.setMustIncludeNotConsolidated(false);
      accountsCountries.setProcessedDateFrom(null);
    });
  }

  @Test
  public void transactionsAccountsSearchPostConsolidated() {
    when(transactionMapper.requestQueryDtoToRequestQuery(requestQueryDto))
        .thenReturn(requestQuery);
    when(transactionDataRepository.search(requestQuery))
        .thenReturn(transactionsSummaryData);
    when(
        transactionMapper.transactionsSummaryDataToTransactionsResponseDto(transactionsSummaryData))
        .thenReturn(transactionsResponseDto);

    requestQuery.setTypeOfTransaction(false);
    ResponseEntity<TransactionsResponseDto> response = transactionsApiResource
        .transactionsAccountsSearchPost(xB3TraceId,
            xB3SpanId, xB3ParentSpanId, xB3Sampled, requestQueryDto);

    checkSearch_whenOnlyConsolidated();
    assertTrue(response.getStatusCode().is2xxSuccessful());
    assertEquals(transactionsResponseDto, response.getBody());

  }

  @Test
  public void transactionsAccountsSearchPostNotConsolidated() {
    String processedDate = "2020-07-10T13:15:51+0000";

    when(transactionMapper.requestQueryDtoToRequestQuery(requestQueryDto))
        .thenReturn(requestQuery);
    when(transactionMapper.instantToElasticFormatString(transactions.get(0).getProcessedDate()))
        .thenReturn(processedDate);

    requestQuery.getAccountsCountriesList().stream().forEach(accountsCountry -> {
      AccountsCountriesList accountsCountriesList = new AccountsCountriesList();
      accountsCountriesList.add(accountsCountry);
      when(transactionService.getLastTransactionsDateTime(accountsCountriesList)).thenReturn(List.of(transactions.get(0)));
    });

    when(transactionDataRepository.search(requestQuery))
        .thenReturn(transactionsSummaryData);
    when(transactionMapper.transactionsSummaryDataToTransactionsResponseDto(any()))
        .thenReturn(transactionsResponseDto);

    requestQuery.setTypeOfTransaction(true);
    ResponseEntity<TransactionsResponseDto> response = transactionsApiResource
        .transactionsAccountsSearchPost(xB3TraceId,
            xB3SpanId, xB3ParentSpanId, xB3Sampled, requestQueryDto);

    checkSearch_whenBothConsolidatedNotConsolidated(processedDate);
    verify(transactionService, times(5)).getLastTransactionsDateTime(any());
    verify(transactionMapper, times(5)).instantToElasticFormatString(any());
    assertTrue(response.getStatusCode().is2xxSuccessful());
    assertEquals(transactionsResponseDto, response.getBody());
  }

  @Test
  public void transactionsLastProcessedDateGet() {
    when(
        transactionMapper.accountsCountriesListDtoToAccountsCountriesList(accountsCountriesListDto))
        .thenReturn(accountsCountriesList);
    when(transactionService.getLastTransactionsDateTime(accountsCountriesList))
        .thenReturn(transactions);
    when(transactionMapper.transactionsToLastProcessedDateOutputDto(transactions))
        .thenReturn(lastProcessedDateOutputDto);

    ResponseEntity<LastProcessedDateOutputDto> response = transactionsApiResource
        .transactionsLastProcessedDatePost(
            xB3TraceId, xB3SpanId, xB3ParentSpanId, xB3Sampled, accountsCountriesListDto);

    assertTrue(response.getStatusCode().is2xxSuccessful());
    assertEquals(lastProcessedDateOutputDto, response.getBody());
  }

  @Test
  public void transactionsTocreationdateDateToOldNotConsolidatedDelete() {
    ResponseEntity<Void> response = transactionsApiResource
        .transactionsTocreationdateDateToOldNotConsolidatedDelete(
            xB3TraceId, xB3SpanId, xB3ParentSpanId, xB3Sampled, dateTo, size);

    verify(transactionDataService, times(1)).deleteOldNotConsolidated(dateTo, size);
    assertTrue(response.getStatusCode().is2xxSuccessful());
  }

  @Test
  public void transactionsAccountsSearchXslxPostTest() throws IOException {
    when(transactionMapper.requestQueryXlsxDtoToRequestQuery(requestQueryXslxDto))
        .thenReturn(requestQuery);
    requestQuery.setTypeOfTransaction(false);
    when(transactionDataRepository.search(requestQuery))
        .thenReturn(transactionsSummaryData);
    when(agentService.findAllAgents(any())).thenReturn(List.of(agent));
    when(transactionMapper.transactionsSummaryDataToByteArrayResource(any(),any(),any())).thenReturn(byteArrayResource);
    when(transactionMapper.requestQueryXlsxDtoToRequestQuery(any())).thenReturn(requestQuery);

    ResponseEntity<Resource> response = transactionsApiResource
        .transactionsAccountsSearchXslxPost(xB3TraceId,
            xB3SpanId, xB3ParentSpanId, xB3Sampled, requestQueryXslxDto);

    checkSearch_whenOnlyConsolidated();
    assertTrue(response.getStatusCode().is2xxSuccessful());
  }

  @Test
  public void transactionsAccountsSearchXslxPostNotFoundTest() throws IOException {
    String processedDate = "2020-07-10T13:15:51+0000";
    transactionsSummaryData.setTransactions(Lists.emptyList());

    when(transactionMapper.requestQueryDtoToRequestQuery(requestQueryDto))
        .thenReturn(requestQuery);
    when(transactionMapper.instantToElasticFormatString(transactions.get(0).getProcessedDate()))
        .thenReturn(processedDate);

    requestQuery.getAccountsCountriesList().stream().forEach(accountsCountry -> {
      AccountsCountriesList accountsCountriesList = new AccountsCountriesList();
      accountsCountriesList.add(accountsCountry);
      when(transactionService.getLastTransactionsDateTime(accountsCountriesList)).thenReturn(List.of(transactions.get(0)));
    });

    when(transactionMapper.requestQueryXlsxDtoToRequestQuery(requestQueryXslxDto))
        .thenReturn(requestQuery);
    requestQuery.setTypeOfTransaction(true);
    when(transactionDataRepository.search(any()))
        .thenReturn(transactionsSummaryData);
    when(agentService.findAllAgents(any())).thenReturn(List.of(agent));
    when(transactionMapper.transactionsSummaryDataToByteArrayResource(any(),any(),any())).thenReturn(byteArrayResource);
    when(transactionMapper.requestQueryXlsxDtoToRequestQuery(any())).thenReturn(requestQuery);

    ResponseEntity<Resource> response = transactionsApiResource
        .transactionsAccountsSearchXslxPost(xB3TraceId,
            xB3SpanId, xB3ParentSpanId, xB3Sampled, requestQueryXslxDto);

    checkSearch_whenBothConsolidatedNotConsolidated(processedDate);
    assertTrue(response.getStatusCode().equals(HttpStatus.NO_CONTENT));
  }

  private void checkSearch_whenOnlyConsolidated(){
    ArgumentCaptor<RequestQuery> argumentRequestQuery = ArgumentCaptor.forClass(RequestQuery.class);
    verify(transactionDataRepository, times(1)).search(argumentRequestQuery.capture());
    assertEquals(requestQuery.getAccountsCountriesList().size(), argumentRequestQuery.getValue().getAccountsCountriesList().size());
      argumentRequestQuery.getValue().getAccountsCountriesList().forEach(accountsCountries -> {
      assertNull(accountsCountries.getProcessedDateFrom());
      assertFalse(accountsCountries.isMustIncludeNotConsolidated());
    });
  }

  private void checkSearch_whenBothConsolidatedNotConsolidated(String processedDate){
    ArgumentCaptor<RequestQuery> argumentRequestQuery = ArgumentCaptor.forClass(RequestQuery.class);
    verify(transactionDataRepository, times(1)).search(argumentRequestQuery.capture());
    assertEquals(requestQuery.getAccountsCountriesList().size(), argumentRequestQuery.getValue().getAccountsCountriesList().size());
    argumentRequestQuery.getValue().getAccountsCountriesList().forEach(accountsCountries -> {
      assertEquals(processedDate, accountsCountries.getProcessedDateFrom());
      assertTrue(accountsCountries.isMustIncludeNotConsolidated());
    });
  }
}
