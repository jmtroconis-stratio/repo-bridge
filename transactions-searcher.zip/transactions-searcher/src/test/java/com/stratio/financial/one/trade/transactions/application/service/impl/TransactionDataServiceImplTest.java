package com.stratio.financial.one.trade.transactions.application.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import com.stratio.financial.one.trade.transactions.application.repository.TransactionDataRepository;
import com.stratio.financial.one.trade.transactions.application.repository.TransactionRepository;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionData;
import com.stratio.financial.one.trade.transactions.domain.data.TransactionSummaryData;
import com.stratio.financial.one.trade.transactions.infrastructure.es.mapper.TransactionDataMapper;
import com.stratio.financial.one.trade.transactions.infrastructure.es.service.impl.TransactionDataServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.slf4j.LoggerFactory;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;
import uk.co.jemos.podam.api.RandomDataProviderStrategyImpl;
import uk.co.jemos.podam.common.PodamCollection;

@RunWith(JUnit4.class)
public class TransactionDataServiceImplTest {

  private final TransactionDataRepository transactionDataRepository = mock(TransactionDataRepository.class);
  private final TransactionRepository transactionRepository = mock(TransactionRepository.class);
  private final TransactionDataMapper transactionDataMapper = mock(TransactionDataMapper.class);
  private final TransactionDataServiceImpl transactionDataService = new TransactionDataServiceImpl(
      transactionDataRepository,  transactionRepository, transactionDataMapper);

  @PodamCollection
  private final List<TransactionData> transactionDataList = new ArrayList<>();
  private TransactionSummaryData transactionSummaryData;
  private TransactionSummaryData transactionSummaryDataEmptyTransactions;
  private String dateTo;
  private String date;
  private Integer size;
  private Boolean consolidated;

  @Before
  public void setUp() {
    Logger root = (Logger) LoggerFactory.getLogger("uk.co.jemos.podam.api");
    root.setLevel(Level.ERROR);
    RandomDataProviderStrategyImpl randomDataProviderStrategy = new RandomDataProviderStrategyImpl();
    randomDataProviderStrategy.setMaxDepth(1);
    PodamFactory podamFactory = new PodamFactoryImpl();
    podamFactory.setStrategy(randomDataProviderStrategy);

    transactionSummaryData = podamFactory.manufacturePojo(TransactionSummaryData.class);
    transactionSummaryDataEmptyTransactions = podamFactory.manufacturePojo(TransactionSummaryData.class);
    transactionSummaryDataEmptyTransactions.getTransactions().clear();
    dateTo = podamFactory.manufacturePojo(String.class);
    date = podamFactory.manufacturePojo(String.class);
    size = podamFactory.manufacturePojo(Integer.class);
    consolidated = podamFactory.manufacturePojo(Boolean.class);
  }

  @Test
  public void save() {
    transactionDataService.save(transactionSummaryData);

    verify(transactionDataRepository, times(1)).index(transactionSummaryData.getTransactions());
  }

  @Test
  public void delete() {
    transactionDataService.delete(transactionDataList);

    verify(transactionDataRepository, times(1)).delete(transactionDataList);
  }

  @Test
  public void deleteOldNotConsolidated() {
    when(transactionDataService.searchToDate(dateTo, size, false)).thenReturn(transactionSummaryData)
        .thenReturn(transactionSummaryDataEmptyTransactions);

    transactionDataService.deleteOldNotConsolidated(dateTo, size);

    verify(transactionRepository, times(1)).deleteAll(any());
    verify(transactionDataRepository, times(1)).delete(any());
  }

  @Test
  public void searchToDate() {
    when(transactionDataRepository.searchToDate(date, 0, size, consolidated))
        .thenReturn(transactionSummaryData);

    TransactionSummaryData response = transactionDataService.searchToDate(date, size, consolidated);

    assertEquals(transactionSummaryData, response);
  }
}
