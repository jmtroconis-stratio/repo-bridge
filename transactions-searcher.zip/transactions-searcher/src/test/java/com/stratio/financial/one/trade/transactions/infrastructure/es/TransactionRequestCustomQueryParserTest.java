package com.stratio.financial.one.trade.transactions.infrastructure.es;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.stratio.financial.one.trade.transactions.domain.search.RequestQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.customquery.ElasticCustomQuery;
import com.stratio.financial.one.trade.transactions.infrastructure.es.parser.TransactionRequestCustomQueryParser;
import lombok.SneakyThrows;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collection;

@RunWith(Parameterized.class)
public class TransactionRequestCustomQueryParserTest {

  private final String INPUT_PATH = "src/test/resources/infrastructure/es/input/";
  private final String OUTPUT_PATH = "src/test/resources/infrastructure/es/output/";

  private String input;
  private String output;
  private Boolean consolidated;
  private String creationDate;
  private ObjectMapper objectMapper;
  private TransactionRequestCustomQueryParser parser;

  public TransactionRequestCustomQueryParserTest(String input, String output, Boolean consolidated,
                                                 String creationDate) throws IOException {
    this.input = Files.readString(Path.of(INPUT_PATH + input));
    this.output = Files.readString(Path.of(OUTPUT_PATH + output));
    this.consolidated = consolidated;
    this.creationDate = creationDate;
    parser = new TransactionRequestCustomQueryParser();
    objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
  }

  @Parameters(name = "Test for: {0} - {1} - {2} - {3}")
  public static Collection jsonExamples() {
    return Arrays.asList(new Object[][]{
        {"requestCustomQueryAllFields.json", "paramsCustomQueryAllFields.json", false, "2020-05-15T00:05:01.000+0000"},
        {"requestCustomQueryWithAccountId.json", "paramsCustomQueryWithAccountId.json", true, null},
        {"requestCustomQueryNoTypeCreditDebit.json", "paramsCustomQueryNoTypeCreditDebit.json", true, null}
    });
  }

  @Test
  @SneakyThrows
  public void shouldParseRequestQueryWithAccountCountry() {
    ElasticCustomQuery query = parser.parse(objectMapper.readValue(input, RequestQuery.class));
    JSONAssert.assertEquals(output, objectMapper.writeValueAsString(query), JSONCompareMode.NON_EXTENSIBLE);
  }
}
