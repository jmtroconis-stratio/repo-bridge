#!groovy
import com.stratio.cicdcd.governance.promotion.Governance
import com.stratio.cicdcd.governance.utils.PromotionType

void authenticate(Map args = [:]){
    PromotionType promotionType = PromotionType.valueOf(args.promotionType)

    Governance governance = new Governance(this)
    governance.getUserProfile(promotionType.sourceEnv)
    governance.getUserProfile(promotionType.targetEnv)
}

void exportResources(Map parameters = [:]){
    Governance governance = new Governance(this)
    governance.exportResources(parameters)
}

void importResources(Map parameters = [:]){
    Governance governance = new Governance(this)
    governance.importResources(parameters)
}