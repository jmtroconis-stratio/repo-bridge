package com.stratio.cicdcd.governance.promotion

import com.stratio.cicdcd.governance.api.GovernanceApi
import com.stratio.cicdcd.governance.api.UserProfileCache
import com.stratio.cicdcd.governance.dto.UserProfile
import com.stratio.cicdcd.governance.utils.Environment

class Governance implements Serializable {

    def pipeline
    GovernanceApi api

    Governance(pipeline) {
        this.pipeline = pipeline
        this.api = new GovernanceApi(pipeline)
    }

    UserProfile getUserProfile(Environment env){
        UserProfile userProfile = UserProfileCache.instance.getUserProfile(env)
        if (!userProfile) {
            userProfile = api.getUserProfile(env)
            UserProfileCache.instance.putUserProfile(env, userProfile)
        }

        userProfile
    }

    void exportResources(Map parameters){
        List<GovernanceResource> resourceList = this.getResources(parameters)
        resourceList.forEach(api.exportResource())
    }

    void importResources(Map parameters){
        List<GovernanceResource> resourceList = this.getResources(parameters)
        resourceList.forEach(api.importResource())
    }

    private List<GovernanceResource> getResources(Map parameters){
        List<GovernanceResource> resourceList

        if (parameters.all){
            resourceList.addAll(Arrays.asList(GovernanceResource.values()))
            return resourceList
        }

        if (parameters.catalogKeyAction){
            resourceList.add(GovernanceResource.CATALOG_KEY_ACTION)
        }

        if (parameters.qualityEnvironmentAction){
            resourceList.add(GovernanceResource.QUALITY_ENVIRONMENT_ACTION)
        }


        // TODO for each
    }

}
