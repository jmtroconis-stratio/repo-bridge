package com.stratio.cicdcd.governance.promotion

enum GovernanceResource implements Serializable {

    CATALOG_KEY_ACTION('catalogKeyAction'),
    QUALITY_ENVIRONMENT_ACTION('qualityEnvironmentAction'),
    GLOSSARY_BUSINESS_ASSET_ACTION('glossaryBusinessAssetAction'),
    GLOSSARY_KEY_BUSINESS_ASSET_ACTION('glossaryKeyBusinessAssetAction'),
    CATALOG_DATA_ASSET_ACTION('catalogDataAssetAction'),
    CATALOG_KEY_DATA_ASSET_ACTION('catalogKeyDataAssetAction'),
    GLOSSARY_BUSINESS_ASSET_DATA_ASSET_ACTION('glossaryBusinessAssetDataAssetAction'),
    QUALITY_QUALITY_ACTION('qualityQualityAction'),
    QUALITY_KEY_QUALITY_ACTION('qualityKeyQualityAction'),
    QUALITY_BUSINESS_ASSET_QUALITY_ACTION('qualityBusinessAssetQualityAction')

    final String parameter

    GovernanceResource(String parameter) {
        this.parameter = parameter
    }

    String getParameter() {
        return parameter
    }
}
