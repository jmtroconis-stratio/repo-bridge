package com.stratio.cicdcd.governance.api

import com.stratio.cicdcd.governance.dto.UserProfile
import com.stratio.cicdcd.governance.utils.Environment

/**
 * Singleton class used for caching auth data
 */
class UserProfileCache implements Serializable {
    private static final INSTANCE = new UserProfileCache()
    def userProfileMap = [:]

    private UserProfileCache() {
    }

    static getInstance() {
        return INSTANCE
    }

    void putUserProfile(Environment key, UserProfile value){
        userProfileMap.put(key, value)
    }

    UserProfile getUserProfile(Environment key){
        userProfileMap.get(key)
    }

}