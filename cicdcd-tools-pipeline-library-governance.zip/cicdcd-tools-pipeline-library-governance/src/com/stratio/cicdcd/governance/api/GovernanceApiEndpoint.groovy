package com.stratio.cicdcd.governance.api

import com.stratio.cicdcd.governance.promotion.GovernanceResource

enum GovernanceApiEndpoint implements Serializable {

    CATALOG_KEY_ACTION_ENDPOINT(GovernanceResource.CATALOG_KEY_ACTION, '/user/catalog/v1/keyAction/export', '/user/catalog/v1/keyAction/import'),
    QUALITY_ENVIRONMENT_ACTION_ENDPOINT(GovernanceResource.QUALITY_ENVIRONMENT_ACTION, '/user/quality/v1/environmentAction/export', '/user/quality/v1/environmentAction/import'),
    GLOSSARY_BUSINESS_ASSET_ACTION_ENDPOINT(GovernanceResource.GLOSSARY_BUSINESS_ASSET_ACTION, '/user/glossary/v2/businessAssetAction/export', '/user/glossary/v2/businessAssetAction/import'),
    GLOSSARY_KEY_BUSINESS_ASSET_ACTION_ENDPOINT(GovernanceResource.GLOSSARY_KEY_BUSINESS_ASSET_ACTION, '/user/glossary/v1/keyBusinessAssetAction/export', '/user/glossary/v1/keyBusinessAssetAction/import'),
    CATALOG_DATA_ASSET_ACTION_ENDPOINT(GovernanceResource.CATALOG_DATA_ASSET_ACTION, '/user/catalog/v1/dataAssetAction/export', '/user/catalog/v1/dataAssetAction/import'),
    CATALOG_KEY_DATA_ASSET_ACTION_ENDPOINT(GovernanceResource.CATALOG_KEY_DATA_ASSET_ACTION, '/user/catalog/v1/keyDataAssetAction/export', '/user/catalog/v1/keyDataAssetAction/import'),
    GLOSSARY_BUSINESS_ASSET_DATA_ASSET_ACTION_ENDPOINT(GovernanceResource.GLOSSARY_BUSINESS_ASSET_DATA_ASSET_ACTION, '/user/glossary/v1/businessAssetDataAssetAction/export', '/user/glossary/v1/businessAssetDataAssetAction/import'),
    QUALITY_QUALITY_ACTION_ENDPOINT(GovernanceResource.QUALITY_QUALITY_ACTION, '/user/quality/v1/qualityAction/export', '/user/quality/v1/qualityAction/import'),
    QUALITY_KEY_QUALITY_ACTION_ENDPOINT(GovernanceResource.QUALITY_KEY_QUALITY_ACTION, '/user/quality/v1/keyQualityAction/export', '/user/quality/v1/keyQualityAction/import'),
    QUALITY_BUSINESS_ASSET_QUALITY_ACTION_ENDPOINT(GovernanceResource.QUALITY_BUSINESS_ASSET_QUALITY_ACTION, '/user/quality/v1/businessAssetQualityAction/export', '/user/quality/v1/businessAssetQualityAction/import')

    final GovernanceResource resource
    final String exportEndpoint
    final String importEndpoint

    GovernanceApiEndpoint(GovernanceResource resource, String exportEndpoint, String importEndpoint) {
        this.resource = resource
        this.exportEndpoint = exportEndpoint
        this.importEndpoint = importEndpoint
    }

    GovernanceResource getResource() {
        return resource
    }

    String getExportEndpoint() {
        return exportEndpoint
    }

    String getImportEndpoint() {
        return importEndpoint
    }
}
