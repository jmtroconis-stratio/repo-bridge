package com.stratio.cicdcd.governance.api

import com.stratio.cicdcd.governance.promotion.GovernanceResource
import com.stratio.cicdcd.governance.utils.Environment

class GovernanceApi implements Serializable {

    def pipeline

    GovernanceApi(pipeline) {
        this.pipeline = pipeline
    }

    void getUserProfile(Environment env){
        // TODO: REQUEST TO API
    }

    void exportResource(GovernanceResource resource){
        String endpoint = this.getApiEndpoint(resource).exportEndpoint
        executeRequest(endpoint)
    }

    void importResource(GovernanceResource resource){
        String endpoint = this.getApiEndpoint(resource).importEndpoint
        executeRequest(endpoint)
    }

    private GovernanceApiEndpoint getApiEndpoint(GovernanceResource resource){
        GovernanceApiEndpoint.find { resource == it.resource }
    }

    private executeRequest(){

    }

}
