package com.stratio.cicdcd.governance.utils

/**
 * Enum for each environment involved in the promotion process.
 */
enum Environment implements Serializable {
    DEV,
    PRE,
    PRO
}