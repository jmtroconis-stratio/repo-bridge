package com.stratio.cicdcd.governance.utils

/**
 * Class that resolves the names of the environment variables and credentials in Jenkins slave
 */
class EnvVarResolver implements Serializable {

    /**
     * Resolve the environment variable name for the sparta url
     * @param env
     * @return environment variable name
     */
    static String getEnvVarName(EnvVarEnum var, Environment env) {
        return "${var}_${env}"
    }

    /**
     * Resolve the environment variable value for the sparta url
     * @param pipeline
     * @param env variable
     * @param env
     * @return Environment variable value
     */
    static String getEnvVarValue(pipeline, EnvVarEnum var, Environment env) {
        return pipeline.env[getEnvVarName(var, env)]
    }

}
