package com.stratio.cicdcd.governance.utils

/**
 * Defines the names of the environment variables in Jenkins slave
 */
enum EnvVarEnum implements Serializable {
    GOVERNANCE_TENANT,
    GOVERNANCE_URL,
    GOVERNANCE_CREDENTIALS
}