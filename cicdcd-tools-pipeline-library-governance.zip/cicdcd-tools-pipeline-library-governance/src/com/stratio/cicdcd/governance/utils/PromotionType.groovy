package com.stratio.cicdcd.governance.utils

/**
 * Promotion types supported by the promotion process.
 * Defines the relation between the different environment involved in a promotion process.
 * - sourceEnv: Source environment from which the export process will be done.
 * - targetEnv: Target environment to which the import process will be done.
 */
enum PromotionType implements Serializable {
    RC(Environment.DEV, Environment.PRE),
    RELEASE(Environment.PRE, Environment.PRO)

    private final Environment sourceEnv
    private final Environment targetEnv

    PromotionType(Environment sourceEnv, Environment targetEnv) {
        this.sourceEnv = sourceEnv
        this.targetEnv = targetEnv
    }

    Environment getSourceEnv() {
        return sourceEnv
    }

    Environment getTargetEnv() {
        return targetEnv
    }
}