package com.stratio.cicdcd.governance.dto

class UserProfile implements Serializable {

    private String role
    private String tenant
    private String user

}
