package com.stratio.cicdcd.governance.auth

import com.stratio.cicdcd.governance.utils.EnvVarEnum
import com.stratio.cicdcd.governance.utils.EnvVarResolver
import com.stratio.cicdcd.governance.utils.Environment

class AuthService implements Serializable {

    def pipeline
    private final String DEFAULT_TENANT = 'NONE'

    AuthService(pipeline) {
        this.pipeline = pipeline
    }

    String getAuthCookie(Environment env){
        // Retrieve cached auth cookie value and if not cached then retrieve it from environment
        String authCookie = AuthCache.instance.getAuth(env)
        if (authCookie) {
            pipeline.println "[INFO] Cached auth cookie for $env environment"
        } else {
            pipeline.println "[INFO] Auth cookie not cached, so retrieve it from $env environment"
            authCookie = retrieveAuthCookie(env)
            if (!authCookie) {
                pipeline.error "Unable to login into $env environment"
            }

            // Save retrieved auth cookie in cache
            AuthCache.instance.putAuth(env, authCookie)
        }

        authCookie
    }

    /**
     * Retrieve auth cookie based on the provided environment
     * @param env - Environment for which the auth cookie should be retrieved
     * @return - Auth cookie???
     */
    protected String retrieveAuthCookie(Environment env){
        pipeline.println "[INFO] Getting auth cookie from ${env.name()} environment"

        String authCookie
        String baseUrl = EnvVarResolver.getEnvVarValue(pipeline, EnvVarEnum.GOVERNANCE_URL, env)
        String credentialsIdVarName = EnvVarResolver.getEnvVarName(EnvVarEnum.GOVERNANCE_CREDENTIALS, env)
        String authFile = "auth-${env}-${pipeline.BUILD_TAG}".replace(' ', '-')
        String tenant = EnvVarResolver.getEnvVarValue(pipeline, EnvVarEnum.GOVERNANCE_TENANT, env) ?: DEFAULT_TENANT

        try {
            pipeline.withCredentials([[$class          : 'UsernamePasswordMultiBinding',
                                       credentialsId   : "$credentialsIdVarName",
                                       usernameVariable: 'AUTH_USER',
                                       passwordVariable: 'AUTH_PASS']]) {

                pipeline.withEnv(["AUTH_BASE_URL=$baseUrl",
                                  "AUTH_TENANT=${tenant}",
                                  "AUTH_FILE=$authFile"]) {

                    pipeline.configFileProvider([pipeline.configFile(fileId: 'sso_login', variable: 'SSO_LOGIN_FILE')]) {

                        pipeline.sh "bash ${pipeline.SSO_LOGIN_FILE}"

                        authCookie = pipeline.sh script: "cat '$authFile'", returnStdout: true
                        authCookie = authCookie.replaceAll("\\n", "").replaceAll("\\r", "")
                    }
                }
            }
        } catch (Exception e){
            pipeline.println "[ERROR] Error getting auth cookie: ${e.getMessage()}"
            pipeline.println "Unable to login into $baseUrl with credentials $credentialsIdVarName"
        }

        return authCookie
    }

}
