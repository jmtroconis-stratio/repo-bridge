package com.stratio.cicdcd.governance.auth

import com.stratio.cicdcd.governance.utils.Environment

/**
 * Singleton class used for caching auth data
 */
class AuthCache implements Serializable {
    private static final INSTANCE = new AuthCache()
    def authDataMap = [:]

    private AuthCache() {
    }

    static getInstance() {
        return INSTANCE
    }

    void putAuth(Environment key, String value){
        authDataMap.put(key, value)
    }

    String getAuth(Environment key){
        authDataMap.get(key)
    }

}