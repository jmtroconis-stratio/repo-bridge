# Changelog

## Prerequisites of the current version

* cicdcd-tools-pipeline-library-commons >= 3.6.0

## 0.1.0

- Initial version of the Governance pipeline.
