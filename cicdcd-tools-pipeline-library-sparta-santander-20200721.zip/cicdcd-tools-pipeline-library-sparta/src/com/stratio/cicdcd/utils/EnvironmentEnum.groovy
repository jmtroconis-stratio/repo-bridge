package com.stratio.cicdcd.utils

/**
 * Enum for each environment involved in the workflow promotion process.
 * - value: used to have another name for the environment in lower case used in the Jenkins credentials naming.
 * - label: used to have a label name for the environment, decoupled from the environment name and more related to the usage of the workflow in the environment.
 *          Used for the naming of the Serenity tests reports.
 */
enum EnvironmentEnum implements Serializable {
    DEV('dev', 'DEV'),
    PRE('pre', 'RC'),
    PRO('pro', 'RELEASE')

    private final String value
    private final String label

    EnvironmentEnum(String value, String label) {
        this.value = value
        this.label = label
    }
}