package com.stratio.cicdcd.utils

class SpartaUtils {

    /**
     * Resolves the Sparta Url for the passed environment based on the environment variables
     * defined in the Jenkins slave
     * @param pipeline
     * @param env
     * @return Sparta url of the env
     */
    static String getSpartaUrl(pipeline, EnvironmentEnum env){
        EnvVarCredentials.getSpartaUrl(pipeline, env)
    }

}
