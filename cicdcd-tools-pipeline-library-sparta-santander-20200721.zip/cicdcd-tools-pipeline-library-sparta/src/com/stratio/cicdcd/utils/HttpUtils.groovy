package com.stratio.cicdcd.utils

import com.santander.alm.pipeline.utils.HttpRestClient
import com.santander.alm.pipeline.utils.HttpRestResponse
import com.stratio.cicdcd.sparta.SpartaResponse

/**
 * Extends HttpRestClient from ALM Global pipeline to execute API requests and parse HttpRestResponse into SpartaResponse
 */
class HttpUtils extends HttpRestClient implements Serializable {

    HttpUtils(pipeline, String cookie) {
        super(pipeline, cookie, true, false)
    }

    def executeGet(pipeline, String url){
        HttpRestResponse response =  doGetHttpRequest(url)
        new SpartaResponse(pipeline, response.statusCode, response.body)
    }

    def executePost(pipeline, String url, String body = null) {
        HttpRestResponse response =  doPostHttpRequestWithJson(body, url)
        new SpartaResponse(pipeline, response.statusCode, response.body)
    }

    def executePut(pipeline, String url, String body = null) {
        HttpRestResponse response =  doPutHttpRequestWithJson(body, url)
        new SpartaResponse(pipeline, response.statusCode, response.body)
    }

    def executeDelete(pipeline, String url){
        HttpRestResponse response =  doDeleteHttpRequest(url)
        new SpartaResponse(pipeline, response.statusCode, response.body)
    }
}
