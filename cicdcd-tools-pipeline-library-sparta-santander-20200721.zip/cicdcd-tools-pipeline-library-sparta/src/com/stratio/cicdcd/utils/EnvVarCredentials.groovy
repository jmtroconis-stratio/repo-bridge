package com.stratio.cicdcd.utils

/**
 * Class that resolves the names of the environment variables and credentials in Jenkins slave
 */
class EnvVarCredentials implements Serializable {

    /**
     * Defines the names of the environment variables in Jenkins slave
     */
    enum CredentialsEnum implements Serializable {
        SPARTA_URL, SPARTA_CREDENTIALS
    }

    /**
     * Resolve the environment variable name for the sparta url
     * @param env
     * @return environment variable name
     */
    static String getSpartaUrlVar(EnvironmentEnum env) {
        return "${CredentialsEnum.SPARTA_URL}_${env.value}"
    }

    /**
     * Resolve the environment variable value for the sparta url
     * @param pipeline
     * @param env
     * @return sparta url
     */
    static String getSpartaUrl(pipeline, EnvironmentEnum env) {
        return pipeline.env[getSpartaUrlVar(env)]
    }

    /**
     * Resolve the environment variable name for the sparta credential of the specified environment
     * @param env
     * @return environment variable name
     */
    static String getSpartaCredentialsVar(EnvironmentEnum env) {
        return "${CredentialsEnum.SPARTA_CREDENTIALS}_${env.value}"
    }

}
