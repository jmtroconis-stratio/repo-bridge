package com.stratio.cicdcd.sparta

import com.stratio.cicdcd.exception.SpartaNotUniqueWorkflowResultException
import com.stratio.cicdcd.exception.SpartaWorkflowAlreadyExistsException
import com.stratio.cicdcd.exception.SpartaWorkflowNotFoundException
import com.stratio.cicdcd.utils.EnvironmentEnum
import groovy.json.JsonSlurper

/**
 * Handles all the interaction with the Sparta API and all the logic related to workflow promotion.
 */
class WorkflowHandler implements Serializable {

    // Sparta api endpoints
    private static final String SPARTA_ENDPOINT_WORKFLOW_FIND = '/workflows/find'
    private static final String SPARTA_ENDPOINT_WORKFLOW_FIND_BY_ID = '/workflows/findById/'
    private static final String SPARTA_ENDPOINT_WORKFLOW_CREATE = '/workflows'
    private static final String SPARTA_ENDPOINT_WORKFLOW_UPDATE = '/workflows'
    private static final String SPARTA_ENDPOINT_WORKFLOW_DELETE = '/workflows/'
    private static final String SPARTA_ENDPOINT_WORKFLOW_RUN_BY_ID = '/workflows/run/'
    private static final String SPARTA_ENDPOINT_GROUP_FIND_BY_NAME = '/groups/findByName/'
    private static final String SPARTA_ENDPOINT_GROUP_CREATE = '/groups'

    private static final String ERROR_CODE_GROUP_NOT_FOUND = "560"
    private static final String ERROR_CODE_WORKFLOW_NOT_FOUND = "702"
    private static final String ERROR_CODE_WORKFLOW_ALREADY_EXISTS = "705"
    private static final String ERROR_CODE_WORKFLOW_ERROR_UPDATING_WORKFLOW = "707"
    private static final String ERROR_CODE_WORKFLOW_ERROR_DELETING_WORKFLOW = "711"

    private def pipeline
    private Api api

    WorkflowHandler(pipeline) {
        this.pipeline = pipeline
        this.api = new Api(pipeline)
    }

    /**
     * Wrapper method used to create or update a workflow in the specified environment. If the group where the workflow belongs doesn't exists, then it's created.
     * @param originEnv - Origin environment involved in the promotion. Used to recreate the group structure from origin to destination.
     * @param destinationEnv - Destination environment involved in the promotion.
     * @param jsonProps - Workflow content being promoted.
     * @return SpartaResponse - Result of the operation
     */
    SpartaResponse createOrUpdateWorkflow(EnvironmentEnum originEnv, EnvironmentEnum destinationEnv, jsonProps) {
        pipeline.println "[INFO] Create or update workflow"

        // Check existence of workflow
        SpartaResponse spartaResponse = api.executeGet(destinationEnv, "$SPARTA_ENDPOINT_WORKFLOW_FIND_BY_ID${jsonProps['id']}")
        if (spartaResponse.isOK && spartaResponse.isJsonResponse && spartaResponse.responseCode == 200) {
            pipeline.println "[INFO] Workflow already exists, so call update workflow"
            updateWorkflow(destinationEnv, jsonProps)
        } else {
            pipeline.println "[INFO] Workflow don't exist, so call create workflow"

            // Check if group exists, if not then create it
            String groupId = jsonProps['group']['id']
            String groupName = jsonProps['group']['name']
            manageGroup(originEnv, destinationEnv, groupId, groupName)
            // Create workflow
            createWorkflow(destinationEnv, jsonProps)
        }
    }

    /**
     * Updates a workflow in the specified environment
     * @param env - Target environment when the update is going to be done.
     * @param jsonProps - Workflow content being updated.
     * @return SpartaResponse - Result of the operation
     */
    SpartaResponse updateWorkflow(EnvironmentEnum env, jsonProps) {
        pipeline.println "[INFO] Updating workflow"
        SpartaResponse spartaResponse = api.executePut(env, SPARTA_ENDPOINT_WORKFLOW_UPDATE, jsonProps.toString())
        if (!spartaResponse.isOK) {
            if (spartaResponse.getErrorCode() == ERROR_CODE_WORKFLOW_ERROR_UPDATING_WORKFLOW) {
                throw new SpartaWorkflowNotFoundException(pipeline, spartaResponse.toString())
            } else { //Other kind of errors
                pipeline.error "[ERROR] Error updating workflow: ${spartaResponse.toString()}"
            }
        }

        pipeline.println "[INFO] Response from Sparta instance: ${spartaResponse.toString()}"
        return spartaResponse
    }

    /**
     * Search for the specified workflow in Sparta. Verifies and parses the API response.
     * @param env - Target environment when the search is going to be done.
     * @param workflowName - Name of the workflow used for identification.
     * @param workflowGroup - Group of the workflow used for identification.
     * @param workflowVersion - Version of the workflow used for identification.
     * @param skipExceptionHandling - Flag used to skip the exception handling. Used when it doesn't matter if the workflow exists to continue with the business process.
     * @return Workflow json of the found element.
     */
    String findWorkflow(EnvironmentEnum env, String workflowName, String workflowGroup, String workflowVersion, Boolean skipExceptionHandling = false) {
        pipeline.println "[INFO] Executing findWorkflow with params: env ${env.name()}, worflowName: $workflowName, workflowGroup: $workflowGroup, workflowVersion: $workflowVersion"

        String body = "{\"name\": \"$workflowName\""
        if (workflowGroup) {
            body += ", \"group\": \"$workflowGroup\""
        }
        if (workflowVersion) {
            body += ", \"version\": $workflowVersion"
        }
        body += "}"

        pipeline.println "Request Body: $body"

        SpartaResponse spartaResponse = api.executePost(env, SPARTA_ENDPOINT_WORKFLOW_FIND, body)
        if (!spartaResponse.isOK || !spartaResponse.isJsonResponse) {
            if (skipExceptionHandling){
                pipeline.println "[INFO] No workflow found, return null with no exception handling to continue execution"
                return null
            }
            if (spartaResponse.getErrorCode() == ERROR_CODE_WORKFLOW_NOT_FOUND) {
                throw new SpartaWorkflowNotFoundException(pipeline, spartaResponse.toString())
            } else { //other errors
                pipeline.error spartaResponse.toString()
            }
        }

        if (new JsonSlurper().parseText(spartaResponse.getResponseBody()).size() > 1) {
            throw new SpartaNotUniqueWorkflowResultException(pipeline, spartaResponse.toString())
        }

        // Transform JSONArray of length 1 into Json
        spartaResponse.getResponseBody().substring(1, spartaResponse.getResponseBody().length() - 1)
    }

    /**
     * Deletes a workflow in the specified environment
     * @param env - Target environment when the delete is going to be done.
     * @param workflowId - Id of the workflow to be deleted.
     * @return SpartaResponse - Result of the operation
     */
    SpartaResponse deleteWorkflow(EnvironmentEnum env, String workflowId){
        pipeline.println "[INFO] Deleting workflow"
        SpartaResponse spartaResponse = api.executeDelete(env, "$SPARTA_ENDPOINT_WORKFLOW_DELETE$workflowId")
        if (!spartaResponse.isOK) {
            if (spartaResponse.getErrorCode() == ERROR_CODE_WORKFLOW_ERROR_DELETING_WORKFLOW) {
                throw new SpartaWorkflowNotFoundException(pipeline, spartaResponse.toString())
            } else { //Other kind of errors
                pipeline.error "[ERROR] Error updating workflow: ${spartaResponse.toString()}"
            }
        }

        pipeline.println "[INFO] Response from Sparta instance: ${spartaResponse.toString()}"
        return spartaResponse
    }

    /**
     * Runs the specified workflow
     * @param env - Target environment when the run is going to be done.
     * @param workflowId - Id of the workflow to be ran.
     * @return SpartaResponse - Result of the operation
     */
    SpartaResponse runWorkflow(EnvironmentEnum env, String workflowId){
        SpartaResponse spartaResponse = api.executePost(env,"$SPARTA_ENDPOINT_WORKFLOW_RUN_BY_ID$workflowId")
        if(!spartaResponse.isOK){
            pipeline.error "[ERROR] Workflow could not be ran: ${spartaResponse.responseBody}"
        }

        pipeline.println "[INFO] Response from Sparta instance: ${spartaResponse.responseCode}"
        spartaResponse
    }

    /**
     * Creates a workflow in the specified environment.
     * @param env - Target environment when the workflow is going to be created.
     * @param jsonProps - Workflow content being created.
     * @return SpartaResponse - Result of the operation
     */
    private SpartaResponse createWorkflow(EnvironmentEnum env, jsonProps) {
        pipeline.println "[INFO] Creating workflow"

        // Create workflow
        SpartaResponse spartaResponse = api.executePost(env, SPARTA_ENDPOINT_WORKFLOW_CREATE, jsonProps.toString())
        if (!spartaResponse.isOK) {
            if (spartaResponse.getErrorCode() == ERROR_CODE_WORKFLOW_ALREADY_EXISTS) {
                throw new SpartaWorkflowAlreadyExistsException(pipeline, spartaResponse.toString())
            } else { //Other kind of errors
                pipeline.error "Error uploading workflow: ${spartaResponse.toString()}"
            }
        }

        pipeline.println "[INFO] Response from Sparta instance: ${spartaResponse.responseCode}"
        spartaResponse
    }

    /**
     * Handles the group creation in destination based on the group structure of the workflow in origin.
     * @param originEnv - Origin environment to take as reference for the workflow's group structure.
     * @param destinationEnv - Destination environment when the group structure will be created if doesn't exist.
     * @param groupId - Id of the group where the workflow belongs.
     * @param groupName - Name of the group where the workflow belongs.
     */
    private void manageGroup(EnvironmentEnum originEnv, EnvironmentEnum destinationEnv, String groupId, String groupName){
        pipeline.println "[INFO] Executing manageGroup"

        // Check if group exists
        SpartaResponse spartaResponse = api.executeGet(destinationEnv, "$SPARTA_ENDPOINT_GROUP_FIND_BY_NAME$groupName")

        if (!spartaResponse.isJsonResponse){
            pipeline.error "[ERROR] Error executing query to find group by name $groupName"
        } else if (!spartaResponse.isOK && spartaResponse.isJsonResponse && spartaResponse.errorCode == ERROR_CODE_GROUP_NOT_FOUND){
            pipeline.println "[INFO] No group found for specified group name: $groupName"

            // Execute recursive invocation of the manageGroup method to handle creation of not existing parent groups
            manageGroup(originEnv, destinationEnv, null, groupName.substring(0, groupName.lastIndexOf("/")))
            // If we don't have groupId for the creation of the group, then retrieve it from origin environment
            if (!groupId){
                SpartaResponse originResponse = api.executeGet(originEnv, "$SPARTA_ENDPOINT_GROUP_FIND_BY_NAME$groupName")
                if (originResponse.isOK && originResponse.isJsonResponse){
                    def jsonProps = pipeline.readJSON text: originResponse.getResponseBody()
                    groupId = jsonProps['id']
                    pipeline.println "[INFO] Retrieved from $originEnv env the groupId $groupId for the group $groupName"
                } else {
                    pipeline.error "[ERROR] Error retrieving groupId for groupName $groupName while building group hierarchy for workflow promotion."
                }
            }

            String group = "{\"id\": \"$groupId\", \"name\": \"$groupName\"}"
            spartaResponse = api.executePost(destinationEnv, SPARTA_ENDPOINT_GROUP_CREATE, group)
            if(spartaResponse.isOK){
                pipeline.println "[INFO] Created group with id $groupId and name $groupName"
            } else {
                pipeline.error "[ERROR] Group $groupName could not be created: ${spartaResponse.toString()}"
            }
        }
    }

}
