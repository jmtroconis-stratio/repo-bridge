package com.stratio.cicdcd.sparta

import com.stratio.cicdcd.utils.EnvironmentEnum

/**
 * Handles all the logic related to workflow versioning when promoting.
 */
class PromotionVersionHandler implements Serializable {

    private final String RC_SEPARATOR = "-"
    private final String RC_PATTERN = "RC" + RC_SEPARATOR
    private final String RC_INITIAL = RC_PATTERN + "1"
    private final String RELEASED = "Released"

    private final String PROMOTION_VERSION_ATTRIBUTE = 'ciCdLabel'

    private def pipeline

    PromotionVersionHandler(pipeline) {
        this.pipeline = pipeline
    }

    /**
     * Modify the passed workflow json in order to change the promotion version.
     * @param jsonProps - Contains the json object to which the promotion version will be updated.
     * @param destinationEnv - Environment destination to which the workflow is being promoted.
     * @param deployedJsonProps - Contains the json object of the already deployed workflow in destination (if it has been promoted previously)
     * @return Json object of the workflow with modified promotion version attribute
     */
    def updateTagsJson(jsonProps, EnvironmentEnum destinationEnv, deployedJsonProps) {
        // Evaluate new workflow promotion version
        def newPromotionVersion
        if (EnvironmentEnum.PRE == destinationEnv){
            // If there is a deployed workflow in destination, then get the promotion version deployed
            String deployedVersion
            if (deployedJsonProps){
                deployedVersion = deployedJsonProps[PROMOTION_VERSION_ATTRIBUTE]
                pipeline.println "[INFO] Deployed version: $deployedVersion"
            }
            // Get the next promotion version number
            newPromotionVersion = incrementPromotionVersion(deployedVersion)
        } else if (EnvironmentEnum.PRO == destinationEnv){
            newPromotionVersion = RELEASED
        }

        // Update workflow with new promotion version
        jsonProps[PROMOTION_VERSION_ATTRIBUTE] = newPromotionVersion
        jsonProps
    }

    /**
     * Verifies if the json workflow contains a promotion version attribute indicating it has been released.
     * @param jsonProps - Json workflow
     * @return boolean - Indicates if the workflow content it has already been released or not.
     */
    boolean isReleasedVersion(jsonProps){
        jsonProps[PROMOTION_VERSION_ATTRIBUTE] == RELEASED
    }

    /**
     * Increments the passed workflow version in order to be used in the next workflow promotion
     * @param promotionVersion
     * @return Increased promotion version
     */
    private String incrementPromotionVersion(String promotionVersion){
        String newPromotionVersion

        if (promotionVersion) {
            def array = promotionVersion.split(RC_SEPARATOR)
            Integer number = Integer.parseInt(array[1])
            newPromotionVersion = "${array[0]}-${++number}"
        } else {
            newPromotionVersion = RC_INITIAL
        }

        pipeline.println "[INFO] New promotion version: $newPromotionVersion"
        newPromotionVersion
    }

}
