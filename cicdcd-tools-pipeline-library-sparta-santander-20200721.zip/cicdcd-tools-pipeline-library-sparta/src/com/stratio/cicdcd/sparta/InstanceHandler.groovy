package com.stratio.cicdcd.sparta

import com.santander.alm.pipeline.utils.SemanticVersion
import com.stratio.cicdcd.utils.EnvironmentEnum

/**
 * Handles the API interaction related to general information related to the Sparta instance
 */
class InstanceHandler implements Serializable {

    private final String SPARTA_ENDPOINT_APP_INFO = '/appInfo'
    private final String SPARTA_APP_INFO_VERSION_ATTRIBUTE = 'pomVersion'
    private final String SPARTA_VERSION_NEEDED_FOR_PROMOTION = "2.11.0"

    private def pipeline
    private Api api

    InstanceHandler(pipeline) {
        this.pipeline = pipeline
        this.api = new Api(pipeline)
    }

    /**
     * Get the Sparta ticket for the specified environment
     * @param env - Environment to interact with
     * @return - Authentication Sparta ticket for the interaction with the API
     */
    String getSpartaTicket(EnvironmentEnum env){
        api.getSpartaTicket(env)
    }

    /**
     * Validate if the Sparta instance version for the specified environment if valid to use the workflow promotion functionality.
     * Should be equals or higher than 2.11.0
     * @param env - Environment to interact with
     */
    void validateSpartaVersion(EnvironmentEnum env){
        String spartaVersion = getSpartaInstanceVersion(env)

        // Compare Sparta instance version with the needed version to use the workflow promotion
        int comparisonResult = SemanticVersion.parse(spartaVersion).compareTo(SemanticVersion.parse(SPARTA_VERSION_NEEDED_FOR_PROMOTION))

        boolean validSpartaInstanceVersion = (comparisonResult >= 0)
        pipeline.println "[INFO] Sparta instance in $env with version $spartaVersion. Valid for promotion? $validSpartaInstanceVersion"

        if (!validSpartaInstanceVersion){
            pipeline.error "[ERROR] Invalid Sparta instance version. In order to use the workflow promotion functionality all the Sparta instances must have a version equals to or greater than $SPARTA_VERSION_NEEDED_FOR_PROMOTION"
        }
    }

    /**
     * Gets the version of the Sparta instance for the specified environment
     * @param env
     * @return - Sparta instance version
     */
    private String getSpartaInstanceVersion(EnvironmentEnum env){
        SpartaResponse spartaResponse = api.executeGet(env, SPARTA_ENDPOINT_APP_INFO)
        if (!spartaResponse.isOK || !spartaResponse.isJsonResponse || spartaResponse.responseCode != 200) {
            pipeline.error "[ERROR] Error while getting app info for env: $env"
        }

        String appInfoJson = spartaResponse.getResponseBody()
        def jsonProps = pipeline.readJSON text: "$appInfoJson"
        String spartaVersion = jsonProps[SPARTA_APP_INFO_VERSION_ATTRIBUTE]
        spartaVersion.substring(0, spartaVersion.indexOf("-"))
    }
}
