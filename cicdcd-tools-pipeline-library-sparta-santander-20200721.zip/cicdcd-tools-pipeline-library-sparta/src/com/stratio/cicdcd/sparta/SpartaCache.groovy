package com.stratio.cicdcd.sparta

import com.stratio.cicdcd.utils.EnvironmentEnum

/**
 * Singleton class used for caching sparta tickets
 */
class SpartaCache implements Serializable {
    private static final INSTANCE = new SpartaCache()
    def ticketMap = [:]

    private SpartaCache(){
    }

    static getInstance(){
        return INSTANCE
    }

    void putTicket(EnvironmentEnum key, String value){
        ticketMap.put(key, value)
    }

    String getTicket(EnvironmentEnum key){
        ticketMap.get(key)
    }

}