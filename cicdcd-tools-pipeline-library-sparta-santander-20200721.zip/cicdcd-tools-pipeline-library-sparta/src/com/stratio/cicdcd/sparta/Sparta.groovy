package com.stratio.cicdcd.sparta

import com.santander.alm.pipeline.maven.Maven
import com.stratio.cicdcd.utils.EnvVarCredentials
import com.stratio.cicdcd.utils.EnvironmentEnum
import com.stratio.cicdcd.utils.SpartaUtils

/**
 * Contains the core logic of the Sparta pipeline's behaviour for Sparta workflow promotion
 */
class Sparta implements Serializable {

    private final String SPARTA_EXECUTION_ENGINE_STREAMING = "Streaming"
    private final String SPARTA_EXECUTION_ENGINE_BATCH = "Batch"

    private final String WORKFLOW_BACKUP_SUFFIX = '.backup'
    private final String WORKFLOW_JSON_FILE_ORIGIN_PATTERN = 'originWorkflow-JOB_NAME-BUILD_NUMBER.json'
    private final String WORKFLOW_JSON_FILE_DESTINATION_PATTERN = 'destinationWorkflow-JOB_NAME-BUILD_NUMBER.json'
    private final String WORKFLOW_JSON_FILE_ORIGIN
    private final String WORKFLOW_JSON_FILE_DESTINATION
    private final String WORKFLOW_JSON_FILE_DESTINATION_BACKUP

    private def pipeline
    private InstanceHandler instanceHandler
    private WorkflowHandler workflowHandler
    private PromotionVersionHandler workflowVersionHandler

    Sparta(pipeline) {
        this.pipeline = pipeline
        this.instanceHandler = new InstanceHandler(pipeline)
        this.workflowHandler = new WorkflowHandler(pipeline)
        this.workflowVersionHandler = new PromotionVersionHandler(pipeline)
        // Set workflow json file names based on job name and build number to avoid collision between jobs
        WORKFLOW_JSON_FILE_ORIGIN = WORKFLOW_JSON_FILE_ORIGIN_PATTERN.replaceAll('JOB_NAME-BUILD_NUMBER', pipeline.BUILD_TAG.replaceAll(' ', '-'))
        WORKFLOW_JSON_FILE_DESTINATION = WORKFLOW_JSON_FILE_DESTINATION_PATTERN.replaceAll('JOB_NAME-BUILD_NUMBER', pipeline.BUILD_TAG.replaceAll(' ', '-'))
        WORKFLOW_JSON_FILE_DESTINATION_BACKUP = WORKFLOW_JSON_FILE_DESTINATION + WORKFLOW_BACKUP_SUFFIX
    }

    /**
     * Validate version of the Sparta instances involved in the promotion has the needed versions.
     * @param config.originEnv = Origin Sparta instance in the promotion
     * @param config.destinationEnv = Destination Sparta instance in the promotion
     */
    void validateSpartaInstancesVersion(config){
        EnvironmentEnum originEnv = config.originEnv
        EnvironmentEnum destinationEnv = config.destinationEnv
        // Validate Sparta instance version in origin
        instanceHandler.validateSpartaVersion(originEnv)
        // Validate Sparta instance version in destination
        instanceHandler.validateSpartaVersion(destinationEnv)
    }

    /**
     * Retrieves from Sparta origin instance the specified workflow that meets the specified data (workflowName, group, version).
     * @param config.originEnv = Origin Sparta instance from which the workflow will be copied.
     * @param config.workflowName = Name of the workflow for it's identification.
     * @param config.workflowGroup = Group of the workflow for it's identification.
     * @param config.workflowVersion = Version of the workflow for it's identification.
     */
    void checkoutWorkflowSource(config){
        EnvironmentEnum originEnv = config.originEnv
        String workflowName = config.workflowName
        String workflowGroup = config.workflowGroup
        String workflowVersion = config.workflowVersion

        // Find workflow
        String workflowJson = workflowHandler.findWorkflow(originEnv, workflowName, workflowGroup, workflowVersion)

        // Write workflow response as json file
        def jsonProps = pipeline.readJSON text: "$workflowJson"
        pipeline.writeJSON file: WORKFLOW_JSON_FILE_ORIGIN, json: jsonProps, pretty: 4
    }

    /**
     * Promotes the workflow to the destination Sparta instance from the origin workflow.
     * @param config.originEnv = Origin Sparta instance from which the workflow will be copied.
     * @param config.destinationEnv = Destination Sparta instance to which the workflow will be copied.
     * @param config.workflowName = Name of the workflow for it's identification.
     * @param config.workflowGroup = Group of the workflow for it's identification.
     * @param config.workflowVersion = Version of the workflow for it's identification.
     */
    void loadWorkflowTarget(config){
        EnvironmentEnum originEnv = config.originEnv
        EnvironmentEnum destinationEnv = config.destinationEnv

        String workflowName = config.workflowName
        String workflowGroup = config.workflowGroup
        String workflowVersion = config.workflowVersion

        // Validate if origin workflow is marked as Released, if that's the case then promotion of workflow is not allowed
        validateWorkflowPromotionAllowed(pipeline.readJSON(file: WORKFLOW_JSON_FILE_ORIGIN))

        String deployedWorkflowJson = workflowHandler.findWorkflow(destinationEnv, workflowName, workflowGroup, workflowVersion, true)
        if (deployedWorkflowJson) {
            // Write destination workflow in a file as a backup
            def destinationBackupJsonProps = pipeline.readJSON text: deployedWorkflowJson
            pipeline.writeJSON file: WORKFLOW_JSON_FILE_DESTINATION_BACKUP, json: destinationBackupJsonProps, pretty: 4

            // Validate if target workflow is marked as Released, if that's the case then promotion of workflow is not allowed
            validateWorkflowPromotionAllowed(destinationBackupJsonProps)
        }

        // Prepare target workflow from source
        def targetJsonProps = pipeline.readJSON file: WORKFLOW_JSON_FILE_ORIGIN
        targetJsonProps = updatePromotionVersion(targetJsonProps, destinationEnv)

        // Write workflow target as json file
        pipeline.writeJSON file: WORKFLOW_JSON_FILE_DESTINATION, json: targetJsonProps, pretty: 4

        // Create or update target workflow
        workflowHandler.createOrUpdateWorkflow(originEnv, destinationEnv, targetJsonProps)
    }

    /**
     * Execute tests in the provided environment
     * The tests are defined in a Maven project in Git
     * @param config.testEnv - Target environment when the test will be executed
     * @param config.testsTag - Defines the type of tests that is going to be executed. Eg. '@CICD'
     *                          If no testTag value specified, then all tests will be executed
     */
    void executeTests(config){
        EnvironmentEnum testEnv = config.testEnv
        String testsTag = config.testsTag
        pipeline.println "[INFO] Executing tests in the environment: $testEnv"

        String spartaTicket = instanceHandler.getSpartaTicket(testEnv)
        String credentialsIdVarName = EnvVarCredentials.getSpartaCredentialsVar(testEnv)

        pipeline.withCredentials([[$class          : 'UsernamePasswordMultiBinding',
                                   credentialsId   : "$credentialsIdVarName",
                                   usernameVariable: 'SPARTA_USER',
                                   passwordVariable: 'SPARTA_PASS']]) {
            config.goal = 'clean verify'
            // TODO: Mask the spartaTicket in order to avoid being visible in the output console. Needed installation of 'mask-passwords' Jenkins plugin.
            config.args = "--file ${config.testProjectPath}/pom.xml " +
                    "-DbaseURI=${SpartaUtils.getSpartaUrl(pipeline, testEnv)} " +
                    "-DuserTicket=${spartaTicket}" +
                    ((testsTag) ? " -Dcucumber.options='--tags $testsTag'" : '')

            Maven maven = new Maven(pipeline)
            maven.executeMaven(config)
        }
    }

    /**
     * Publishes the Serenity tests report.
     * @param config.testProjectPath: Path where the test project is located in the test repository.
     * @param config.testEnv - Target environment when the test will be executed
     */
    void publishTestsReport(config){
        String testProjectPath = config.testProjectPath
        EnvironmentEnum testEnv = config.testEnv
        pipeline.println "[INFO] Executing publication test report in: $testProjectPath/target/site/serenity for env $testEnv"

        pipeline.publishHTML(target: [
                            reportName           : "Serenity ${testEnv.label} tests report",
                            reportDir            : "$testProjectPath/target/site/serenity",
                            reportFiles          : 'index.html',
                            keepAll              : true,
                            alwaysLinkToLastBuild: true,
                            allowMissing         : false
                            ])
    }

    /**
     * Restore in destination the workflow saved in backup when tests fail.
     * @param config.destinationEnv = Destination Sparta instance in which the workflow will be restored.
     */
    void restoreWorkflow(config){
        EnvironmentEnum destinationEnv = config.destinationEnv
        pipeline.println "[INFO] Executing restoreWorkflow with params: env $destinationEnv"

        // If there was a previously deployed workflow in destination then restore it
        def backupExists = pipeline.fileExists WORKFLOW_JSON_FILE_DESTINATION_BACKUP
        if (backupExists) {
            def backupJsonProps = pipeline.readJSON file: WORKFLOW_JSON_FILE_DESTINATION_BACKUP

            // Restore backup workflow
            workflowHandler.updateWorkflow(destinationEnv, backupJsonProps)
            // If there was no previously deployed workflow then delete the last one
        } else {
            // Delete deployed workflow
            def jsonProps = pipeline.readJSON file: WORKFLOW_JSON_FILE_DESTINATION
            String workflowId = jsonProps['id']
            workflowHandler.deleteWorkflow(destinationEnv, workflowId)
        }

        pipeline.println "[INFO] Restored previous workflow state"
    }

    /**
     * Sets the value for versioning after workflow promotion and successful testing
     * @param config.originEnv = Origin Sparta instance to update the promotion version.
     * @param config.destinationEnv = Destination Sparta instance to determine the promotion type.
     */
    void applyWorkflowPromotionVersioning(config){
        EnvironmentEnum originEnv = config.originEnv
        EnvironmentEnum destinationEnv = config.destinationEnv

        // Update source workflow
        def sourceJsonProps = pipeline.readJSON file: WORKFLOW_JSON_FILE_ORIGIN
        sourceJsonProps = updatePromotionVersion(sourceJsonProps, destinationEnv)
        pipeline.writeJSON file: WORKFLOW_JSON_FILE_ORIGIN, json: sourceJsonProps, pretty: 4
        workflowHandler.updateWorkflow(originEnv, sourceJsonProps)

        // If promoting workflow from PRE to PRO, then update promotion version in DEV to add Release value
        if (EnvironmentEnum.PRO == destinationEnv){
            pipeline.println "[INFO] Update develop version of workflow to set RELEASE tag due to promotion to production env"
            String workflowName = config.workflowName
            String workflowGroup = config.workflowGroup
            String workflowVersion = config.workflowVersion

            // Update DEV workflow with Released promotion version
            String devWorkflowJson = workflowHandler.findWorkflow(EnvironmentEnum.DEV, workflowName, workflowGroup, workflowVersion)
            def devJsonProps = pipeline.readJSON text: devWorkflowJson
            devJsonProps = updatePromotionVersion(devJsonProps, destinationEnv)
            workflowHandler.updateWorkflow(EnvironmentEnum.DEV, devJsonProps)
        }
    }

    /**
     * Execute workflow after has been promoted to the destination environment
     * @param config.destinationEnv = Destination Sparta instance to which the workflow will be ran.
     */
    void runWorkflow(config){
        pipeline.println "[INFO] Executing workflow run"

        // Run workflow only if it's of type streaming, so if it's not then do nothing
        def targetJsonProps = pipeline.readJSON file: WORKFLOW_JSON_FILE_DESTINATION
        String executionEngine = targetJsonProps['executionEngine']

        if (executionEngine == SPARTA_EXECUTION_ENGINE_BATCH){
            pipeline.println "[INFO] Workflow execution type $SPARTA_EXECUTION_ENGINE_BATCH. Not running workflow"
        } else if (executionEngine == SPARTA_EXECUTION_ENGINE_STREAMING){
            EnvironmentEnum env = config.destinationEnv
            String workflowId = targetJsonProps['id']
            workflowHandler.runWorkflow(env, workflowId)

            pipeline.println "[INFO] Workflow execution type $SPARTA_EXECUTION_ENGINE_STREAMING. Running workflow"
        }
    }

    /**
     * Validate if workflow has already been released, if it's the case then don't allow workflow promotion and stop pipeline execution
     * @param jsonProps - Contains the json object of the workflow
     */
    private void validateWorkflowPromotionAllowed(jsonProps){
        pipeline.println "[INFO] Executing validation of workflow to check if it has already been release into production environment"

        if (workflowVersionHandler.isReleasedVersion(jsonProps)){
            pipeline.error "[ERROR] Not allowed workflow promotion because this workflow has already been released into production environment and can't be modified. In order to continue developing the workflow a new version should be created."
        }
    }

    /**
     * Modify the passed workflow json in order to change the promotion version.
     * @param jsonProps - Contains the json object to which the tags will be updated.
     * @param destinationEnv - Environment destination to which the workflow is being promoted.
     * @return Workflow with modified tags
     */
    private def updatePromotionVersion(jsonProps, EnvironmentEnum destinationEnv){
        def deployedJsonProps
        def deployedWorkflowExists = pipeline.fileExists WORKFLOW_JSON_FILE_DESTINATION_BACKUP
        if (deployedWorkflowExists) {
            deployedJsonProps = pipeline.readJSON file: WORKFLOW_JSON_FILE_DESTINATION_BACKUP
        }

        workflowVersionHandler.updateTagsJson(jsonProps, destinationEnv, deployedJsonProps)
    }

}
