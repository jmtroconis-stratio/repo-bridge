package com.stratio.cicdcd.sparta

import groovy.json.JsonException
import groovy.json.JsonSlurper

/**
 * Sparta Helper Class to retrieve Sparta responses. The responses depends on the error type. If
 * a response is OK, it comes compressed sometimes.
 */
class SpartaResponse{

    def statusCode
    def errorCode
    def message
    def exception
    def responseCode
    def responseBody
    def isOK
    def jsonSize
    boolean isJsonResponse = true

    SpartaResponse(pipeline, statusCode, body){
        this.responseCode = statusCode
        this.isOK = (this.responseCode < 400)
        this.responseBody = body

        def json
        try{
            json = new JsonSlurper().parseText(this.responseBody)
            this.jsonSize = json.size()
        }catch (JsonException ex){
            //sparta responses sometimes are not a JSON ...
            this.isJsonResponse=false
        }

        if(isJsonResponse){
            this.statusCode = json.statusCode
            this.errorCode  = json.errorCode
            this.message    = json.message
            this.exception  = json.exception
        }
    }

    @Override
    String toString(){


        if(isOK){
            String res = "SpartaResponse:"
            res += "\n\tresponseCode: $responseCode"
            if(isJsonResponse){
                res += "\n\t   json size: ${jsonSize}"
            }
            res += "\n\tresponseBody: $responseBody"
            return res
        }else{
            String response = "SpartaResponse:"

            if (isJsonResponse){
                response += "\n\t  statusCode: $statusCode" +
                            "\n\t   errorCode: $errorCode" +
                            "\n\t     message: $message" +
                            "\n\t   exception: $exception" +
                            "\n\t   json size: ${jsonSize}"
            }

//            response += "\n\tisCompressed: $isCompressed" +
            response += "\n\tresponseCode: $responseCode" +
                        "\n\tresponseBody: $responseBody"

            response
        }
    }
}
