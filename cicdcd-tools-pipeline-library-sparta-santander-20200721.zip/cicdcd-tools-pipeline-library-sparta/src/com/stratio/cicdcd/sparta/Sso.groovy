package com.stratio.cicdcd.sparta

import com.stratio.cicdcd.utils.EnvVarCredentials
import com.stratio.cicdcd.utils.EnvironmentEnum

/**
 * Sso class handles interaction with Jenkins sso_login_sparta.sh script used for authenticate against Sparta
 */
class Sso implements Serializable {

    def pipeline
    private final String DEFAULT_TENANT = 'NONE'

    Sso(pipeline) {
        this.pipeline = pipeline
    }

    /**
     * Resolve sparta ticket for api interaction based on the passed environment
     * Handles a cache class in order to reuse the sparta tickets between api requests
     * @param env - Environment to retrieve the sparta ticket
     * @return Sparta ticket
     */
    String getSpartaTicket(EnvironmentEnum env){
        // Retrieve cached sparta ticket value and if not cached then retrieve it from environment
        String ticket = SpartaCache.instance.getTicket(env)
        if (ticket) {
            pipeline.println "[INFO] Cached sparta ticket for $env environment"
        } else {
            pipeline.println "[INFO] Sparta ticket not cached, so retrieve it from $env environment"
            ticket = retrieveSpartaTicket(env)
            if (!ticket) {
                pipeline.error "Unable to login into $env environment"
            }

            // Save retrieved sparta ticket in cache
            SpartaCache.instance.putTicket(env, ticket)
        }

        ticket
    }

    /**
     * Retrieve sparta ticket based on the provided environment
     * @param env - Environment for which the sparta ticket should be retrieved
     * @return - Sparta ticket
     */
    private String retrieveSpartaTicket(EnvironmentEnum env){
        pipeline.println "[INFO] Getting sparta ticket from ${env.name()} environment"

        String spartaTicket
        String spartaUrl = EnvVarCredentials.getSpartaUrl(pipeline, env)
        String credentialsIdVarName = EnvVarCredentials.getSpartaCredentialsVar(env)
        String ticketFile = "ticket-${env.name()}-${pipeline.BUILD_TAG}".replace(' ', '-')
        String tenant = pipeline.env["SPARTA_TENANT_$env"] ?: DEFAULT_TENANT

        try {
            pipeline.withCredentials([[$class          : 'UsernamePasswordMultiBinding',
                                       credentialsId   : "$credentialsIdVarName",
                                       usernameVariable: 'USERLOGIN',
                                       passwordVariable: 'PASSWD']]) {

                pipeline.withEnv(["SPARTA_UI_URI=$spartaUrl",
                                  "TENANT=${tenant}",
                                  "TICKET_FILE=$ticketFile"]) {

                    pipeline.configFileProvider([pipeline.configFile(fileId: 'sso_login_sparta', variable: 'SSO_LOGIN_FILE')]) {

                        pipeline.sh "bash '${pipeline.SSO_LOGIN_FILE}'"

                        spartaTicket = pipeline.sh script: "cat '$ticketFile'", returnStdout: true
                        spartaTicket = spartaTicket.replaceAll("\\n", "").replaceAll("\\r", "")
                    }
                }
            }
        } catch (Exception e){
            pipeline.println "[ERROR] Error getting sparta user ticket: ${e.getMessage()}"
            pipeline.println "Unable to login into $spartaUrl with credentials $credentialsIdVarName"
        }

        return spartaTicket
    }

}
