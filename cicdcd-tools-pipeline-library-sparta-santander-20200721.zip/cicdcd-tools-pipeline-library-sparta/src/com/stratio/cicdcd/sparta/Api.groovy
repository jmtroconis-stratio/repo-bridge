package com.stratio.cicdcd.sparta

import com.stratio.cicdcd.utils.EnvironmentEnum
import com.stratio.cicdcd.utils.HttpUtils
import com.stratio.cicdcd.utils.SpartaUtils

/**
 * Class that executes all the interactions with the Sparta Api
 * - Resolve urls of the environments from jenkins slave environment variables
 * - Resolve sparta ticket for api authentication
 * - Handle caching of Sparta ticket for reuse the tickets between api requests
 */
class Api implements Serializable {

    def pipeline
    Sso sso

    Api(pipeline) {
        this.pipeline = pipeline
        this.sso = new Sso(pipeline)
    }

    /**
     * Execute get request to the Sparta api
     * @param env
     * @param endpoint
     * @return SpartaResponse
     */
    SpartaResponse executeGet(EnvironmentEnum env, String endpoint){
        String spartaTicket = sso.getSpartaTicket(env)
        HttpUtils httpUtils = new HttpUtils(pipeline, "$spartaTicket")
        httpUtils.executeGet(pipeline, "${SpartaUtils.getSpartaUrl(pipeline, env)}$endpoint")
    }

    /**
     * Execute post request to the Sparta api
     * @param env
     * @param endpoint
     * @param body
     * @return SpartaResponse
     */
    SpartaResponse executePost(EnvironmentEnum env, String endpoint, String body = null){
        String spartaTicket = sso.getSpartaTicket(env)
        HttpUtils httpUtils = new HttpUtils(pipeline, "$spartaTicket")
        httpUtils.executePost(pipeline, "${SpartaUtils.getSpartaUrl(pipeline, env)}$endpoint", body)
    }

    /**
     * Execute put request to the Sparta api
     * @param env
     * @param endpoint
     * @param body
     * @return SpartaResponse
     */
    SpartaResponse executePut(EnvironmentEnum env, String endpoint, String body){
        String spartaTicket = sso.getSpartaTicket(env)
        HttpUtils httpUtils = new HttpUtils(pipeline, "$spartaTicket")
        httpUtils.executePut(pipeline, "${SpartaUtils.getSpartaUrl(pipeline, env)}$endpoint", body)
    }

    /**
     * Execute delete request to the Sparta api
     * @param env
     * @param endpoint
     * @return SpartaResponse
     */
    SpartaResponse executeDelete(EnvironmentEnum env, String endpoint){
        String spartaTicket = sso.getSpartaTicket(env)
        HttpUtils httpUtils = new HttpUtils(pipeline, "$spartaTicket")
        httpUtils.executeDelete(pipeline, "${SpartaUtils.getSpartaUrl(pipeline, env)}$endpoint")
    }

    /**
     * Get sparta ticket for the specified environment
     * @param env
     * @return - Sparta ticket
     */
    String getSpartaTicket(EnvironmentEnum env){
        sso.getSpartaTicket(env)
    }

}
