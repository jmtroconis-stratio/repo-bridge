package com.stratio.cicdcd.exception

/**
 * Exception to be thrown when a workflow is not present in Sparta instance
 * {"statusCode":500,"errorCode":"702","message":"Error executing workflow query","exception":"No workflow found"}
 */
class SpartaWorkflowNotFoundException{

    /**
     * Constructor
     * @param pipeline The object pipeline needed to stop its execution
     * @param message The detailed info returned by the Sparta API
     */
    SpartaWorkflowNotFoundException(pipeline, message){
        pipeline.println "[ERROR] A workflow with the given name and in the given group has not been found."
        pipeline.error "Workflow not found $message"
    }

}
