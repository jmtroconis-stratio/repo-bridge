package com.stratio.cicdcd.exception

/**
* Exception to be thrown when a workflow already exists in the destination Sparta instance
*/
class SpartaWorkflowAlreadyExistsException {

    /**
     * Constructor
     * @param pipeline The object pipeline needed to stop its execution
     * @param message The detailed info returned by the Sparta API
     */
    SpartaWorkflowAlreadyExistsException(pipeline,message){
        pipeline.println "[ERROR] A workflow with the given name and group already exists in the " +
                "destination Sparta instance"
        pipeline.error "Workflow already exists $message"
    }

}
