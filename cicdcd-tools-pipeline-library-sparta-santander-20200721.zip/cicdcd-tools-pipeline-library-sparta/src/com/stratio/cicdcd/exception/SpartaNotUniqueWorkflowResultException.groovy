package com.stratio.cicdcd.exception

/**
 * This Exception must be raised when the query to the Sparta API does not return a unique value. It
 * ends the execution of the pipeline with an error message.
  */
class SpartaNotUniqueWorkflowResultException{

    /**
     * Constructor
     * @param pipeline The object pipeline needed to stop its execution
     * @param message The detailed info returned by the Sparta API
     */
    SpartaNotUniqueWorkflowResultException(pipeline, message){
        pipeline.println "[ERROR] The Sparta API does not return a unique result for the query."
        pipeline.error "Not a unique workflow:\n ${message} "
    }
}
