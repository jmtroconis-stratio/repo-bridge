#!/usr/bin/env bash

PATH_TO_PROJECT=$1
#urlSsoLoginSource="https://admin.dev.air.hospitales.sanitas.azure:9005/sso/login?service=https%3A%2F%2Fadmin.dev.air.hospitales.sanitas.azure%3A9005%2Fsso%2Foauth2.0%2FcallbackAuthorize"
#urlSource="https://sparta.dev.air.hospitales.sanitas.dom/sparta-pegaso"
#spartaSourceCredentials="dcos_credentials"
#urlSsoLoginTarget="https://admin.dev.air.hospitales.sanitas.azure:9005/sso/login?service=https%3A%2F%2Fadmin.dev.air.hospitales.sanitas.azure%3A9005%2Fsso%2Foauth2.0%2FcallbackAuthorize"
#urlTarget="https://sparta.dev.air.hospitales.sanitas.dom/sparta-pegaso"
#spartaTargetCredentials="dcos_credentials"

#originEnv="dev"
#destinationEnv="dev"
#workflowSourceName="workflow-name"
#workflowSourceGroup="/home"
#workflowSourceVersion="0"
#workflowTargetGroup="/home/target"



echo "[INFO] executing... "

echo "[INFO] synchronizing repository"

git add ..
TMPSTMP=$(date +%s%N | cut -b1-13)
git commit -m "synchronizing on origin remote ${TMPSTMP}"
git push origin

echo "[INFO] starting jenkinsfile runner docker"

docker run --rm \
  -e JAVA_OPTS=-Dhudson.model.ParametersAction.keepUndefinedParameters=true  \
  -e CASC_JENKINS_CONFIG=/tmp/casc.yml \
  -v $PATH_TO_PROJECT:/workspace \
  -v /home/jmtroconis/workspace/sparta/casc.yml:/tmp/casc.yml \
  -v /run/docker.sock:/var/run/docker.sock \
  -v ~/.ssh/id_rsa:/run/secrets/id_rsa \
  -v ~/.ssh/private-keys/github-sparta-sanitas-id-rsa:/run/secrets/github-sparta-sanitas-id-rsa \
  -v ~/.ssh/user-pass/ey_pegaso_demo_dcos_admin_credentials_password:/run/secrets/ey_pegaso_demo_dcos_admin_credentials_password \
  -v ~/.ssh/user-pass/ey_pegaso_demo_dcos_cicdcdservice_credentials_password:/run/secrets/ey_pegaso_demo_dcos_cicdcdservice_credentials_password \
  -v ~/.ssh/user-pass/sanitas_dcos_admin_credentials_password:/run/secrets/sanitas_dcos_admin_credentials_password \
  -v ~/.ssh/user-pass/sanitas_dcos_cicdcdservice_credentials_password:/run/secrets/sanitas_dcos_cicdcdservice_credentials_password \
  -v ~/.ssh/user-pass/sanitas_sparta_pre_eosadmin-pre_credentials_password:/run/secrets/sanitas_sparta_pre_eosadmin-pre_credentials_password \
  -v /media/jmtroconis/Datos2/sdkman/candidates/java/current/lib/security/cacerts:/usr/local/openjdk-8/jre/lib/security/cacerts \
  --network=host \
  --name=jenkinsfile-runner \
  cicdcd/jenkinsfile-runner:latest \
  -ns
#
#echo "[INFO] Deleting working directory $JENKINS_HOME_DIR"
#rm -rf $JENKINS_HOME_DIR