#!groovy
import com.stratio.cicdcd.utils.EnvironmentEnum

def call(Map args = [:]){
    args.originEnv = EnvironmentEnum.PRE
    args.destinationEnv = EnvironmentEnum.PRO
    spartaWorkflowPromotionPipeline(args)
}
