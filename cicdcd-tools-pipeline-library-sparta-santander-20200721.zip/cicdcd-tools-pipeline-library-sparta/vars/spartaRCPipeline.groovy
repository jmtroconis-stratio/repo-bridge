#!groovy
import com.stratio.cicdcd.utils.EnvironmentEnum

def call(Map args = [:]){
    args.originEnv = EnvironmentEnum.DEV
    args.destinationEnv = EnvironmentEnum.PRE
    spartaWorkflowPromotionPipeline(args)
}
