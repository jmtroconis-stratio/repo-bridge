#!groovy

import com.stratio.cicdcd.sparta.Sparta

void validateSpartaInstancesVersion(Map args = [:]){
    new Sparta(this).validateSpartaInstancesVersion(args)
}

void checkoutWorkflowSource(Map args = [:]){
    new Sparta(this).checkoutWorkflowSource(args)
}

void executeTests(Map args = [:]){
    new Sparta(this).executeTests(args)
}

void publishTestsReport(Map args = [:]){
    new Sparta(this).publishTestsReport(args)
}

void loadWorkflowTarget(Map args = [:]){
    new Sparta(this).loadWorkflowTarget(args)
}

void restoreWorkflow(Map args = [:]){
    new Sparta(this).restoreWorkflow(args)
}

void applyWorkflowPromotionVersioning(Map args = [:]){
    new Sparta(this).applyWorkflowPromotionVersioning(args)
}

void runWorkflow(Map args = [:]){
    new Sparta(this).runWorkflow(args)
}