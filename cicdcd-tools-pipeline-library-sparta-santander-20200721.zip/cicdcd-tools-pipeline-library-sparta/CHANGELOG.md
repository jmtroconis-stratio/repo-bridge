# Changelog

## Prerequisites of the current version

* cicdcd-tools-pipeline-library-commons >= 3.6.0

## 3.1.0
- Changed pipeline to avoid Jenkins Sandbox restrictions.
- Changed http client to use Http Rest Client class from Global ALM pipeline to avoid Jenkins sandbox restrictions.

## 3.0.2
- Hotfix: Fixed error with encoding during workflow promotion when the workflow contained special characters.

## 3.0.1

- Avoid error when parsing Sparta API response when there is an error message from the API.

## 3.0.0

#### Note: This version must be used with versions of Sparta equals to or greater than 2.11.0 and breaks compatibility with previous versions.

- Changed the attribute used for promotion versioning. Now it's used the attribute 'ciCdLabel'. Removed all usage of 'tags' attribute for promotion versioning.
- This version supports integration with Sparta to execute workflow promotion from user interface.

## 2.1.0

- Added functionality for execution of a test project for the Sparta workflows and publication of the tests report.
- Modified pipeline parameters.
- Modified environment variables in new Maven Slave
[Documentation](https://stratio.atlassian.net/wiki/spaces/TEAMDEVOPS/pages/634061357/DEVO-623+-+Introducir+las+fases+de+testing+en+el+flujo+de+Sparta)

## 2.0.1

- Changed names of files used for persisting workflow and ticket in order to avoid collisions when concurrent job executions. 

## 2.0.0

- Release process implemented as specified in [documentation](https://stratio.atlassian.net/wiki/spaces/TEAMDEVOPS/pages/593035286/DEVO-478+-+Preparaci+n+demo+reuni+n+sparta)
- Changes include:
  - Sparta workflow promotion between DEV, PRE and PRO environments.
  - Usage of slave deployer for workflow processing and environment variable definitions for Sparta Urls per environment.
  - Retrieve Sparta credentials per environment from Jenkins credentials.
  - Creation of groups its parents when don't exist.
  - Change input parameters of the workflow to admit origin environment, destination environment, tenant per environment and workflow.
  

## 1.0.0

- Initial version of the Sparta pipeline.